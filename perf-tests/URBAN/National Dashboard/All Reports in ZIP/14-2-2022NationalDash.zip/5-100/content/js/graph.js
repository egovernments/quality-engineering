/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 474.0, "minX": 0.0, "maxY": 60817.0, "series": [{"data": [[0.0, 474.0], [0.1, 474.0], [0.2, 474.0], [0.3, 474.0], [0.4, 481.0], [0.5, 481.0], [0.6, 481.0], [0.7, 481.0], [0.8, 492.0], [0.9, 492.0], [1.0, 492.0], [1.1, 492.0], [1.2, 514.0], [1.3, 514.0], [1.4, 514.0], [1.5, 518.0], [1.6, 518.0], [1.7, 518.0], [1.8, 518.0], [1.9, 518.0], [2.0, 518.0], [2.1, 518.0], [2.2, 518.0], [2.3, 519.0], [2.4, 519.0], [2.5, 519.0], [2.6, 532.0], [2.7, 532.0], [2.8, 532.0], [2.9, 532.0], [3.0, 537.0], [3.1, 537.0], [3.2, 537.0], [3.3, 537.0], [3.4, 537.0], [3.5, 537.0], [3.6, 537.0], [3.7, 539.0], [3.8, 539.0], [3.9, 539.0], [4.0, 539.0], [4.1, 542.0], [4.2, 542.0], [4.3, 542.0], [4.4, 542.0], [4.5, 544.0], [4.6, 544.0], [4.7, 544.0], [4.8, 548.0], [4.9, 548.0], [5.0, 548.0], [5.1, 548.0], [5.2, 550.0], [5.3, 550.0], [5.4, 550.0], [5.5, 550.0], [5.6, 554.0], [5.7, 554.0], [5.8, 554.0], [5.9, 554.0], [6.0, 558.0], [6.1, 558.0], [6.2, 558.0], [6.3, 558.0], [6.4, 558.0], [6.5, 558.0], [6.6, 558.0], [6.7, 565.0], [6.8, 565.0], [6.9, 565.0], [7.0, 565.0], [7.1, 575.0], [7.2, 575.0], [7.3, 575.0], [7.4, 577.0], [7.5, 577.0], [7.6, 577.0], [7.7, 577.0], [7.8, 578.0], [7.9, 578.0], [8.0, 578.0], [8.1, 578.0], [8.2, 578.0], [8.3, 578.0], [8.4, 578.0], [8.5, 580.0], [8.6, 580.0], [8.7, 580.0], [8.8, 580.0], [8.9, 581.0], [9.0, 581.0], [9.1, 581.0], [9.2, 581.0], [9.3, 583.0], [9.4, 583.0], [9.5, 583.0], [9.6, 588.0], [9.7, 588.0], [9.8, 588.0], [9.9, 588.0], [10.0, 591.0], [10.1, 591.0], [10.2, 591.0], [10.3, 591.0], [10.4, 592.0], [10.5, 592.0], [10.6, 592.0], [10.7, 592.0], [10.8, 596.0], [10.9, 596.0], [11.0, 596.0], [11.1, 598.0], [11.2, 598.0], [11.3, 598.0], [11.4, 598.0], [11.5, 603.0], [11.6, 603.0], [11.7, 603.0], [11.8, 603.0], [11.9, 604.0], [12.0, 604.0], [12.1, 604.0], [12.2, 605.0], [12.3, 605.0], [12.4, 605.0], [12.5, 605.0], [12.6, 610.0], [12.7, 610.0], [12.8, 610.0], [12.9, 610.0], [13.0, 615.0], [13.1, 615.0], [13.2, 615.0], [13.3, 617.0], [13.4, 617.0], [13.5, 617.0], [13.6, 617.0], [13.7, 628.0], [13.8, 628.0], [13.9, 628.0], [14.0, 628.0], [14.1, 628.0], [14.2, 628.0], [14.3, 628.0], [14.4, 632.0], [14.5, 632.0], [14.6, 632.0], [14.7, 632.0], [14.8, 635.0], [14.9, 635.0], [15.0, 635.0], [15.1, 635.0], [15.2, 644.0], [15.3, 644.0], [15.4, 644.0], [15.5, 647.0], [15.6, 647.0], [15.7, 647.0], [15.8, 647.0], [15.9, 647.0], [16.0, 647.0], [16.1, 647.0], [16.2, 647.0], [16.3, 649.0], [16.4, 649.0], [16.5, 649.0], [16.6, 649.0], [16.7, 654.0], [16.8, 654.0], [16.9, 654.0], [17.0, 658.0], [17.1, 658.0], [17.2, 658.0], [17.3, 658.0], [17.4, 659.0], [17.5, 659.0], [17.6, 659.0], [17.7, 659.0], [17.8, 665.0], [17.9, 665.0], [18.0, 665.0], [18.1, 667.0], [18.2, 667.0], [18.3, 667.0], [18.4, 667.0], [18.5, 669.0], [18.6, 669.0], [18.7, 669.0], [18.8, 669.0], [18.9, 672.0], [19.0, 672.0], [19.1, 672.0], [19.2, 673.0], [19.3, 673.0], [19.4, 673.0], [19.5, 673.0], [19.6, 686.0], [19.7, 686.0], [19.8, 686.0], [19.9, 686.0], [20.0, 689.0], [20.1, 689.0], [20.2, 689.0], [20.3, 696.0], [20.4, 696.0], [20.5, 696.0], [20.6, 696.0], [20.7, 697.0], [20.8, 697.0], [20.9, 697.0], [21.0, 697.0], [21.1, 698.0], [21.2, 698.0], [21.3, 698.0], [21.4, 698.0], [21.5, 706.0], [21.6, 706.0], [21.7, 706.0], [21.8, 707.0], [21.9, 707.0], [22.0, 707.0], [22.1, 707.0], [22.2, 711.0], [22.3, 711.0], [22.4, 711.0], [22.5, 711.0], [22.6, 721.0], [22.7, 721.0], [22.8, 721.0], [22.9, 733.0], [23.0, 733.0], [23.1, 733.0], [23.2, 733.0], [23.3, 740.0], [23.4, 740.0], [23.5, 740.0], [23.6, 740.0], [23.7, 748.0], [23.8, 748.0], [23.9, 748.0], [24.0, 764.0], [24.1, 764.0], [24.2, 764.0], [24.3, 764.0], [24.4, 768.0], [24.5, 768.0], [24.6, 768.0], [24.7, 768.0], [24.8, 772.0], [24.9, 772.0], [25.0, 772.0], [25.1, 775.0], [25.2, 775.0], [25.3, 775.0], [25.4, 775.0], [25.5, 775.0], [25.6, 775.0], [25.7, 775.0], [25.8, 775.0], [25.9, 780.0], [26.0, 780.0], [26.1, 780.0], [26.2, 780.0], [26.3, 780.0], [26.4, 780.0], [26.5, 780.0], [26.6, 781.0], [26.7, 781.0], [26.8, 781.0], [26.9, 781.0], [27.0, 782.0], [27.1, 782.0], [27.2, 782.0], [27.3, 782.0], [27.4, 785.0], [27.5, 785.0], [27.6, 785.0], [27.7, 795.0], [27.8, 795.0], [27.9, 795.0], [28.0, 795.0], [28.1, 829.0], [28.2, 829.0], [28.3, 829.0], [28.4, 829.0], [28.5, 830.0], [28.6, 830.0], [28.7, 830.0], [28.8, 834.0], [28.9, 834.0], [29.0, 834.0], [29.1, 834.0], [29.2, 838.0], [29.3, 838.0], [29.4, 838.0], [29.5, 838.0], [29.6, 845.0], [29.7, 845.0], [29.8, 845.0], [29.9, 870.0], [30.0, 870.0], [30.1, 870.0], [30.2, 870.0], [30.3, 876.0], [30.4, 876.0], [30.5, 876.0], [30.6, 876.0], [30.7, 918.0], [30.8, 918.0], [30.9, 918.0], [31.0, 928.0], [31.1, 928.0], [31.2, 928.0], [31.3, 928.0], [31.4, 929.0], [31.5, 929.0], [31.6, 929.0], [31.7, 929.0], [31.8, 942.0], [31.9, 942.0], [32.0, 942.0], [32.1, 942.0], [32.2, 951.0], [32.3, 951.0], [32.4, 951.0], [32.5, 957.0], [32.6, 957.0], [32.7, 957.0], [32.8, 957.0], [32.9, 958.0], [33.0, 958.0], [33.1, 958.0], [33.2, 958.0], [33.3, 962.0], [33.4, 962.0], [33.5, 962.0], [33.6, 968.0], [33.7, 968.0], [33.8, 968.0], [33.9, 968.0], [34.0, 977.0], [34.1, 977.0], [34.2, 977.0], [34.3, 977.0], [34.4, 982.0], [34.5, 982.0], [34.6, 982.0], [34.7, 982.0], [34.8, 982.0], [34.9, 982.0], [35.0, 982.0], [35.1, 989.0], [35.2, 989.0], [35.3, 989.0], [35.4, 989.0], [35.5, 999.0], [35.6, 999.0], [35.7, 999.0], [35.8, 1002.0], [35.9, 1002.0], [36.0, 1002.0], [36.1, 1002.0], [36.2, 1013.0], [36.3, 1013.0], [36.4, 1013.0], [36.5, 1013.0], [36.6, 1013.0], [36.7, 1013.0], [36.8, 1013.0], [36.9, 1013.0], [37.0, 1017.0], [37.1, 1017.0], [37.2, 1017.0], [37.3, 1024.0], [37.4, 1024.0], [37.5, 1024.0], [37.6, 1024.0], [37.7, 1027.0], [37.8, 1027.0], [37.9, 1027.0], [38.0, 1027.0], [38.1, 1046.0], [38.2, 1046.0], [38.3, 1046.0], [38.4, 1047.0], [38.5, 1047.0], [38.6, 1047.0], [38.7, 1047.0], [38.8, 1073.0], [38.9, 1073.0], [39.0, 1073.0], [39.1, 1073.0], [39.2, 1075.0], [39.3, 1075.0], [39.4, 1075.0], [39.5, 1084.0], [39.6, 1084.0], [39.7, 1084.0], [39.8, 1084.0], [39.9, 1085.0], [40.0, 1085.0], [40.1, 1085.0], [40.2, 1085.0], [40.3, 1092.0], [40.4, 1092.0], [40.5, 1092.0], [40.6, 1092.0], [40.7, 1092.0], [40.8, 1092.0], [40.9, 1092.0], [41.0, 1096.0], [41.1, 1096.0], [41.2, 1096.0], [41.3, 1096.0], [41.4, 1103.0], [41.5, 1103.0], [41.6, 1103.0], [41.7, 1103.0], [41.8, 1103.0], [41.9, 1103.0], [42.0, 1103.0], [42.1, 1123.0], [42.2, 1123.0], [42.3, 1123.0], [42.4, 1123.0], [42.5, 1130.0], [42.6, 1130.0], [42.7, 1130.0], [42.8, 1130.0], [42.9, 1144.0], [43.0, 1144.0], [43.1, 1144.0], [43.2, 1147.0], [43.3, 1147.0], [43.4, 1147.0], [43.5, 1147.0], [43.6, 1154.0], [43.7, 1154.0], [43.8, 1154.0], [43.9, 1154.0], [44.0, 1188.0], [44.1, 1188.0], [44.2, 1188.0], [44.3, 1192.0], [44.4, 1192.0], [44.5, 1192.0], [44.6, 1192.0], [44.7, 1197.0], [44.8, 1197.0], [44.9, 1197.0], [45.0, 1197.0], [45.1, 1198.0], [45.2, 1198.0], [45.3, 1198.0], [45.4, 1205.0], [45.5, 1205.0], [45.6, 1205.0], [45.7, 1205.0], [45.8, 1205.0], [45.9, 1205.0], [46.0, 1205.0], [46.1, 1205.0], [46.2, 1208.0], [46.3, 1208.0], [46.4, 1208.0], [46.5, 1212.0], [46.6, 1212.0], [46.7, 1212.0], [46.8, 1212.0], [46.9, 1220.0], [47.0, 1220.0], [47.1, 1220.0], [47.2, 1220.0], [47.3, 1235.0], [47.4, 1235.0], [47.5, 1235.0], [47.6, 1235.0], [47.7, 1237.0], [47.8, 1237.0], [47.9, 1237.0], [48.0, 1239.0], [48.1, 1239.0], [48.2, 1239.0], [48.3, 1239.0], [48.4, 1246.0], [48.5, 1246.0], [48.6, 1246.0], [48.7, 1246.0], [48.8, 1263.0], [48.9, 1263.0], [49.0, 1263.0], [49.1, 1270.0], [49.2, 1270.0], [49.3, 1270.0], [49.4, 1270.0], [49.5, 1278.0], [49.6, 1278.0], [49.7, 1278.0], [49.8, 1278.0], [49.9, 1288.0], [50.0, 1288.0], [50.1, 1288.0], [50.2, 1291.0], [50.3, 1291.0], [50.4, 1291.0], [50.5, 1291.0], [50.6, 1308.0], [50.7, 1308.0], [50.8, 1308.0], [50.9, 1308.0], [51.0, 1309.0], [51.1, 1309.0], [51.2, 1309.0], [51.3, 1318.0], [51.4, 1318.0], [51.5, 1318.0], [51.6, 1318.0], [51.7, 1354.0], [51.8, 1354.0], [51.9, 1354.0], [52.0, 1354.0], [52.1, 1360.0], [52.2, 1360.0], [52.3, 1360.0], [52.4, 1371.0], [52.5, 1371.0], [52.6, 1371.0], [52.7, 1371.0], [52.8, 1376.0], [52.9, 1376.0], [53.0, 1376.0], [53.1, 1376.0], [53.2, 1401.0], [53.3, 1401.0], [53.4, 1401.0], [53.5, 1401.0], [53.6, 1411.0], [53.7, 1411.0], [53.8, 1411.0], [53.9, 1412.0], [54.0, 1412.0], [54.1, 1412.0], [54.2, 1412.0], [54.3, 1421.0], [54.4, 1421.0], [54.5, 1421.0], [54.6, 1421.0], [54.7, 1443.0], [54.8, 1443.0], [54.9, 1443.0], [55.0, 1460.0], [55.1, 1460.0], [55.2, 1460.0], [55.3, 1460.0], [55.4, 1464.0], [55.5, 1464.0], [55.6, 1464.0], [55.7, 1464.0], [55.8, 1513.0], [55.9, 1513.0], [56.0, 1513.0], [56.1, 1519.0], [56.2, 1519.0], [56.3, 1519.0], [56.4, 1519.0], [56.5, 1527.0], [56.6, 1527.0], [56.7, 1527.0], [56.8, 1527.0], [56.9, 1530.0], [57.0, 1530.0], [57.1, 1530.0], [57.2, 1546.0], [57.3, 1546.0], [57.4, 1546.0], [57.5, 1546.0], [57.6, 1549.0], [57.7, 1549.0], [57.8, 1549.0], [57.9, 1549.0], [58.0, 1563.0], [58.1, 1563.0], [58.2, 1563.0], [58.3, 1563.0], [58.4, 1576.0], [58.5, 1576.0], [58.6, 1576.0], [58.7, 1578.0], [58.8, 1578.0], [58.9, 1578.0], [59.0, 1578.0], [59.1, 1608.0], [59.2, 1608.0], [59.3, 1608.0], [59.4, 1608.0], [59.5, 1613.0], [59.6, 1613.0], [59.7, 1613.0], [59.8, 1617.0], [59.9, 1617.0], [60.0, 1617.0], [60.1, 1617.0], [60.2, 1623.0], [60.3, 1623.0], [60.4, 1623.0], [60.5, 1623.0], [60.6, 1626.0], [60.7, 1626.0], [60.8, 1626.0], [60.9, 1653.0], [61.0, 1653.0], [61.1, 1653.0], [61.2, 1653.0], [61.3, 1654.0], [61.4, 1654.0], [61.5, 1654.0], [61.6, 1654.0], [61.7, 1684.0], [61.8, 1684.0], [61.9, 1684.0], [62.0, 1694.0], [62.1, 1694.0], [62.2, 1694.0], [62.3, 1694.0], [62.4, 1695.0], [62.5, 1695.0], [62.6, 1695.0], [62.7, 1695.0], [62.8, 1709.0], [62.9, 1709.0], [63.0, 1709.0], [63.1, 1782.0], [63.2, 1782.0], [63.3, 1782.0], [63.4, 1782.0], [63.5, 1783.0], [63.6, 1783.0], [63.7, 1783.0], [63.8, 1783.0], [63.9, 1822.0], [64.0, 1822.0], [64.1, 1822.0], [64.2, 1822.0], [64.3, 1892.0], [64.4, 1892.0], [64.5, 1892.0], [64.6, 1907.0], [64.7, 1907.0], [64.8, 1907.0], [64.9, 1907.0], [65.0, 1929.0], [65.1, 1929.0], [65.2, 1929.0], [65.3, 1929.0], [65.4, 2017.0], [65.5, 2017.0], [65.6, 2017.0], [65.7, 2017.0], [65.8, 2017.0], [65.9, 2017.0], [66.0, 2017.0], [66.1, 2020.0], [66.2, 2020.0], [66.3, 2020.0], [66.4, 2020.0], [66.5, 2039.0], [66.6, 2039.0], [66.7, 2039.0], [66.8, 2051.0], [66.9, 2051.0], [67.0, 2051.0], [67.1, 2051.0], [67.2, 2060.0], [67.3, 2060.0], [67.4, 2060.0], [67.5, 2060.0], [67.6, 2060.0], [67.7, 2060.0], [67.8, 2060.0], [67.9, 2079.0], [68.0, 2079.0], [68.1, 2079.0], [68.2, 2079.0], [68.3, 2122.0], [68.4, 2122.0], [68.5, 2122.0], [68.6, 2122.0], [68.7, 2162.0], [68.8, 2162.0], [68.9, 2162.0], [69.0, 2162.0], [69.1, 2203.0], [69.2, 2203.0], [69.3, 2203.0], [69.4, 2229.0], [69.5, 2229.0], [69.6, 2229.0], [69.7, 2229.0], [69.8, 2254.0], [69.9, 2254.0], [70.0, 2254.0], [70.1, 2254.0], [70.2, 2255.0], [70.3, 2255.0], [70.4, 2255.0], [70.5, 2317.0], [70.6, 2317.0], [70.7, 2317.0], [70.8, 2317.0], [70.9, 2324.0], [71.0, 2324.0], [71.1, 2324.0], [71.2, 2324.0], [71.3, 2374.0], [71.4, 2374.0], [71.5, 2374.0], [71.6, 2389.0], [71.7, 2389.0], [71.8, 2389.0], [71.9, 2389.0], [72.0, 2405.0], [72.1, 2405.0], [72.2, 2405.0], [72.3, 2405.0], [72.4, 2487.0], [72.5, 2487.0], [72.6, 2487.0], [72.7, 2514.0], [72.8, 2514.0], [72.9, 2514.0], [73.0, 2514.0], [73.1, 2516.0], [73.2, 2516.0], [73.3, 2516.0], [73.4, 2516.0], [73.5, 2599.0], [73.6, 2599.0], [73.7, 2599.0], [73.8, 2599.0], [73.9, 2629.0], [74.0, 2629.0], [74.1, 2629.0], [74.2, 2692.0], [74.3, 2692.0], [74.4, 2692.0], [74.5, 2692.0], [74.6, 2712.0], [74.7, 2712.0], [74.8, 2712.0], [74.9, 2712.0], [75.0, 2737.0], [75.1, 2737.0], [75.2, 2737.0], [75.3, 2906.0], [75.4, 2906.0], [75.5, 2906.0], [75.6, 2906.0], [75.7, 2979.0], [75.8, 2979.0], [75.9, 2979.0], [76.0, 2979.0], [76.1, 2997.0], [76.2, 2997.0], [76.3, 2997.0], [76.4, 3044.0], [76.5, 3044.0], [76.6, 3044.0], [76.7, 3044.0], [76.8, 3092.0], [76.9, 3092.0], [77.0, 3092.0], [77.1, 3092.0], [77.2, 3333.0], [77.3, 3333.0], [77.4, 3333.0], [77.5, 3589.0], [77.6, 3589.0], [77.7, 3589.0], [77.8, 3589.0], [77.9, 3684.0], [78.0, 3684.0], [78.1, 3684.0], [78.2, 3684.0], [78.3, 3848.0], [78.4, 3848.0], [78.5, 3848.0], [78.6, 4040.0], [78.7, 4040.0], [78.8, 4040.0], [78.9, 4040.0], [79.0, 4103.0], [79.1, 4103.0], [79.2, 4103.0], [79.3, 4103.0], [79.4, 4213.0], [79.5, 4213.0], [79.6, 4213.0], [79.7, 4213.0], [79.8, 4221.0], [79.9, 4221.0], [80.0, 4221.0], [80.1, 4222.0], [80.2, 4222.0], [80.3, 4222.0], [80.4, 4222.0], [80.5, 4415.0], [80.6, 4415.0], [80.7, 4415.0], [80.8, 4415.0], [80.9, 4443.0], [81.0, 4443.0], [81.1, 4443.0], [81.2, 4491.0], [81.3, 4491.0], [81.4, 4491.0], [81.5, 4491.0], [81.6, 4767.0], [81.7, 4767.0], [81.8, 4767.0], [81.9, 4767.0], [82.0, 4816.0], [82.1, 4816.0], [82.2, 4816.0], [82.3, 4906.0], [82.4, 4906.0], [82.5, 4906.0], [82.6, 4906.0], [82.7, 5455.0], [82.8, 5455.0], [82.9, 5455.0], [83.0, 5455.0], [83.1, 5563.0], [83.2, 5563.0], [83.3, 5563.0], [83.4, 5640.0], [83.5, 5640.0], [83.6, 5640.0], [83.7, 5640.0], [83.8, 6046.0], [83.9, 6046.0], [84.0, 6046.0], [84.1, 6046.0], [84.2, 6134.0], [84.3, 6134.0], [84.4, 6134.0], [84.5, 6134.0], [84.6, 6229.0], [84.7, 6229.0], [84.8, 6229.0], [84.9, 6304.0], [85.0, 6304.0], [85.1, 6304.0], [85.2, 6304.0], [85.3, 6523.0], [85.4, 6523.0], [85.5, 6523.0], [85.6, 6523.0], [85.7, 6911.0], [85.8, 6911.0], [85.9, 6911.0], [86.0, 7111.0], [86.1, 7111.0], [86.2, 7111.0], [86.3, 7111.0], [86.4, 7130.0], [86.5, 7130.0], [86.6, 7130.0], [86.7, 7130.0], [86.8, 7180.0], [86.9, 7180.0], [87.0, 7180.0], [87.1, 7304.0], [87.2, 7304.0], [87.3, 7304.0], [87.4, 7304.0], [87.5, 7466.0], [87.6, 7466.0], [87.7, 7466.0], [87.8, 7466.0], [87.9, 7726.0], [88.0, 7726.0], [88.1, 7726.0], [88.2, 8548.0], [88.3, 8548.0], [88.4, 8548.0], [88.5, 8548.0], [88.6, 9059.0], [88.7, 9059.0], [88.8, 9059.0], [88.9, 9059.0], [89.0, 9158.0], [89.1, 9158.0], [89.2, 9158.0], [89.3, 9247.0], [89.4, 9247.0], [89.5, 9247.0], [89.6, 9247.0], [89.7, 10966.0], [89.8, 10966.0], [89.9, 10966.0], [90.0, 10966.0], [90.1, 13669.0], [90.2, 13669.0], [90.3, 13669.0], [90.4, 13669.0], [90.5, 14661.0], [90.6, 14661.0], [90.7, 14661.0], [90.8, 15370.0], [90.9, 15370.0], [91.0, 15370.0], [91.1, 15370.0], [91.2, 15739.0], [91.3, 15739.0], [91.4, 15739.0], [91.5, 15739.0], [91.6, 16615.0], [91.7, 16615.0], [91.8, 16615.0], [91.9, 16758.0], [92.0, 16758.0], [92.1, 16758.0], [92.2, 16758.0], [92.3, 18359.0], [92.4, 18359.0], [92.5, 18359.0], [92.6, 18359.0], [92.7, 18503.0], [92.8, 18503.0], [92.9, 18503.0], [93.0, 18533.0], [93.1, 18533.0], [93.2, 18533.0], [93.3, 18533.0], [93.4, 19137.0], [93.5, 19137.0], [93.6, 19137.0], [93.7, 19137.0], [93.8, 30654.0], [93.9, 30654.0], [94.0, 30654.0], [94.1, 30749.0], [94.2, 30749.0], [94.3, 30749.0], [94.4, 30749.0], [94.5, 30812.0], [94.6, 30812.0], [94.7, 30812.0], [94.8, 30812.0], [94.9, 34330.0], [95.0, 34330.0], [95.1, 34330.0], [95.2, 34330.0], [95.3, 36316.0], [95.4, 36316.0], [95.5, 36316.0], [95.6, 45935.0], [95.7, 45935.0], [95.8, 45935.0], [95.9, 45935.0], [96.0, 55083.0], [96.1, 55083.0], [96.2, 55083.0], [96.3, 55083.0], [96.4, 60256.0], [96.5, 60256.0], [96.6, 60256.0], [96.7, 60263.0], [96.8, 60263.0], [96.9, 60263.0], [97.0, 60263.0], [97.1, 60268.0], [97.2, 60268.0], [97.3, 60268.0], [97.4, 60268.0], [97.5, 60274.0], [97.6, 60274.0], [97.7, 60274.0], [97.8, 60298.0], [97.9, 60298.0], [98.0, 60298.0], [98.1, 60298.0], [98.2, 60668.0], [98.3, 60668.0], [98.4, 60668.0], [98.5, 60668.0], [98.6, 60699.0], [98.7, 60699.0], [98.8, 60699.0], [98.9, 60730.0], [99.0, 60730.0], [99.1, 60730.0], [99.2, 60730.0], [99.3, 60772.0], [99.4, 60772.0], [99.5, 60772.0], [99.6, 60772.0], [99.7, 60817.0], [99.8, 60817.0], [99.9, 60817.0], [100.0, 60817.0]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 400.0, "maxY": 28.0, "series": [{"data": [[600.0, 27.0], [700.0, 18.0], [800.0, 7.0], [900.0, 14.0], [1000.0, 15.0], [1100.0, 11.0], [1200.0, 14.0], [1300.0, 7.0], [1400.0, 7.0], [1500.0, 9.0], [1600.0, 10.0], [1700.0, 3.0], [1800.0, 2.0], [1900.0, 2.0], [2000.0, 8.0], [2100.0, 2.0], [2300.0, 4.0], [2200.0, 4.0], [2400.0, 2.0], [2500.0, 3.0], [2600.0, 2.0], [2700.0, 2.0], [2900.0, 3.0], [3000.0, 2.0], [3300.0, 1.0], [3500.0, 1.0], [3600.0, 1.0], [3800.0, 1.0], [4000.0, 1.0], [4200.0, 3.0], [4100.0, 1.0], [4400.0, 3.0], [4800.0, 1.0], [4700.0, 1.0], [4900.0, 1.0], [5600.0, 1.0], [5500.0, 1.0], [5400.0, 1.0], [6000.0, 1.0], [6100.0, 1.0], [6200.0, 1.0], [6300.0, 1.0], [6500.0, 1.0], [6900.0, 1.0], [7100.0, 3.0], [7300.0, 1.0], [7400.0, 1.0], [7700.0, 1.0], [8500.0, 1.0], [9000.0, 1.0], [9200.0, 1.0], [9100.0, 1.0], [10900.0, 1.0], [13600.0, 1.0], [14600.0, 1.0], [15300.0, 1.0], [15700.0, 1.0], [16600.0, 1.0], [16700.0, 1.0], [18300.0, 1.0], [18500.0, 2.0], [19100.0, 1.0], [30600.0, 1.0], [30700.0, 1.0], [30800.0, 1.0], [34300.0, 1.0], [36300.0, 1.0], [45900.0, 1.0], [55000.0, 1.0], [60600.0, 2.0], [60200.0, 5.0], [60800.0, 1.0], [60700.0, 2.0], [400.0, 3.0], [500.0, 28.0]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 60800.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 3.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 147.0, "series": [{"data": [[0.0, 3.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 147.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 100.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 21.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 2.5, "minX": 1.64482236E12, "maxY": 5.0, "series": [{"data": [[1.6448226E12, 5.0], [1.64482242E12, 5.0], [1.64482272E12, 2.5], [1.64482254E12, 5.0], [1.64482236E12, 4.294117647058823], [1.64482266E12, 5.0], [1.64482248E12, 5.0]], "isOverall": false, "label": "Dashboard API", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64482272E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 4897.299212598426, "minX": 1.0, "maxY": 60730.0, "series": [{"data": [[2.0, 16105.75], [4.0, 10868.833333333334], [1.0, 60730.0], [5.0, 4897.299212598426], [3.0, 10692.166666666666]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}, {"data": [[4.874538745387455, 5529.273062730628]], "isOverall": false, "label": "Ingest API Firenoc-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 5.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 56.666666666666664, "minX": 1.64482236E12, "maxY": 595174.4833333333, "series": [{"data": [[1.6448226E12, 1436.9166666666667], [1.64482242E12, 2197.8333333333335], [1.64482272E12, 56.666666666666664], [1.64482254E12, 528.3833333333333], [1.64482236E12, 741.6333333333333], [1.64482266E12, 402.35], [1.64482248E12, 419.85]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.6448226E12, 394818.7166666667], [1.64482242E12, 595174.4833333333], [1.64482272E12, 23571.266666666666], [1.64482254E12, 153213.23333333334], [1.64482236E12, 200355.76666666666], [1.64482266E12, 111963.51666666666], [1.64482248E12, 117856.33333333333]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64482272E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 1164.8235294117649, "minX": 1.64482236E12, "maxY": 60606.5, "series": [{"data": [[1.6448226E12, 3989.4029850746274], [1.64482242E12, 2165.336633663367], [1.64482272E12, 60606.5], [1.64482254E12, 12949.884615384615], [1.64482236E12, 1164.8235294117649], [1.64482266E12, 8782.421052631578], [1.64482248E12, 11342.550000000001]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64482272E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 1163.5588235294117, "minX": 1.64482236E12, "maxY": 60606.5, "series": [{"data": [[1.6448226E12, 3989.179104477613], [1.64482242E12, 2165.118811881188], [1.64482272E12, 60606.5], [1.64482254E12, 12949.615384615383], [1.64482236E12, 1163.5588235294117], [1.64482266E12, 8782.315789473685], [1.64482248E12, 11342.350000000002]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64482272E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 105.5, "minX": 1.64482236E12, "maxY": 134.94117647058823, "series": [{"data": [[1.6448226E12, 112.67164179104479], [1.64482242E12, 119.03960396039604], [1.64482272E12, 105.5], [1.64482254E12, 111.42307692307692], [1.64482236E12, 134.94117647058823], [1.64482266E12, 108.05263157894736], [1.64482248E12, 124.05]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64482272E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 474.0, "minX": 1.64482236E12, "maxY": 55083.0, "series": [{"data": [[1.6448226E12, 18503.0], [1.64482242E12, 9247.0], [1.64482254E12, 55083.0], [1.64482236E12, 6229.0], [1.64482266E12, 14661.0], [1.64482248E12, 45935.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.6448226E12, 3660.6000000000017], [1.64482242E12, 4394.800000000001], [1.64482254E12, 36316.0], [1.64482236E12, 2501.5], [1.64482266E12, 13867.4], [1.64482248E12, 22478.999999999978]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.6448226E12, 18503.0], [1.64482242E12, 9245.119999999999], [1.64482254E12, 55083.0], [1.64482236E12, 6229.0], [1.64482266E12, 14661.0], [1.64482248E12, 45935.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.6448226E12, 4878.2], [1.64482242E12, 6872.149999999991], [1.64482254E12, 55083.0], [1.64482236E12, 4925.5], [1.64482266E12, 14661.0], [1.64482248E12, 45935.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.6448226E12, 492.0], [1.64482242E12, 548.0], [1.64482254E12, 481.0], [1.64482236E12, 474.0], [1.64482266E12, 1613.0], [1.64482248E12, 537.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.6448226E12, 1013.0], [1.64482242E12, 1516.0], [1.64482254E12, 598.0], [1.64482236E12, 722.0], [1.64482266E12, 2254.0], [1.64482248E12, 7111.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64482266E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 1138.5, "minX": 1.0, "maxY": 60259.5, "series": [{"data": [[2.0, 1270.0], [4.0, 1138.5], [1.0, 1371.0], [5.0, 1198.0], [3.0, 1235.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[1.0, 60259.5], [2.0, 30749.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 5.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 1138.0, "minX": 1.0, "maxY": 60259.5, "series": [{"data": [[2.0, 1270.0], [4.0, 1138.0], [1.0, 1371.0], [5.0, 1198.0], [3.0, 1235.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[1.0, 60259.5], [2.0, 30749.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 5.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.3, "minX": 1.64482236E12, "maxY": 1.6833333333333333, "series": [{"data": [[1.6448226E12, 1.1166666666666667], [1.64482242E12, 1.6833333333333333], [1.64482254E12, 0.45], [1.64482236E12, 0.65], [1.64482266E12, 0.3], [1.64482248E12, 0.31666666666666665]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64482266E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.64482236E12, "maxY": 1.6666666666666667, "series": [{"data": [[1.6448226E12, 1.05], [1.64482242E12, 1.6666666666666667], [1.64482254E12, 0.31666666666666665], [1.64482236E12, 0.5666666666666667], [1.64482266E12, 0.2833333333333333], [1.64482248E12, 0.2833333333333333]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.6448226E12, 0.03333333333333333], [1.64482242E12, 0.016666666666666666], [1.64482254E12, 0.05], [1.64482248E12, 0.03333333333333333]], "isOverall": false, "label": "400", "isController": false}, {"data": [[1.64482254E12, 0.03333333333333333], [1.64482266E12, 0.016666666666666666]], "isOverall": false, "label": "500", "isController": false}, {"data": [[1.6448226E12, 0.03333333333333333], [1.64482272E12, 0.06666666666666667], [1.64482254E12, 0.03333333333333333], [1.64482266E12, 0.016666666666666666], [1.64482248E12, 0.016666666666666666]], "isOverall": false, "label": "504", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64482272E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.64482236E12, "maxY": 1.6666666666666667, "series": [{"data": [[1.6448226E12, 1.05], [1.64482242E12, 1.6666666666666667], [1.64482254E12, 0.31666666666666665], [1.64482236E12, 0.5666666666666667], [1.64482266E12, 0.2833333333333333], [1.64482248E12, 0.2833333333333333]], "isOverall": false, "label": "Ingest API Firenoc-success", "isController": false}, {"data": [[1.6448226E12, 0.06666666666666667], [1.64482242E12, 0.016666666666666666], [1.64482272E12, 0.06666666666666667], [1.64482254E12, 0.11666666666666667], [1.64482266E12, 0.03333333333333333], [1.64482248E12, 0.05]], "isOverall": false, "label": "Ingest API Firenoc-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64482272E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.64482236E12, "maxY": 1.6666666666666667, "series": [{"data": [[1.6448226E12, 1.05], [1.64482242E12, 1.6666666666666667], [1.64482254E12, 0.31666666666666665], [1.64482236E12, 0.5666666666666667], [1.64482266E12, 0.2833333333333333], [1.64482248E12, 0.2833333333333333]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.6448226E12, 0.06666666666666667], [1.64482242E12, 0.016666666666666666], [1.64482272E12, 0.06666666666666667], [1.64482254E12, 0.11666666666666667], [1.64482266E12, 0.03333333333333333], [1.64482248E12, 0.05]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64482272E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

