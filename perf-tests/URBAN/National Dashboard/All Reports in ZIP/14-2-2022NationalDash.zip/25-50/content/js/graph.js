/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 230.0, "minX": 0.0, "maxY": 62262.0, "series": [{"data": [[0.0, 230.0], [0.1, 239.0], [0.2, 239.0], [0.3, 243.0], [0.4, 245.0], [0.5, 251.0], [0.6, 259.0], [0.7, 262.0], [0.8, 263.0], [0.9, 265.0], [1.0, 266.0], [1.1, 268.0], [1.2, 268.0], [1.3, 270.0], [1.4, 271.0], [1.5, 273.0], [1.6, 273.0], [1.7, 275.0], [1.8, 275.0], [1.9, 276.0], [2.0, 277.0], [2.1, 278.0], [2.2, 279.0], [2.3, 281.0], [2.4, 281.0], [2.5, 282.0], [2.6, 282.0], [2.7, 283.0], [2.8, 283.0], [2.9, 285.0], [3.0, 285.0], [3.1, 286.0], [3.2, 288.0], [3.3, 290.0], [3.4, 290.0], [3.5, 291.0], [3.6, 292.0], [3.7, 293.0], [3.8, 295.0], [3.9, 296.0], [4.0, 296.0], [4.1, 297.0], [4.2, 298.0], [4.3, 300.0], [4.4, 301.0], [4.5, 301.0], [4.6, 302.0], [4.7, 303.0], [4.8, 304.0], [4.9, 305.0], [5.0, 306.0], [5.1, 307.0], [5.2, 308.0], [5.3, 309.0], [5.4, 310.0], [5.5, 311.0], [5.6, 311.0], [5.7, 312.0], [5.8, 313.0], [5.9, 313.0], [6.0, 314.0], [6.1, 315.0], [6.2, 315.0], [6.3, 316.0], [6.4, 316.0], [6.5, 318.0], [6.6, 319.0], [6.7, 320.0], [6.8, 321.0], [6.9, 322.0], [7.0, 322.0], [7.1, 323.0], [7.2, 324.0], [7.3, 325.0], [7.4, 325.0], [7.5, 326.0], [7.6, 327.0], [7.7, 328.0], [7.8, 329.0], [7.9, 329.0], [8.0, 330.0], [8.1, 330.0], [8.2, 331.0], [8.3, 332.0], [8.4, 333.0], [8.5, 334.0], [8.6, 335.0], [8.7, 336.0], [8.8, 337.0], [8.9, 337.0], [9.0, 338.0], [9.1, 339.0], [9.2, 339.0], [9.3, 341.0], [9.4, 342.0], [9.5, 343.0], [9.6, 343.0], [9.7, 344.0], [9.8, 344.0], [9.9, 346.0], [10.0, 347.0], [10.1, 347.0], [10.2, 347.0], [10.3, 348.0], [10.4, 348.0], [10.5, 349.0], [10.6, 349.0], [10.7, 350.0], [10.8, 352.0], [10.9, 352.0], [11.0, 354.0], [11.1, 354.0], [11.2, 355.0], [11.3, 356.0], [11.4, 357.0], [11.5, 357.0], [11.6, 358.0], [11.7, 359.0], [11.8, 359.0], [11.9, 360.0], [12.0, 361.0], [12.1, 361.0], [12.2, 363.0], [12.3, 363.0], [12.4, 364.0], [12.5, 365.0], [12.6, 366.0], [12.7, 367.0], [12.8, 367.0], [12.9, 368.0], [13.0, 369.0], [13.1, 369.0], [13.2, 370.0], [13.3, 370.0], [13.4, 371.0], [13.5, 372.0], [13.6, 372.0], [13.7, 373.0], [13.8, 374.0], [13.9, 374.0], [14.0, 375.0], [14.1, 375.0], [14.2, 376.0], [14.3, 376.0], [14.4, 376.0], [14.5, 377.0], [14.6, 378.0], [14.7, 378.0], [14.8, 378.0], [14.9, 379.0], [15.0, 379.0], [15.1, 380.0], [15.2, 380.0], [15.3, 381.0], [15.4, 382.0], [15.5, 382.0], [15.6, 383.0], [15.7, 384.0], [15.8, 385.0], [15.9, 386.0], [16.0, 386.0], [16.1, 387.0], [16.2, 387.0], [16.3, 388.0], [16.4, 388.0], [16.5, 389.0], [16.6, 390.0], [16.7, 390.0], [16.8, 391.0], [16.9, 391.0], [17.0, 392.0], [17.1, 393.0], [17.2, 394.0], [17.3, 394.0], [17.4, 395.0], [17.5, 396.0], [17.6, 396.0], [17.7, 396.0], [17.8, 397.0], [17.9, 398.0], [18.0, 399.0], [18.1, 400.0], [18.2, 401.0], [18.3, 402.0], [18.4, 403.0], [18.5, 404.0], [18.6, 404.0], [18.7, 405.0], [18.8, 406.0], [18.9, 406.0], [19.0, 407.0], [19.1, 407.0], [19.2, 409.0], [19.3, 409.0], [19.4, 409.0], [19.5, 411.0], [19.6, 411.0], [19.7, 411.0], [19.8, 412.0], [19.9, 412.0], [20.0, 412.0], [20.1, 414.0], [20.2, 414.0], [20.3, 415.0], [20.4, 416.0], [20.5, 417.0], [20.6, 417.0], [20.7, 419.0], [20.8, 419.0], [20.9, 420.0], [21.0, 420.0], [21.1, 421.0], [21.2, 422.0], [21.3, 422.0], [21.4, 423.0], [21.5, 424.0], [21.6, 424.0], [21.7, 424.0], [21.8, 425.0], [21.9, 425.0], [22.0, 425.0], [22.1, 426.0], [22.2, 427.0], [22.3, 428.0], [22.4, 429.0], [22.5, 430.0], [22.6, 431.0], [22.7, 433.0], [22.8, 433.0], [22.9, 434.0], [23.0, 435.0], [23.1, 435.0], [23.2, 436.0], [23.3, 437.0], [23.4, 437.0], [23.5, 439.0], [23.6, 440.0], [23.7, 441.0], [23.8, 441.0], [23.9, 442.0], [24.0, 443.0], [24.1, 444.0], [24.2, 444.0], [24.3, 444.0], [24.4, 445.0], [24.5, 446.0], [24.6, 446.0], [24.7, 447.0], [24.8, 448.0], [24.9, 449.0], [25.0, 449.0], [25.1, 450.0], [25.2, 450.0], [25.3, 451.0], [25.4, 451.0], [25.5, 452.0], [25.6, 453.0], [25.7, 453.0], [25.8, 456.0], [25.9, 456.0], [26.0, 457.0], [26.1, 457.0], [26.2, 459.0], [26.3, 460.0], [26.4, 461.0], [26.5, 461.0], [26.6, 462.0], [26.7, 462.0], [26.8, 463.0], [26.9, 464.0], [27.0, 465.0], [27.1, 466.0], [27.2, 467.0], [27.3, 467.0], [27.4, 468.0], [27.5, 469.0], [27.6, 470.0], [27.7, 471.0], [27.8, 472.0], [27.9, 472.0], [28.0, 474.0], [28.1, 474.0], [28.2, 475.0], [28.3, 475.0], [28.4, 475.0], [28.5, 476.0], [28.6, 478.0], [28.7, 479.0], [28.8, 479.0], [28.9, 480.0], [29.0, 482.0], [29.1, 483.0], [29.2, 484.0], [29.3, 484.0], [29.4, 486.0], [29.5, 487.0], [29.6, 487.0], [29.7, 488.0], [29.8, 489.0], [29.9, 491.0], [30.0, 491.0], [30.1, 492.0], [30.2, 492.0], [30.3, 493.0], [30.4, 493.0], [30.5, 494.0], [30.6, 495.0], [30.7, 495.0], [30.8, 496.0], [30.9, 496.0], [31.0, 497.0], [31.1, 498.0], [31.2, 500.0], [31.3, 500.0], [31.4, 501.0], [31.5, 503.0], [31.6, 505.0], [31.7, 505.0], [31.8, 506.0], [31.9, 507.0], [32.0, 507.0], [32.1, 508.0], [32.2, 509.0], [32.3, 510.0], [32.4, 510.0], [32.5, 511.0], [32.6, 512.0], [32.7, 513.0], [32.8, 514.0], [32.9, 515.0], [33.0, 516.0], [33.1, 516.0], [33.2, 518.0], [33.3, 520.0], [33.4, 521.0], [33.5, 521.0], [33.6, 522.0], [33.7, 524.0], [33.8, 525.0], [33.9, 526.0], [34.0, 527.0], [34.1, 528.0], [34.2, 529.0], [34.3, 529.0], [34.4, 530.0], [34.5, 531.0], [34.6, 531.0], [34.7, 533.0], [34.8, 534.0], [34.9, 534.0], [35.0, 537.0], [35.1, 537.0], [35.2, 538.0], [35.3, 539.0], [35.4, 540.0], [35.5, 541.0], [35.6, 542.0], [35.7, 543.0], [35.8, 545.0], [35.9, 545.0], [36.0, 548.0], [36.1, 549.0], [36.2, 549.0], [36.3, 550.0], [36.4, 551.0], [36.5, 552.0], [36.6, 554.0], [36.7, 554.0], [36.8, 555.0], [36.9, 556.0], [37.0, 556.0], [37.1, 557.0], [37.2, 557.0], [37.3, 558.0], [37.4, 560.0], [37.5, 561.0], [37.6, 563.0], [37.7, 565.0], [37.8, 565.0], [37.9, 566.0], [38.0, 568.0], [38.1, 568.0], [38.2, 570.0], [38.3, 571.0], [38.4, 572.0], [38.5, 572.0], [38.6, 573.0], [38.7, 574.0], [38.8, 576.0], [38.9, 576.0], [39.0, 577.0], [39.1, 578.0], [39.2, 580.0], [39.3, 581.0], [39.4, 582.0], [39.5, 583.0], [39.6, 584.0], [39.7, 586.0], [39.8, 586.0], [39.9, 589.0], [40.0, 590.0], [40.1, 590.0], [40.2, 593.0], [40.3, 595.0], [40.4, 596.0], [40.5, 597.0], [40.6, 600.0], [40.7, 603.0], [40.8, 604.0], [40.9, 605.0], [41.0, 607.0], [41.1, 608.0], [41.2, 609.0], [41.3, 613.0], [41.4, 614.0], [41.5, 616.0], [41.6, 618.0], [41.7, 618.0], [41.8, 621.0], [41.9, 624.0], [42.0, 624.0], [42.1, 627.0], [42.2, 627.0], [42.3, 628.0], [42.4, 629.0], [42.5, 630.0], [42.6, 635.0], [42.7, 637.0], [42.8, 639.0], [42.9, 642.0], [43.0, 644.0], [43.1, 651.0], [43.2, 652.0], [43.3, 656.0], [43.4, 658.0], [43.5, 660.0], [43.6, 662.0], [43.7, 663.0], [43.8, 664.0], [43.9, 666.0], [44.0, 670.0], [44.1, 671.0], [44.2, 673.0], [44.3, 675.0], [44.4, 678.0], [44.5, 678.0], [44.6, 680.0], [44.7, 683.0], [44.8, 687.0], [44.9, 687.0], [45.0, 690.0], [45.1, 691.0], [45.2, 693.0], [45.3, 694.0], [45.4, 694.0], [45.5, 698.0], [45.6, 700.0], [45.7, 701.0], [45.8, 702.0], [45.9, 704.0], [46.0, 704.0], [46.1, 709.0], [46.2, 712.0], [46.3, 713.0], [46.4, 715.0], [46.5, 719.0], [46.6, 720.0], [46.7, 720.0], [46.8, 723.0], [46.9, 729.0], [47.0, 732.0], [47.1, 733.0], [47.2, 735.0], [47.3, 736.0], [47.4, 738.0], [47.5, 739.0], [47.6, 741.0], [47.7, 745.0], [47.8, 745.0], [47.9, 747.0], [48.0, 754.0], [48.1, 757.0], [48.2, 757.0], [48.3, 761.0], [48.4, 764.0], [48.5, 769.0], [48.6, 771.0], [48.7, 776.0], [48.8, 777.0], [48.9, 779.0], [49.0, 781.0], [49.1, 784.0], [49.2, 788.0], [49.3, 790.0], [49.4, 793.0], [49.5, 795.0], [49.6, 796.0], [49.7, 798.0], [49.8, 800.0], [49.9, 803.0], [50.0, 804.0], [50.1, 807.0], [50.2, 810.0], [50.3, 813.0], [50.4, 815.0], [50.5, 817.0], [50.6, 818.0], [50.7, 819.0], [50.8, 821.0], [50.9, 822.0], [51.0, 824.0], [51.1, 827.0], [51.2, 828.0], [51.3, 832.0], [51.4, 834.0], [51.5, 836.0], [51.6, 838.0], [51.7, 838.0], [51.8, 839.0], [51.9, 840.0], [52.0, 843.0], [52.1, 844.0], [52.2, 844.0], [52.3, 848.0], [52.4, 851.0], [52.5, 852.0], [52.6, 852.0], [52.7, 856.0], [52.8, 857.0], [52.9, 860.0], [53.0, 862.0], [53.1, 864.0], [53.2, 866.0], [53.3, 870.0], [53.4, 871.0], [53.5, 875.0], [53.6, 877.0], [53.7, 877.0], [53.8, 878.0], [53.9, 881.0], [54.0, 883.0], [54.1, 884.0], [54.2, 888.0], [54.3, 889.0], [54.4, 892.0], [54.5, 893.0], [54.6, 897.0], [54.7, 904.0], [54.8, 906.0], [54.9, 907.0], [55.0, 909.0], [55.1, 913.0], [55.2, 915.0], [55.3, 920.0], [55.4, 921.0], [55.5, 923.0], [55.6, 925.0], [55.7, 926.0], [55.8, 928.0], [55.9, 930.0], [56.0, 932.0], [56.1, 935.0], [56.2, 937.0], [56.3, 939.0], [56.4, 941.0], [56.5, 944.0], [56.6, 945.0], [56.7, 946.0], [56.8, 948.0], [56.9, 949.0], [57.0, 951.0], [57.1, 954.0], [57.2, 957.0], [57.3, 958.0], [57.4, 958.0], [57.5, 960.0], [57.6, 962.0], [57.7, 964.0], [57.8, 965.0], [57.9, 968.0], [58.0, 972.0], [58.1, 972.0], [58.2, 974.0], [58.3, 977.0], [58.4, 978.0], [58.5, 978.0], [58.6, 981.0], [58.7, 983.0], [58.8, 985.0], [58.9, 988.0], [59.0, 989.0], [59.1, 991.0], [59.2, 993.0], [59.3, 994.0], [59.4, 995.0], [59.5, 998.0], [59.6, 999.0], [59.7, 1001.0], [59.8, 1003.0], [59.9, 1005.0], [60.0, 1006.0], [60.1, 1009.0], [60.2, 1012.0], [60.3, 1014.0], [60.4, 1016.0], [60.5, 1021.0], [60.6, 1025.0], [60.7, 1025.0], [60.8, 1029.0], [60.9, 1030.0], [61.0, 1033.0], [61.1, 1034.0], [61.2, 1036.0], [61.3, 1041.0], [61.4, 1042.0], [61.5, 1043.0], [61.6, 1046.0], [61.7, 1051.0], [61.8, 1052.0], [61.9, 1057.0], [62.0, 1061.0], [62.1, 1064.0], [62.2, 1065.0], [62.3, 1066.0], [62.4, 1067.0], [62.5, 1068.0], [62.6, 1069.0], [62.7, 1075.0], [62.8, 1077.0], [62.9, 1079.0], [63.0, 1081.0], [63.1, 1085.0], [63.2, 1091.0], [63.3, 1092.0], [63.4, 1098.0], [63.5, 1100.0], [63.6, 1104.0], [63.7, 1107.0], [63.8, 1110.0], [63.9, 1111.0], [64.0, 1112.0], [64.1, 1116.0], [64.2, 1118.0], [64.3, 1121.0], [64.4, 1121.0], [64.5, 1124.0], [64.6, 1125.0], [64.7, 1129.0], [64.8, 1129.0], [64.9, 1132.0], [65.0, 1134.0], [65.1, 1137.0], [65.2, 1139.0], [65.3, 1144.0], [65.4, 1147.0], [65.5, 1147.0], [65.6, 1156.0], [65.7, 1156.0], [65.8, 1159.0], [65.9, 1161.0], [66.0, 1165.0], [66.1, 1168.0], [66.2, 1174.0], [66.3, 1176.0], [66.4, 1179.0], [66.5, 1184.0], [66.6, 1185.0], [66.7, 1186.0], [66.8, 1187.0], [66.9, 1189.0], [67.0, 1191.0], [67.1, 1195.0], [67.2, 1196.0], [67.3, 1197.0], [67.4, 1201.0], [67.5, 1204.0], [67.6, 1212.0], [67.7, 1219.0], [67.8, 1223.0], [67.9, 1233.0], [68.0, 1241.0], [68.1, 1247.0], [68.2, 1252.0], [68.3, 1260.0], [68.4, 1263.0], [68.5, 1267.0], [68.6, 1272.0], [68.7, 1283.0], [68.8, 1289.0], [68.9, 1293.0], [69.0, 1302.0], [69.1, 1308.0], [69.2, 1310.0], [69.3, 1315.0], [69.4, 1325.0], [69.5, 1330.0], [69.6, 1335.0], [69.7, 1341.0], [69.8, 1346.0], [69.9, 1348.0], [70.0, 1350.0], [70.1, 1356.0], [70.2, 1357.0], [70.3, 1358.0], [70.4, 1367.0], [70.5, 1373.0], [70.6, 1375.0], [70.7, 1377.0], [70.8, 1383.0], [70.9, 1388.0], [71.0, 1389.0], [71.1, 1396.0], [71.2, 1400.0], [71.3, 1406.0], [71.4, 1408.0], [71.5, 1409.0], [71.6, 1411.0], [71.7, 1412.0], [71.8, 1416.0], [71.9, 1419.0], [72.0, 1423.0], [72.1, 1425.0], [72.2, 1430.0], [72.3, 1433.0], [72.4, 1438.0], [72.5, 1442.0], [72.6, 1451.0], [72.7, 1461.0], [72.8, 1463.0], [72.9, 1466.0], [73.0, 1473.0], [73.1, 1475.0], [73.2, 1478.0], [73.3, 1480.0], [73.4, 1482.0], [73.5, 1486.0], [73.6, 1490.0], [73.7, 1502.0], [73.8, 1507.0], [73.9, 1511.0], [74.0, 1515.0], [74.1, 1525.0], [74.2, 1533.0], [74.3, 1533.0], [74.4, 1535.0], [74.5, 1538.0], [74.6, 1547.0], [74.7, 1548.0], [74.8, 1559.0], [74.9, 1561.0], [75.0, 1565.0], [75.1, 1580.0], [75.2, 1587.0], [75.3, 1590.0], [75.4, 1593.0], [75.5, 1600.0], [75.6, 1601.0], [75.7, 1602.0], [75.8, 1605.0], [75.9, 1608.0], [76.0, 1618.0], [76.1, 1621.0], [76.2, 1627.0], [76.3, 1636.0], [76.4, 1638.0], [76.5, 1640.0], [76.6, 1644.0], [76.7, 1652.0], [76.8, 1653.0], [76.9, 1658.0], [77.0, 1665.0], [77.1, 1669.0], [77.2, 1674.0], [77.3, 1676.0], [77.4, 1676.0], [77.5, 1682.0], [77.6, 1684.0], [77.7, 1687.0], [77.8, 1700.0], [77.9, 1714.0], [78.0, 1722.0], [78.1, 1731.0], [78.2, 1734.0], [78.3, 1742.0], [78.4, 1745.0], [78.5, 1749.0], [78.6, 1761.0], [78.7, 1762.0], [78.8, 1767.0], [78.9, 1773.0], [79.0, 1778.0], [79.1, 1783.0], [79.2, 1786.0], [79.3, 1791.0], [79.4, 1798.0], [79.5, 1807.0], [79.6, 1812.0], [79.7, 1822.0], [79.8, 1829.0], [79.9, 1834.0], [80.0, 1845.0], [80.1, 1853.0], [80.2, 1857.0], [80.3, 1863.0], [80.4, 1871.0], [80.5, 1874.0], [80.6, 1877.0], [80.7, 1883.0], [80.8, 1886.0], [80.9, 1887.0], [81.0, 1908.0], [81.1, 1917.0], [81.2, 1920.0], [81.3, 1925.0], [81.4, 1944.0], [81.5, 1948.0], [81.6, 1956.0], [81.7, 1959.0], [81.8, 1968.0], [81.9, 1975.0], [82.0, 1981.0], [82.1, 1997.0], [82.2, 2003.0], [82.3, 2004.0], [82.4, 2010.0], [82.5, 2022.0], [82.6, 2037.0], [82.7, 2047.0], [82.8, 2048.0], [82.9, 2050.0], [83.0, 2051.0], [83.1, 2059.0], [83.2, 2067.0], [83.3, 2078.0], [83.4, 2095.0], [83.5, 2100.0], [83.6, 2112.0], [83.7, 2113.0], [83.8, 2122.0], [83.9, 2127.0], [84.0, 2138.0], [84.1, 2145.0], [84.2, 2157.0], [84.3, 2158.0], [84.4, 2166.0], [84.5, 2175.0], [84.6, 2176.0], [84.7, 2193.0], [84.8, 2212.0], [84.9, 2223.0], [85.0, 2229.0], [85.1, 2231.0], [85.2, 2245.0], [85.3, 2255.0], [85.4, 2264.0], [85.5, 2272.0], [85.6, 2294.0], [85.7, 2308.0], [85.8, 2325.0], [85.9, 2333.0], [86.0, 2354.0], [86.1, 2359.0], [86.2, 2370.0], [86.3, 2375.0], [86.4, 2386.0], [86.5, 2394.0], [86.6, 2405.0], [86.7, 2419.0], [86.8, 2429.0], [86.9, 2436.0], [87.0, 2449.0], [87.1, 2456.0], [87.2, 2464.0], [87.3, 2469.0], [87.4, 2475.0], [87.5, 2487.0], [87.6, 2493.0], [87.7, 2508.0], [87.8, 2520.0], [87.9, 2526.0], [88.0, 2546.0], [88.1, 2557.0], [88.2, 2561.0], [88.3, 2569.0], [88.4, 2580.0], [88.5, 2596.0], [88.6, 2602.0], [88.7, 2653.0], [88.8, 2674.0], [88.9, 2692.0], [89.0, 2708.0], [89.1, 2726.0], [89.2, 2753.0], [89.3, 2761.0], [89.4, 2775.0], [89.5, 2810.0], [89.6, 2824.0], [89.7, 2859.0], [89.8, 2865.0], [89.9, 2890.0], [90.0, 2918.0], [90.1, 2937.0], [90.2, 2950.0], [90.3, 3013.0], [90.4, 3033.0], [90.5, 3071.0], [90.6, 3108.0], [90.7, 3136.0], [90.8, 3160.0], [90.9, 3202.0], [91.0, 3245.0], [91.1, 3260.0], [91.2, 3280.0], [91.3, 3346.0], [91.4, 3352.0], [91.5, 3391.0], [91.6, 3417.0], [91.7, 3437.0], [91.8, 3485.0], [91.9, 3499.0], [92.0, 3535.0], [92.1, 3577.0], [92.2, 3677.0], [92.3, 3688.0], [92.4, 3719.0], [92.5, 3756.0], [92.6, 3793.0], [92.7, 3799.0], [92.8, 3840.0], [92.9, 3876.0], [93.0, 3893.0], [93.1, 3934.0], [93.2, 3995.0], [93.3, 4083.0], [93.4, 4133.0], [93.5, 4206.0], [93.6, 4375.0], [93.7, 4408.0], [93.8, 4488.0], [93.9, 4566.0], [94.0, 4599.0], [94.1, 4614.0], [94.2, 4696.0], [94.3, 4845.0], [94.4, 5008.0], [94.5, 5045.0], [94.6, 5086.0], [94.7, 5196.0], [94.8, 5285.0], [94.9, 5452.0], [95.0, 5508.0], [95.1, 5858.0], [95.2, 6077.0], [95.3, 6404.0], [95.4, 7000.0], [95.5, 7288.0], [95.6, 7317.0], [95.7, 7467.0], [95.8, 7870.0], [95.9, 8044.0], [96.0, 8122.0], [96.1, 8421.0], [96.2, 8724.0], [96.3, 9134.0], [96.4, 9348.0], [96.5, 9651.0], [96.6, 10054.0], [96.7, 10617.0], [96.8, 10891.0], [96.9, 11241.0], [97.0, 11592.0], [97.1, 12115.0], [97.2, 12594.0], [97.3, 13561.0], [97.4, 15496.0], [97.5, 16987.0], [97.6, 18731.0], [97.7, 20101.0], [97.8, 20411.0], [97.9, 23239.0], [98.0, 23800.0], [98.1, 25021.0], [98.2, 29065.0], [98.3, 53889.0], [98.4, 60258.0], [98.5, 60261.0], [98.6, 60267.0], [98.7, 60272.0], [98.8, 60285.0], [98.9, 60295.0], [99.0, 60305.0], [99.1, 60330.0], [99.2, 60352.0], [99.3, 60518.0], [99.4, 60710.0], [99.5, 60893.0], [99.6, 61006.0], [99.7, 61412.0], [99.8, 61808.0], [99.9, 61984.0]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 200.0, "maxY": 376.0, "series": [{"data": [[33300.0, 1.0], [200.0, 117.0], [60300.0, 8.0], [60700.0, 3.0], [59900.0, 1.0], [60500.0, 1.0], [60900.0, 2.0], [61300.0, 1.0], [61500.0, 1.0], [61900.0, 3.0], [300.0, 376.0], [400.0, 358.0], [500.0, 256.0], [600.0, 136.0], [700.0, 114.0], [800.0, 134.0], [900.0, 135.0], [1000.0, 106.0], [1100.0, 106.0], [1200.0, 44.0], [1300.0, 60.0], [1400.0, 66.0], [1500.0, 51.0], [1600.0, 63.0], [1700.0, 45.0], [1800.0, 42.0], [1900.0, 32.0], [2000.0, 36.0], [2100.0, 36.0], [2300.0, 24.0], [2200.0, 24.0], [2400.0, 30.0], [2500.0, 24.0], [2600.0, 12.0], [2700.0, 13.0], [2800.0, 14.0], [2900.0, 9.0], [3000.0, 7.0], [3100.0, 9.0], [3200.0, 9.0], [3300.0, 10.0], [3400.0, 10.0], [3500.0, 6.0], [3700.0, 10.0], [3600.0, 5.0], [3800.0, 10.0], [3900.0, 4.0], [4000.0, 3.0], [4100.0, 4.0], [4300.0, 3.0], [4200.0, 2.0], [4600.0, 5.0], [4400.0, 4.0], [4500.0, 6.0], [4800.0, 2.0], [4700.0, 1.0], [5000.0, 6.0], [4900.0, 2.0], [5100.0, 3.0], [5200.0, 3.0], [5300.0, 1.0], [5400.0, 3.0], [5600.0, 1.0], [5500.0, 2.0], [5800.0, 1.0], [6000.0, 2.0], [5900.0, 2.0], [6400.0, 1.0], [6600.0, 1.0], [6800.0, 1.0], [7000.0, 2.0], [7400.0, 2.0], [7200.0, 2.0], [7300.0, 3.0], [7500.0, 1.0], [7900.0, 2.0], [7700.0, 1.0], [7800.0, 1.0], [8000.0, 2.0], [8100.0, 1.0], [8400.0, 2.0], [8700.0, 1.0], [8200.0, 1.0], [8300.0, 1.0], [8600.0, 1.0], [9000.0, 1.0], [9100.0, 1.0], [9200.0, 1.0], [8800.0, 1.0], [9500.0, 1.0], [9600.0, 3.0], [9700.0, 1.0], [9300.0, 1.0], [10000.0, 1.0], [10600.0, 3.0], [10300.0, 1.0], [10800.0, 1.0], [11200.0, 2.0], [10900.0, 1.0], [11500.0, 1.0], [11300.0, 1.0], [11400.0, 1.0], [12100.0, 2.0], [11900.0, 1.0], [12500.0, 1.0], [12700.0, 1.0], [12400.0, 1.0], [13500.0, 2.0], [13800.0, 1.0], [14400.0, 1.0], [15400.0, 1.0], [16600.0, 1.0], [16900.0, 1.0], [18300.0, 2.0], [18700.0, 1.0], [18800.0, 1.0], [20400.0, 2.0], [20100.0, 1.0], [19500.0, 1.0], [21300.0, 1.0], [20500.0, 1.0], [23200.0, 1.0], [24400.0, 1.0], [23600.0, 2.0], [23800.0, 1.0], [25000.0, 1.0], [24900.0, 1.0], [26900.0, 1.0], [29000.0, 1.0], [44000.0, 1.0], [53800.0, 1.0], [60800.0, 1.0], [60200.0, 17.0], [60600.0, 2.0], [61000.0, 1.0], [61400.0, 1.0], [62200.0, 1.0], [61600.0, 1.0], [62000.0, 1.0], [61800.0, 1.0]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 62200.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 2.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 2490.0, "series": [{"data": [[0.0, 2.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 42.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 194.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 2490.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 3.0, "minX": 1.64482188E12, "maxY": 25.0, "series": [{"data": [[1.64482212E12, 25.0], [1.64482194E12, 25.0], [1.64482224E12, 3.0], [1.64482206E12, 25.0], [1.64482188E12, 24.18655462184873], [1.64482218E12, 17.25], [1.644822E12, 25.0]], "isOverall": false, "label": "Dashboard API", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64482224E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 738.0, "minX": 1.0, "maxY": 60352.0, "series": [{"data": [[2.0, 60270.0], [3.0, 30444.0], [4.0, 60352.0], [5.0, 15548.5], [6.0, 20448.0], [7.0, 31168.5], [8.0, 738.0], [9.0, 981.0], [10.0, 31593.0], [11.0, 851.0], [12.0, 31331.5], [13.0, 21272.333333333332], [14.0, 17172.75], [15.0, 16319.5], [16.0, 21710.333333333332], [1.0, 60263.0], [17.0, 13383.6], [18.0, 31197.0], [19.0, 30858.5], [20.0, 7702.5], [21.0, 21195.0], [22.0, 9809.571428571428], [23.0, 15844.666666666666], [24.0, 8624.5], [25.0, 1994.1456054319162]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}, {"data": [[24.71407624633432, 2484.177785923757]], "isOverall": false, "label": "Ingest API Firenoc-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 25.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 70.83333333333333, "minX": 1.64482188E12, "maxY": 5103179.233333333, "series": [{"data": [[1.64482212E12, 8232.666666666666], [1.64482194E12, 12915.883333333333], [1.64482224E12, 70.83333333333333], [1.64482206E12, 8796.383333333333], [1.64482188E12, 9287.366666666667], [1.64482218E12, 389.3], [1.644822E12, 933.2]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.64482212E12, 3376583.95], [1.64482194E12, 5103179.233333333], [1.64482224E12, 29464.083333333332], [1.64482206E12, 3653546.3333333335], [1.64482188E12, 3506225.9166666665], [1.64482218E12, 141427.6], [1.644822E12, 253391.11666666667]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64482224E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 1088.8168202764978, "minX": 1.64482188E12, "maxY": 60286.6, "series": [{"data": [[1.64482212E12, 1743.078534031415], [1.64482194E12, 1088.8168202764978], [1.64482224E12, 60286.6], [1.64482206E12, 3665.6370967741977], [1.64482188E12, 1114.589915966385], [1.64482218E12, 49947.24999999999], [1.644822E12, 9230.627906976746]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64482224E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 1068.8732718894003, "minX": 1.64482188E12, "maxY": 60286.6, "series": [{"data": [[1.64482212E12, 1742.9703315881327], [1.64482194E12, 1068.8732718894003], [1.64482224E12, 60286.6], [1.64482206E12, 3665.5967741935483], [1.64482188E12, 1114.3647058823547], [1.64482218E12, 49947.24999999999], [1.644822E12, 9230.488372093021]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64482224E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 106.8, "minX": 1.64482188E12, "maxY": 832.3699825479932, "series": [{"data": [[1.64482212E12, 832.3699825479932], [1.64482194E12, 312.3652073732716], [1.64482224E12, 106.8], [1.64482206E12, 201.91612903225814], [1.64482188E12, 318.5932773109244], [1.64482218E12, 356.08333333333326], [1.644822E12, 147.72093023255812]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64482224E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 411.0, "minX": 1.64482188E12, "maxY": 33380.0, "series": [{"data": [[1.64482212E12, 11470.0], [1.64482194E12, 12594.0], [1.64482188E12, 6077.0], [1.64482218E12, 33380.0], [1.644822E12, 23239.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.64482212E12, 11246.2], [1.64482194E12, 8189.700000000002], [1.64482188E12, 3692.1999999999994], [1.64482218E12, 33380.0], [1.644822E12, 18333.2]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.64482212E12, 11470.0], [1.64482194E12, 12594.0], [1.64482188E12, 5981.959999999996], [1.64482218E12, 33380.0], [1.644822E12, 23239.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.64482212E12, 11470.0], [1.64482194E12, 11067.55], [1.64482188E12, 4568.4], [1.64482218E12, 33380.0], [1.644822E12, 20958.850000000002]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.64482212E12, 5508.0], [1.64482194E12, 834.0], [1.64482188E12, 411.0], [1.64482218E12, 8804.0], [1.644822E12, 2158.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.64482212E12, 8421.0], [1.64482194E12, 3869.0], [1.64482188E12, 1742.0], [1.64482218E12, 14907.5], [1.644822E12, 8086.5]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64482218E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 431.5, "minX": 1.0, "maxY": 60285.0, "series": [{"data": [[1.0, 15496.0], [2.0, 8827.5], [4.0, 5235.0], [8.0, 3019.0], [9.0, 2636.0], [5.0, 2177.0], [11.0, 1853.0], [6.0, 3208.0], [3.0, 5660.0], [27.0, 6077.0], [7.0, 1917.0], [15.0, 2122.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[2.0, 60285.0], [3.0, 60272.0], [4.0, 3234.0], [5.0, 1784.0], [7.0, 1601.0], [8.0, 2271.5], [9.0, 1948.0], [10.0, 1473.5], [11.0, 1132.0], [12.0, 1022.0], [13.0, 865.0], [14.0, 944.0], [15.0, 757.0], [16.0, 723.5], [1.0, 60263.0], [17.0, 725.5], [18.0, 736.5], [19.0, 556.0], [20.0, 481.5], [21.0, 516.0], [22.0, 503.0], [23.0, 434.0], [24.0, 995.5], [25.0, 468.5], [26.0, 475.0], [27.0, 1776.5], [28.0, 431.5]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 28.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 431.5, "minX": 1.0, "maxY": 60285.0, "series": [{"data": [[1.0, 15495.0], [2.0, 8827.5], [4.0, 5235.0], [8.0, 3019.0], [9.0, 2636.0], [5.0, 2177.0], [11.0, 1853.0], [6.0, 3208.0], [3.0, 5660.0], [27.0, 6077.0], [7.0, 1917.0], [15.0, 2122.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[2.0, 60285.0], [3.0, 60272.0], [4.0, 3234.0], [5.0, 1784.0], [7.0, 1601.0], [8.0, 2271.5], [9.0, 1948.0], [10.0, 1473.5], [11.0, 1132.0], [12.0, 1022.0], [13.0, 865.0], [14.0, 944.0], [15.0, 757.0], [16.0, 723.5], [1.0, 60263.0], [17.0, 725.5], [18.0, 736.5], [19.0, 556.0], [20.0, 481.5], [21.0, 516.0], [22.0, 503.0], [23.0, 434.0], [24.0, 984.0], [25.0, 468.5], [26.0, 474.5], [27.0, 1776.5], [28.0, 431.5]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 28.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.1, "minX": 1.64482188E12, "maxY": 14.483333333333333, "series": [{"data": [[1.64482212E12, 9.65], [1.64482194E12, 14.483333333333333], [1.64482206E12, 10.2], [1.64482188E12, 10.316666666666666], [1.64482218E12, 0.1], [1.644822E12, 0.7166666666666667]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64482218E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.64482188E12, "maxY": 13.3, "series": [{"data": [[1.64482212E12, 0.18333333333333332], [1.64482194E12, 1.1333333333333333], [1.64482188E12, 1.85], [1.64482218E12, 0.1], [1.644822E12, 0.7]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.64482212E12, 0.016666666666666666], [1.64482188E12, 0.016666666666666666], [1.64482218E12, 0.016666666666666666], [1.644822E12, 0.016666666666666666]], "isOverall": false, "label": "400", "isController": false}, {"data": [[1.64482206E12, 0.9333333333333333], [1.64482188E12, 0.9333333333333333]], "isOverall": false, "label": "502", "isController": false}, {"data": [[1.64482212E12, 9.35], [1.64482194E12, 13.3], [1.64482206E12, 9.016666666666667], [1.64482188E12, 7.116666666666666]], "isOverall": false, "label": "503", "isController": false}, {"data": [[1.64482224E12, 0.08333333333333333], [1.64482206E12, 0.38333333333333336], [1.64482218E12, 0.2833333333333333]], "isOverall": false, "label": "504", "isController": false}, {"data": [[1.64482194E12, 0.03333333333333333]], "isOverall": false, "label": "Non HTTP response code: java.net.SocketException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64482224E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.64482188E12, "maxY": 13.333333333333334, "series": [{"data": [[1.64482212E12, 0.18333333333333332], [1.64482194E12, 1.1333333333333333], [1.64482188E12, 1.85], [1.64482218E12, 0.1], [1.644822E12, 0.7]], "isOverall": false, "label": "Ingest API Firenoc-success", "isController": false}, {"data": [[1.64482212E12, 9.366666666666667], [1.64482194E12, 13.333333333333334], [1.64482224E12, 0.08333333333333333], [1.64482206E12, 10.333333333333334], [1.64482188E12, 8.066666666666666], [1.64482218E12, 0.3], [1.644822E12, 0.016666666666666666]], "isOverall": false, "label": "Ingest API Firenoc-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64482224E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.64482188E12, "maxY": 13.333333333333334, "series": [{"data": [[1.64482212E12, 0.18333333333333332], [1.64482194E12, 1.1333333333333333], [1.64482188E12, 1.85], [1.64482218E12, 0.1], [1.644822E12, 0.7]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.64482212E12, 9.366666666666667], [1.64482194E12, 13.333333333333334], [1.64482224E12, 0.08333333333333333], [1.64482206E12, 10.333333333333334], [1.64482188E12, 8.066666666666666], [1.64482218E12, 0.3], [1.644822E12, 0.016666666666666666]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64482224E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

