/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 4569.0, "minX": 0.0, "maxY": 17691.0, "series": [{"data": [[0.0, 4569.0], [0.1, 4769.0], [0.2, 4964.0], [0.3, 5175.0], [0.4, 5196.0], [0.5, 5243.0], [0.6, 5413.0], [0.7, 5421.0], [0.8, 5422.0], [0.9, 5427.0], [1.0, 5454.0], [1.1, 5470.0], [1.2, 5516.0], [1.3, 5516.0], [1.4, 5531.0], [1.5, 5565.0], [1.6, 5590.0], [1.7, 5648.0], [1.8, 5668.0], [1.9, 5695.0], [2.0, 5695.0], [2.1, 5718.0], [2.2, 5731.0], [2.3, 5752.0], [2.4, 5831.0], [2.5, 5838.0], [2.6, 5855.0], [2.7, 5869.0], [2.8, 5887.0], [2.9, 5907.0], [3.0, 5920.0], [3.1, 5920.0], [3.2, 5922.0], [3.3, 5965.0], [3.4, 5990.0], [3.5, 5992.0], [3.6, 6012.0], [3.7, 6014.0], [3.8, 6017.0], [3.9, 6033.0], [4.0, 6042.0], [4.1, 6064.0], [4.2, 6091.0], [4.3, 6097.0], [4.4, 6117.0], [4.5, 6141.0], [4.6, 6141.0], [4.7, 6154.0], [4.8, 6177.0], [4.9, 6183.0], [5.0, 6188.0], [5.1, 6200.0], [5.2, 6200.0], [5.3, 6201.0], [5.4, 6202.0], [5.5, 6205.0], [5.6, 6224.0], [5.7, 6234.0], [5.8, 6235.0], [5.9, 6260.0], [6.0, 6260.0], [6.1, 6269.0], [6.2, 6273.0], [6.3, 6287.0], [6.4, 6293.0], [6.5, 6297.0], [6.6, 6303.0], [6.7, 6307.0], [6.8, 6324.0], [6.9, 6327.0], [7.0, 6350.0], [7.1, 6371.0], [7.2, 6377.0], [7.3, 6379.0], [7.4, 6387.0], [7.5, 6402.0], [7.6, 6416.0], [7.7, 6439.0], [7.8, 6440.0], [7.9, 6443.0], [8.0, 6485.0], [8.1, 6509.0], [8.2, 6519.0], [8.3, 6530.0], [8.4, 6531.0], [8.5, 6545.0], [8.6, 6550.0], [8.7, 6555.0], [8.8, 6571.0], [8.9, 6584.0], [9.0, 6600.0], [9.1, 6650.0], [9.2, 6655.0], [9.3, 6658.0], [9.4, 6672.0], [9.5, 6704.0], [9.6, 6707.0], [9.7, 6723.0], [9.8, 6726.0], [9.9, 6730.0], [10.0, 6732.0], [10.1, 6744.0], [10.2, 6752.0], [10.3, 6759.0], [10.4, 6769.0], [10.5, 6783.0], [10.6, 6802.0], [10.7, 6809.0], [10.8, 6820.0], [10.9, 6831.0], [11.0, 6831.0], [11.1, 6842.0], [11.2, 6869.0], [11.3, 6874.0], [11.4, 6883.0], [11.5, 6898.0], [11.6, 6908.0], [11.7, 6910.0], [11.8, 6911.0], [11.9, 6915.0], [12.0, 6934.0], [12.1, 6937.0], [12.2, 6944.0], [12.3, 6951.0], [12.4, 6996.0], [12.5, 6996.0], [12.6, 6998.0], [12.7, 7012.0], [12.8, 7016.0], [12.9, 7018.0], [13.0, 7027.0], [13.1, 7029.0], [13.2, 7037.0], [13.3, 7039.0], [13.4, 7060.0], [13.5, 7080.0], [13.6, 7086.0], [13.7, 7125.0], [13.8, 7140.0], [13.9, 7143.0], [14.0, 7146.0], [14.1, 7150.0], [14.2, 7156.0], [14.3, 7160.0], [14.4, 7171.0], [14.5, 7186.0], [14.6, 7226.0], [14.7, 7233.0], [14.8, 7236.0], [14.9, 7237.0], [15.0, 7249.0], [15.1, 7250.0], [15.2, 7256.0], [15.3, 7263.0], [15.4, 7264.0], [15.5, 7269.0], [15.6, 7273.0], [15.7, 7288.0], [15.8, 7292.0], [15.9, 7335.0], [16.0, 7346.0], [16.1, 7363.0], [16.2, 7376.0], [16.3, 7381.0], [16.4, 7384.0], [16.5, 7394.0], [16.6, 7396.0], [16.7, 7396.0], [16.8, 7403.0], [16.9, 7405.0], [17.0, 7406.0], [17.1, 7417.0], [17.2, 7419.0], [17.3, 7435.0], [17.4, 7441.0], [17.5, 7443.0], [17.6, 7454.0], [17.7, 7475.0], [17.8, 7482.0], [17.9, 7486.0], [18.0, 7488.0], [18.1, 7492.0], [18.2, 7502.0], [18.3, 7507.0], [18.4, 7541.0], [18.5, 7567.0], [18.6, 7585.0], [18.7, 7611.0], [18.8, 7650.0], [18.9, 7658.0], [19.0, 7666.0], [19.1, 7678.0], [19.2, 7685.0], [19.3, 7691.0], [19.4, 7702.0], [19.5, 7711.0], [19.6, 7752.0], [19.7, 7758.0], [19.8, 7758.0], [19.9, 7769.0], [20.0, 7789.0], [20.1, 7809.0], [20.2, 7821.0], [20.3, 7831.0], [20.4, 7872.0], [20.5, 7873.0], [20.6, 7895.0], [20.7, 7926.0], [20.8, 7927.0], [20.9, 7952.0], [21.0, 7967.0], [21.1, 7995.0], [21.2, 8017.0], [21.3, 8035.0], [21.4, 8040.0], [21.5, 8074.0], [21.6, 8078.0], [21.7, 8079.0], [21.8, 8090.0], [21.9, 8094.0], [22.0, 8175.0], [22.1, 8183.0], [22.2, 8187.0], [22.3, 8195.0], [22.4, 8197.0], [22.5, 8203.0], [22.6, 8213.0], [22.7, 8221.0], [22.8, 8237.0], [22.9, 8239.0], [23.0, 8242.0], [23.1, 8242.0], [23.2, 8254.0], [23.3, 8262.0], [23.4, 8263.0], [23.5, 8272.0], [23.6, 8276.0], [23.7, 8296.0], [23.8, 8327.0], [23.9, 8339.0], [24.0, 8347.0], [24.1, 8375.0], [24.2, 8380.0], [24.3, 8400.0], [24.4, 8407.0], [24.5, 8427.0], [24.6, 8448.0], [24.7, 8456.0], [24.8, 8460.0], [24.9, 8480.0], [25.0, 8498.0], [25.1, 8518.0], [25.2, 8526.0], [25.3, 8529.0], [25.4, 8538.0], [25.5, 8545.0], [25.6, 8561.0], [25.7, 8590.0], [25.8, 8594.0], [25.9, 8619.0], [26.0, 8633.0], [26.1, 8649.0], [26.2, 8654.0], [26.3, 8662.0], [26.4, 8680.0], [26.5, 8698.0], [26.6, 8711.0], [26.7, 8725.0], [26.8, 8733.0], [26.9, 8734.0], [27.0, 8749.0], [27.1, 8755.0], [27.2, 8757.0], [27.3, 8768.0], [27.4, 8774.0], [27.5, 8790.0], [27.6, 8797.0], [27.7, 8798.0], [27.8, 8809.0], [27.9, 8818.0], [28.0, 8819.0], [28.1, 8824.0], [28.2, 8843.0], [28.3, 8851.0], [28.4, 8854.0], [28.5, 8860.0], [28.6, 8866.0], [28.7, 8869.0], [28.8, 8888.0], [28.9, 8896.0], [29.0, 8898.0], [29.1, 8917.0], [29.2, 8939.0], [29.3, 8943.0], [29.4, 8952.0], [29.5, 8958.0], [29.6, 8963.0], [29.7, 8975.0], [29.8, 8976.0], [29.9, 8985.0], [30.0, 8988.0], [30.1, 8988.0], [30.2, 8997.0], [30.3, 9019.0], [30.4, 9038.0], [30.5, 9051.0], [30.6, 9065.0], [30.7, 9083.0], [30.8, 9095.0], [30.9, 9102.0], [31.0, 9102.0], [31.1, 9116.0], [31.2, 9116.0], [31.3, 9136.0], [31.4, 9141.0], [31.5, 9145.0], [31.6, 9147.0], [31.7, 9152.0], [31.8, 9159.0], [31.9, 9161.0], [32.0, 9178.0], [32.1, 9193.0], [32.2, 9200.0], [32.3, 9209.0], [32.4, 9214.0], [32.5, 9214.0], [32.6, 9227.0], [32.7, 9232.0], [32.8, 9245.0], [32.9, 9255.0], [33.0, 9257.0], [33.1, 9258.0], [33.2, 9278.0], [33.3, 9280.0], [33.4, 9284.0], [33.5, 9291.0], [33.6, 9292.0], [33.7, 9293.0], [33.8, 9307.0], [33.9, 9315.0], [34.0, 9326.0], [34.1, 9332.0], [34.2, 9333.0], [34.3, 9336.0], [34.4, 9339.0], [34.5, 9339.0], [34.6, 9342.0], [34.7, 9357.0], [34.8, 9357.0], [34.9, 9369.0], [35.0, 9371.0], [35.1, 9388.0], [35.2, 9416.0], [35.3, 9422.0], [35.4, 9441.0], [35.5, 9457.0], [35.6, 9460.0], [35.7, 9477.0], [35.8, 9478.0], [35.9, 9479.0], [36.0, 9484.0], [36.1, 9489.0], [36.2, 9507.0], [36.3, 9518.0], [36.4, 9538.0], [36.5, 9541.0], [36.6, 9549.0], [36.7, 9566.0], [36.8, 9570.0], [36.9, 9573.0], [37.0, 9581.0], [37.1, 9590.0], [37.2, 9592.0], [37.3, 9622.0], [37.4, 9626.0], [37.5, 9627.0], [37.6, 9630.0], [37.7, 9640.0], [37.8, 9640.0], [37.9, 9646.0], [38.0, 9648.0], [38.1, 9649.0], [38.2, 9669.0], [38.3, 9670.0], [38.4, 9673.0], [38.5, 9680.0], [38.6, 9686.0], [38.7, 9687.0], [38.8, 9693.0], [38.9, 9701.0], [39.0, 9709.0], [39.1, 9720.0], [39.2, 9730.0], [39.3, 9738.0], [39.4, 9744.0], [39.5, 9770.0], [39.6, 9772.0], [39.7, 9779.0], [39.8, 9783.0], [39.9, 9790.0], [40.0, 9794.0], [40.1, 9798.0], [40.2, 9808.0], [40.3, 9812.0], [40.4, 9818.0], [40.5, 9830.0], [40.6, 9841.0], [40.7, 9844.0], [40.8, 9861.0], [40.9, 9862.0], [41.0, 9866.0], [41.1, 9873.0], [41.2, 9879.0], [41.3, 9879.0], [41.4, 9896.0], [41.5, 9902.0], [41.6, 9909.0], [41.7, 9918.0], [41.8, 9920.0], [41.9, 9920.0], [42.0, 9928.0], [42.1, 9934.0], [42.2, 9935.0], [42.3, 9948.0], [42.4, 9950.0], [42.5, 9950.0], [42.6, 9966.0], [42.7, 9967.0], [42.8, 9973.0], [42.9, 9992.0], [43.0, 9993.0], [43.1, 9997.0], [43.2, 10014.0], [43.3, 10015.0], [43.4, 10018.0], [43.5, 10027.0], [43.6, 10033.0], [43.7, 10053.0], [43.8, 10054.0], [43.9, 10055.0], [44.0, 10060.0], [44.1, 10063.0], [44.2, 10063.0], [44.3, 10065.0], [44.4, 10070.0], [44.5, 10082.0], [44.6, 10093.0], [44.7, 10095.0], [44.8, 10113.0], [44.9, 10118.0], [45.0, 10118.0], [45.1, 10119.0], [45.2, 10135.0], [45.3, 10142.0], [45.4, 10156.0], [45.5, 10163.0], [45.6, 10167.0], [45.7, 10171.0], [45.8, 10179.0], [45.9, 10180.0], [46.0, 10190.0], [46.1, 10203.0], [46.2, 10253.0], [46.3, 10260.0], [46.4, 10269.0], [46.5, 10282.0], [46.6, 10283.0], [46.7, 10291.0], [46.8, 10309.0], [46.9, 10309.0], [47.0, 10312.0], [47.1, 10317.0], [47.2, 10318.0], [47.3, 10347.0], [47.4, 10349.0], [47.5, 10378.0], [47.6, 10385.0], [47.7, 10406.0], [47.8, 10416.0], [47.9, 10420.0], [48.0, 10423.0], [48.1, 10427.0], [48.2, 10428.0], [48.3, 10433.0], [48.4, 10447.0], [48.5, 10453.0], [48.6, 10486.0], [48.7, 10491.0], [48.8, 10497.0], [48.9, 10507.0], [49.0, 10533.0], [49.1, 10536.0], [49.2, 10541.0], [49.3, 10554.0], [49.4, 10565.0], [49.5, 10567.0], [49.6, 10577.0], [49.7, 10587.0], [49.8, 10587.0], [49.9, 10632.0], [50.0, 10648.0], [50.1, 10648.0], [50.2, 10664.0], [50.3, 10697.0], [50.4, 10701.0], [50.5, 10714.0], [50.6, 10716.0], [50.7, 10728.0], [50.8, 10748.0], [50.9, 10763.0], [51.0, 10763.0], [51.1, 10791.0], [51.2, 10794.0], [51.3, 10799.0], [51.4, 10821.0], [51.5, 10829.0], [51.6, 10829.0], [51.7, 10841.0], [51.8, 10842.0], [51.9, 10856.0], [52.0, 10884.0], [52.1, 10891.0], [52.2, 10917.0], [52.3, 10927.0], [52.4, 10929.0], [52.5, 10945.0], [52.6, 10947.0], [52.7, 10950.0], [52.8, 10987.0], [52.9, 10992.0], [53.0, 10994.0], [53.1, 11022.0], [53.2, 11025.0], [53.3, 11027.0], [53.4, 11066.0], [53.5, 11071.0], [53.6, 11087.0], [53.7, 11094.0], [53.8, 11108.0], [53.9, 11117.0], [54.0, 11130.0], [54.1, 11134.0], [54.2, 11159.0], [54.3, 11164.0], [54.4, 11164.0], [54.5, 11177.0], [54.6, 11211.0], [54.7, 11243.0], [54.8, 11262.0], [54.9, 11265.0], [55.0, 11280.0], [55.1, 11288.0], [55.2, 11336.0], [55.3, 11362.0], [55.4, 11368.0], [55.5, 11403.0], [55.6, 11406.0], [55.7, 11421.0], [55.8, 11481.0], [55.9, 11502.0], [56.0, 11524.0], [56.1, 11561.0], [56.2, 11568.0], [56.3, 11581.0], [56.4, 11594.0], [56.5, 11610.0], [56.6, 11650.0], [56.7, 11661.0], [56.8, 11673.0], [56.9, 11681.0], [57.0, 11682.0], [57.1, 11705.0], [57.2, 11719.0], [57.3, 11728.0], [57.4, 11733.0], [57.5, 11755.0], [57.6, 11768.0], [57.7, 11773.0], [57.8, 11814.0], [57.9, 11818.0], [58.0, 11835.0], [58.1, 11839.0], [58.2, 11844.0], [58.3, 11847.0], [58.4, 11862.0], [58.5, 11878.0], [58.6, 11912.0], [58.7, 11948.0], [58.8, 11967.0], [58.9, 11990.0], [59.0, 12004.0], [59.1, 12004.0], [59.2, 12006.0], [59.3, 12033.0], [59.4, 12035.0], [59.5, 12038.0], [59.6, 12060.0], [59.7, 12060.0], [59.8, 12061.0], [59.9, 12075.0], [60.0, 12096.0], [60.1, 12113.0], [60.2, 12129.0], [60.3, 12140.0], [60.4, 12141.0], [60.5, 12159.0], [60.6, 12167.0], [60.7, 12169.0], [60.8, 12209.0], [60.9, 12217.0], [61.0, 12230.0], [61.1, 12230.0], [61.2, 12257.0], [61.3, 12271.0], [61.4, 12284.0], [61.5, 12294.0], [61.6, 12305.0], [61.7, 12315.0], [61.8, 12327.0], [61.9, 12340.0], [62.0, 12350.0], [62.1, 12369.0], [62.2, 12378.0], [62.3, 12385.0], [62.4, 12392.0], [62.5, 12398.0], [62.6, 12400.0], [62.7, 12401.0], [62.8, 12416.0], [62.9, 12422.0], [63.0, 12428.0], [63.1, 12439.0], [63.2, 12452.0], [63.3, 12453.0], [63.4, 12455.0], [63.5, 12473.0], [63.6, 12486.0], [63.7, 12494.0], [63.8, 12497.0], [63.9, 12499.0], [64.0, 12505.0], [64.1, 12510.0], [64.2, 12532.0], [64.3, 12539.0], [64.4, 12541.0], [64.5, 12554.0], [64.6, 12623.0], [64.7, 12623.0], [64.8, 12657.0], [64.9, 12668.0], [65.0, 12672.0], [65.1, 12695.0], [65.2, 12727.0], [65.3, 12728.0], [65.4, 12739.0], [65.5, 12745.0], [65.6, 12747.0], [65.7, 12757.0], [65.8, 12763.0], [65.9, 12775.0], [66.0, 12788.0], [66.1, 12789.0], [66.2, 12812.0], [66.3, 12818.0], [66.4, 12831.0], [66.5, 12840.0], [66.6, 12860.0], [66.7, 12867.0], [66.8, 12870.0], [66.9, 12888.0], [67.0, 12904.0], [67.1, 12907.0], [67.2, 12912.0], [67.3, 12914.0], [67.4, 12920.0], [67.5, 12933.0], [67.6, 12936.0], [67.7, 12939.0], [67.8, 12970.0], [67.9, 12976.0], [68.0, 12976.0], [68.1, 12982.0], [68.2, 12999.0], [68.3, 13008.0], [68.4, 13019.0], [68.5, 13037.0], [68.6, 13039.0], [68.7, 13049.0], [68.8, 13050.0], [68.9, 13060.0], [69.0, 13085.0], [69.1, 13088.0], [69.2, 13098.0], [69.3, 13114.0], [69.4, 13119.0], [69.5, 13120.0], [69.6, 13123.0], [69.7, 13140.0], [69.8, 13153.0], [69.9, 13159.0], [70.0, 13173.0], [70.1, 13193.0], [70.2, 13201.0], [70.3, 13222.0], [70.4, 13237.0], [70.5, 13245.0], [70.6, 13249.0], [70.7, 13255.0], [70.8, 13263.0], [70.9, 13275.0], [71.0, 13288.0], [71.1, 13299.0], [71.2, 13303.0], [71.3, 13310.0], [71.4, 13312.0], [71.5, 13319.0], [71.6, 13330.0], [71.7, 13336.0], [71.8, 13340.0], [71.9, 13359.0], [72.0, 13364.0], [72.1, 13365.0], [72.2, 13371.0], [72.3, 13374.0], [72.4, 13379.0], [72.5, 13393.0], [72.6, 13394.0], [72.7, 13405.0], [72.8, 13411.0], [72.9, 13412.0], [73.0, 13414.0], [73.1, 13424.0], [73.2, 13427.0], [73.3, 13429.0], [73.4, 13442.0], [73.5, 13443.0], [73.6, 13446.0], [73.7, 13448.0], [73.8, 13450.0], [73.9, 13455.0], [74.0, 13467.0], [74.1, 13475.0], [74.2, 13482.0], [74.3, 13497.0], [74.4, 13500.0], [74.5, 13506.0], [74.6, 13516.0], [74.7, 13516.0], [74.8, 13534.0], [74.9, 13540.0], [75.0, 13541.0], [75.1, 13558.0], [75.2, 13563.0], [75.3, 13567.0], [75.4, 13577.0], [75.5, 13582.0], [75.6, 13589.0], [75.7, 13601.0], [75.8, 13602.0], [75.9, 13611.0], [76.0, 13631.0], [76.1, 13635.0], [76.2, 13644.0], [76.3, 13651.0], [76.4, 13652.0], [76.5, 13652.0], [76.6, 13656.0], [76.7, 13673.0], [76.8, 13675.0], [76.9, 13712.0], [77.0, 13722.0], [77.1, 13731.0], [77.2, 13734.0], [77.3, 13737.0], [77.4, 13741.0], [77.5, 13760.0], [77.6, 13763.0], [77.7, 13763.0], [77.8, 13765.0], [77.9, 13767.0], [78.0, 13773.0], [78.1, 13797.0], [78.2, 13808.0], [78.3, 13826.0], [78.4, 13831.0], [78.5, 13834.0], [78.6, 13838.0], [78.7, 13843.0], [78.8, 13853.0], [78.9, 13862.0], [79.0, 13863.0], [79.1, 13865.0], [79.2, 13878.0], [79.3, 13883.0], [79.4, 13885.0], [79.5, 13912.0], [79.6, 13917.0], [79.7, 13918.0], [79.8, 13930.0], [79.9, 13955.0], [80.0, 13955.0], [80.1, 13968.0], [80.2, 13973.0], [80.3, 13973.0], [80.4, 13994.0], [80.5, 13995.0], [80.6, 14005.0], [80.7, 14009.0], [80.8, 14013.0], [80.9, 14019.0], [81.0, 14035.0], [81.1, 14046.0], [81.2, 14049.0], [81.3, 14068.0], [81.4, 14071.0], [81.5, 14079.0], [81.6, 14084.0], [81.7, 14104.0], [81.8, 14109.0], [81.9, 14116.0], [82.0, 14117.0], [82.1, 14120.0], [82.2, 14131.0], [82.3, 14152.0], [82.4, 14163.0], [82.5, 14175.0], [82.6, 14180.0], [82.7, 14184.0], [82.8, 14195.0], [82.9, 14203.0], [83.0, 14206.0], [83.1, 14211.0], [83.2, 14226.0], [83.3, 14235.0], [83.4, 14243.0], [83.5, 14244.0], [83.6, 14249.0], [83.7, 14262.0], [83.8, 14267.0], [83.9, 14278.0], [84.0, 14280.0], [84.1, 14283.0], [84.2, 14290.0], [84.3, 14290.0], [84.4, 14300.0], [84.5, 14306.0], [84.6, 14312.0], [84.7, 14326.0], [84.8, 14330.0], [84.9, 14331.0], [85.0, 14331.0], [85.1, 14339.0], [85.2, 14340.0], [85.3, 14344.0], [85.4, 14354.0], [85.5, 14355.0], [85.6, 14355.0], [85.7, 14377.0], [85.8, 14380.0], [85.9, 14383.0], [86.0, 14393.0], [86.1, 14406.0], [86.2, 14408.0], [86.3, 14417.0], [86.4, 14420.0], [86.5, 14423.0], [86.6, 14427.0], [86.7, 14437.0], [86.8, 14438.0], [86.9, 14459.0], [87.0, 14468.0], [87.1, 14474.0], [87.2, 14479.0], [87.3, 14491.0], [87.4, 14522.0], [87.5, 14522.0], [87.6, 14524.0], [87.7, 14524.0], [87.8, 14534.0], [87.9, 14558.0], [88.0, 14565.0], [88.1, 14568.0], [88.2, 14582.0], [88.3, 14588.0], [88.4, 14591.0], [88.5, 14601.0], [88.6, 14607.0], [88.7, 14610.0], [88.8, 14611.0], [88.9, 14617.0], [89.0, 14622.0], [89.1, 14624.0], [89.2, 14631.0], [89.3, 14637.0], [89.4, 14656.0], [89.5, 14687.0], [89.6, 14689.0], [89.7, 14705.0], [89.8, 14714.0], [89.9, 14717.0], [90.0, 14722.0], [90.1, 14731.0], [90.2, 14734.0], [90.3, 14735.0], [90.4, 14754.0], [90.5, 14757.0], [90.6, 14762.0], [90.7, 14775.0], [90.8, 14786.0], [90.9, 14794.0], [91.0, 14822.0], [91.1, 14839.0], [91.2, 14840.0], [91.3, 14866.0], [91.4, 14868.0], [91.5, 14893.0], [91.6, 14894.0], [91.7, 14896.0], [91.8, 14915.0], [91.9, 14917.0], [92.0, 14924.0], [92.1, 14940.0], [92.2, 14950.0], [92.3, 14954.0], [92.4, 14967.0], [92.5, 14968.0], [92.6, 14978.0], [92.7, 15004.0], [92.8, 15045.0], [92.9, 15090.0], [93.0, 15106.0], [93.1, 15115.0], [93.2, 15118.0], [93.3, 15147.0], [93.4, 15176.0], [93.5, 15177.0], [93.6, 15200.0], [93.7, 15211.0], [93.8, 15231.0], [93.9, 15247.0], [94.0, 15253.0], [94.1, 15277.0], [94.2, 15285.0], [94.3, 15306.0], [94.4, 15321.0], [94.5, 15329.0], [94.6, 15334.0], [94.7, 15344.0], [94.8, 15410.0], [94.9, 15428.0], [95.0, 15446.0], [95.1, 15465.0], [95.2, 15467.0], [95.3, 15469.0], [95.4, 15484.0], [95.5, 15496.0], [95.6, 15500.0], [95.7, 15507.0], [95.8, 15512.0], [95.9, 15546.0], [96.0, 15568.0], [96.1, 15572.0], [96.2, 15647.0], [96.3, 15657.0], [96.4, 15666.0], [96.5, 15703.0], [96.6, 15744.0], [96.7, 15751.0], [96.8, 15770.0], [96.9, 15774.0], [97.0, 15774.0], [97.1, 15824.0], [97.2, 15871.0], [97.3, 15871.0], [97.4, 15908.0], [97.5, 15913.0], [97.6, 15937.0], [97.7, 15995.0], [97.8, 16014.0], [97.9, 16208.0], [98.0, 16220.0], [98.1, 16241.0], [98.2, 16306.0], [98.3, 16446.0], [98.4, 16478.0], [98.5, 16509.0], [98.6, 16567.0], [98.7, 16661.0], [98.8, 16666.0], [98.9, 16689.0], [99.0, 16707.0], [99.1, 16724.0], [99.2, 16786.0], [99.3, 16900.0], [99.4, 17006.0], [99.5, 17136.0], [99.6, 17250.0], [99.7, 17318.0], [99.8, 17579.0], [99.9, 17584.0], [100.0, 17691.0]], "isOverall": false, "label": "Ingest API Firenoc(20)", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 4500.0, "maxY": 23.0, "series": [{"data": [[4500.0, 1.0], [4700.0, 1.0], [5100.0, 2.0], [4900.0, 2.0], [5200.0, 1.0], [5300.0, 1.0], [5400.0, 8.0], [5600.0, 6.0], [5500.0, 6.0], [5700.0, 4.0], [5800.0, 6.0], [6000.0, 11.0], [6100.0, 10.0], [5900.0, 9.0], [6300.0, 12.0], [6200.0, 20.0], [6500.0, 12.0], [6400.0, 8.0], [6600.0, 7.0], [6900.0, 14.0], [6700.0, 15.0], [6800.0, 13.0], [7000.0, 14.0], [7100.0, 12.0], [7400.0, 19.0], [7200.0, 17.0], [7300.0, 13.0], [7500.0, 6.0], [7600.0, 10.0], [7800.0, 8.0], [7700.0, 9.0], [7900.0, 6.0], [8000.0, 11.0], [8100.0, 7.0], [8500.0, 10.0], [8700.0, 16.0], [8400.0, 11.0], [8200.0, 17.0], [8600.0, 10.0], [8300.0, 7.0], [8900.0, 16.0], [9100.0, 17.0], [9200.0, 22.0], [9000.0, 9.0], [8800.0, 17.0], [9700.0, 17.0], [9400.0, 14.0], [9500.0, 14.0], [9600.0, 22.0], [9300.0, 18.0], [9900.0, 22.0], [10000.0, 22.0], [10100.0, 18.0], [10200.0, 9.0], [9800.0, 18.0], [10400.0, 16.0], [10300.0, 12.0], [10600.0, 7.0], [10700.0, 13.0], [10500.0, 13.0], [10900.0, 12.0], [11000.0, 10.0], [11100.0, 11.0], [10800.0, 11.0], [11200.0, 7.0], [11600.0, 8.0], [11500.0, 8.0], [11700.0, 9.0], [11300.0, 5.0], [11400.0, 5.0], [12200.0, 12.0], [12000.0, 14.0], [11800.0, 11.0], [12100.0, 9.0], [11900.0, 6.0], [12500.0, 9.0], [12600.0, 7.0], [12300.0, 13.0], [12400.0, 18.0], [12700.0, 14.0], [13200.0, 13.0], [12900.0, 17.0], [13100.0, 12.0], [13300.0, 20.0], [13000.0, 14.0], [12800.0, 11.0], [13400.0, 23.0], [13800.0, 18.0], [13500.0, 17.0], [13700.0, 17.0], [13600.0, 17.0], [14100.0, 16.0], [14200.0, 20.0], [13900.0, 14.0], [14300.0, 23.0], [14000.0, 15.0], [14400.0, 17.0], [14700.0, 17.0], [14500.0, 15.0], [14600.0, 16.0], [14800.0, 11.0], [14900.0, 12.0], [15300.0, 7.0], [15000.0, 4.0], [15100.0, 9.0], [15200.0, 9.0], [15400.0, 10.0], [15500.0, 8.0], [15700.0, 7.0], [15600.0, 5.0], [15800.0, 5.0], [16200.0, 4.0], [15900.0, 5.0], [16300.0, 2.0], [16000.0, 1.0], [16600.0, 4.0], [17300.0, 1.0], [16700.0, 4.0], [16500.0, 3.0], [16400.0, 2.0], [17100.0, 1.0], [17200.0, 1.0], [17000.0, 2.0], [16900.0, 1.0], [17500.0, 3.0], [17600.0, 1.0]], "isOverall": false, "label": "Ingest API Firenoc(20)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 17600.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 1341.0, "minX": 2.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 1341.0, "series": [{"data": [], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 1341.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 21.7741935483871, "minX": 1.64501004E12, "maxY": 25.0, "series": [{"data": [[1.64501058E12, 25.0], [1.6450104E12, 25.0], [1.64501046E12, 25.0], [1.6450101E12, 25.0], [1.64501028E12, 25.0], [1.64501004E12, 25.0], [1.64501034E12, 25.0], [1.64501022E12, 25.0], [1.64501064E12, 21.7741935483871], [1.64501016E12, 25.0], [1.64501052E12, 25.0]], "isOverall": false, "label": "Dashboard API", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64501064E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 5695.0, "minX": 1.0, "maxY": 13478.0, "series": [{"data": [[2.0, 10577.0], [3.0, 8221.0], [4.0, 11681.0], [5.0, 7666.0], [6.0, 8448.0], [7.0, 11581.0], [8.0, 12378.0], [9.0, 9291.0], [10.0, 13443.0], [11.0, 12159.0], [12.0, 12144.0], [13.0, 13478.0], [14.0, 7037.0], [15.0, 10253.0], [16.0, 12731.0], [1.0, 10569.0], [17.0, 9973.0], [18.0, 9866.0], [19.0, 8798.0], [20.0, 12541.0], [21.0, 6273.0], [22.0, 11421.0], [23.0, 13322.0], [24.0, 5695.0], [25.0, 10894.936977980253]], "isOverall": false, "label": "Ingest API Firenoc(20)", "isController": false}, {"data": [[24.776286353467558, 10886.03877703206]], "isOverall": false, "label": "Ingest API Firenoc(20)-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 25.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 782.05, "minX": 1.64501004E12, "maxY": 337509.6666666667, "series": [{"data": [[1.64501058E12, 2423.116666666667], [1.6450104E12, 2594.616666666667], [1.64501046E12, 2613.75], [1.6450101E12, 2499.616666666667], [1.64501028E12, 2613.766666666667], [1.64501004E12, 782.05], [1.64501034E12, 2575.55], [1.64501022E12, 2479.9333333333334], [1.64501064E12, 1774.15], [1.64501016E12, 2556.65], [1.64501052E12, 2670.8]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.64501058E12, 306169.48333333334], [1.6450104E12, 327866.5333333333], [1.64501046E12, 330277.31666666665], [1.6450101E12, 315812.61666666664], [1.64501028E12, 330277.31666666665], [1.64501004E12, 98842.11666666667], [1.64501034E12, 325455.75], [1.64501022E12, 313401.8333333333], [1.64501064E12, 224202.85], [1.64501016E12, 323044.9666666667], [1.64501052E12, 337509.6666666667]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64501064E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 10496.185714285715, "minX": 1.64501004E12, "maxY": 11352.551181102363, "series": [{"data": [[1.64501058E12, 11352.551181102363], [1.6450104E12, 10692.610294117652], [1.64501046E12, 10663.744525547441], [1.6450101E12, 11229.267175572522], [1.64501028E12, 10853.620437956208], [1.64501004E12, 10843.536585365853], [1.64501034E12, 10678.918518518514], [1.64501022E12, 11212.176923076926], [1.64501064E12, 11149.236559139792], [1.64501016E12, 10694.992537313434], [1.64501052E12, 10496.185714285715]], "isOverall": false, "label": "Ingest API Firenoc(20)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64501064E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 10496.092857142858, "minX": 1.64501004E12, "maxY": 11352.3779527559, "series": [{"data": [[1.64501058E12, 11352.3779527559], [1.6450104E12, 10692.301470588238], [1.64501046E12, 10663.605839416054], [1.6450101E12, 11229.122137404584], [1.64501028E12, 10853.5401459854], [1.64501004E12, 10843.341463414634], [1.64501034E12, 10678.770370370374], [1.64501022E12, 11212.0], [1.64501064E12, 11149.107526881724], [1.64501016E12, 10694.888059701492], [1.64501052E12, 10496.092857142858]], "isOverall": false, "label": "Ingest API Firenoc(20)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64501064E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 100.12686567164178, "minX": 1.64501004E12, "maxY": 154.88172043010746, "series": [{"data": [[1.64501058E12, 129.68503937007875], [1.6450104E12, 128.02205882352942], [1.64501046E12, 111.22627737226274], [1.6450101E12, 103.61068702290078], [1.64501028E12, 110.90510948905111], [1.64501004E12, 143.02439024390247], [1.64501034E12, 105.63703703703703], [1.64501022E12, 114.51538461538463], [1.64501064E12, 154.88172043010746], [1.64501016E12, 100.12686567164178], [1.64501052E12, 104.12857142857139]], "isOverall": false, "label": "Ingest API Firenoc(20)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64501064E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 4569.0, "minX": 1.64501004E12, "maxY": 17691.0, "series": [{"data": [[1.64501058E12, 17584.0], [1.6450104E12, 15744.0], [1.64501046E12, 15816.0], [1.6450101E12, 17579.0], [1.64501028E12, 17025.0], [1.64501004E12, 16212.0], [1.64501034E12, 16707.0], [1.64501022E12, 17691.0], [1.64501064E12, 15995.0], [1.64501016E12, 16546.0], [1.64501052E12, 16478.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.64501058E12, 15330.0], [1.6450104E12, 14413.5], [1.64501046E12, 14372.0], [1.6450101E12, 15447.4], [1.64501028E12, 15459.2], [1.64501004E12, 14360.2], [1.64501034E12, 14811.400000000001], [1.64501022E12, 15227.5], [1.64501064E12, 14344.4], [1.64501016E12, 14479.0], [1.64501052E12, 14407.8]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.64501058E12, 17578.12], [1.6450104E12, 15595.999999999998], [1.64501046E12, 15798.52], [1.6450101E12, 17495.480000000003], [1.64501028E12, 17017.78], [1.64501004E12, 16212.0], [1.64501034E12, 16531.679999999993], [1.64501022E12, 17554.289999999997], [1.64501064E12, 15995.0], [1.64501016E12, 16085.750000000007], [1.64501052E12, 16380.83]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.64501058E12, 15832.199999999999], [1.6450104E12, 14909.900000000001], [1.64501046E12, 15205.3], [1.6450101E12, 15813.8], [1.64501028E12, 16043.199999999999], [1.64501004E12, 14705.6], [1.64501034E12, 15254.0], [1.64501022E12, 16609.3], [1.64501064E12, 14873.5], [1.64501016E12, 14817.5], [1.64501052E12, 15404.8]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.64501058E12, 4569.0], [1.6450104E12, 4964.0], [1.64501046E12, 5427.0], [1.6450101E12, 5421.0], [1.64501028E12, 4769.0], [1.64501004E12, 5752.0], [1.64501034E12, 5423.0], [1.64501022E12, 6012.0], [1.64501064E12, 4972.0], [1.64501016E12, 5454.0], [1.64501052E12, 5196.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.64501058E12, 11650.0], [1.6450104E12, 10343.5], [1.64501046E12, 10095.0], [1.6450101E12, 10954.0], [1.64501028E12, 10447.0], [1.64501004E12, 10987.0], [1.64501034E12, 10060.0], [1.64501022E12, 10939.0], [1.64501064E12, 11594.0], [1.64501016E12, 10240.0], [1.64501052E12, 9870.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64501064E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 9560.5, "minX": 1.0, "maxY": 11406.0, "series": [{"data": [[4.0, 10576.0], [1.0, 10860.0], [2.0, 10404.0], [5.0, 11406.0], [3.0, 10828.5], [6.0, 11094.5], [7.0, 9560.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 7.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 9560.5, "minX": 1.0, "maxY": 11406.0, "series": [{"data": [[4.0, 10576.0], [1.0, 10860.0], [2.0, 10404.0], [5.0, 11406.0], [3.0, 10828.5], [6.0, 11094.5], [7.0, 9560.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 7.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 1.0666666666666667, "minX": 1.64501004E12, "maxY": 2.316666666666667, "series": [{"data": [[1.64501058E12, 2.15], [1.6450104E12, 2.2333333333333334], [1.64501046E12, 2.316666666666667], [1.6450101E12, 2.183333333333333], [1.64501028E12, 2.3], [1.64501004E12, 1.0666666666666667], [1.64501034E12, 2.2666666666666666], [1.64501022E12, 2.15], [1.64501064E12, 1.1333333333333333], [1.64501016E12, 2.25], [1.64501052E12, 2.3]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64501064E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.6833333333333333, "minX": 1.64501004E12, "maxY": 2.3333333333333335, "series": [{"data": [[1.64501058E12, 2.1166666666666667], [1.6450104E12, 2.2666666666666666], [1.64501046E12, 2.283333333333333], [1.6450101E12, 2.183333333333333], [1.64501028E12, 2.283333333333333], [1.64501004E12, 0.6833333333333333], [1.64501034E12, 2.25], [1.64501022E12, 2.1666666666666665], [1.64501064E12, 1.55], [1.64501016E12, 2.2333333333333334], [1.64501052E12, 2.3333333333333335]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64501064E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.6833333333333333, "minX": 1.64501004E12, "maxY": 2.3333333333333335, "series": [{"data": [[1.64501058E12, 2.1166666666666667], [1.6450104E12, 2.2666666666666666], [1.64501046E12, 2.283333333333333], [1.6450101E12, 2.183333333333333], [1.64501028E12, 2.283333333333333], [1.64501004E12, 0.6833333333333333], [1.64501034E12, 2.25], [1.64501022E12, 2.1666666666666665], [1.64501064E12, 1.55], [1.64501016E12, 2.2333333333333334], [1.64501052E12, 2.3333333333333335]], "isOverall": false, "label": "Ingest API Firenoc(20)-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64501064E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.6833333333333333, "minX": 1.64501004E12, "maxY": 2.3333333333333335, "series": [{"data": [[1.64501058E12, 2.1166666666666667], [1.6450104E12, 2.2666666666666666], [1.64501046E12, 2.283333333333333], [1.6450101E12, 2.183333333333333], [1.64501028E12, 2.283333333333333], [1.64501004E12, 0.6833333333333333], [1.64501034E12, 2.25], [1.64501022E12, 2.1666666666666665], [1.64501064E12, 1.55], [1.64501016E12, 2.2333333333333334], [1.64501052E12, 2.3333333333333335]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64501064E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

