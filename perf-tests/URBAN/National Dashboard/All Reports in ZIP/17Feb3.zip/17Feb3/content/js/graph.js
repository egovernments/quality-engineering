/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 345.0, "minX": 0.0, "maxY": 24650.0, "series": [{"data": [[0.0, 345.0], [0.1, 355.0], [0.2, 360.0], [0.3, 365.0], [0.4, 369.0], [0.5, 371.0], [0.6, 373.0], [0.7, 376.0], [0.8, 378.0], [0.9, 379.0], [1.0, 382.0], [1.1, 387.0], [1.2, 389.0], [1.3, 392.0], [1.4, 395.0], [1.5, 396.0], [1.6, 399.0], [1.7, 400.0], [1.8, 402.0], [1.9, 404.0], [2.0, 407.0], [2.1, 407.0], [2.2, 409.0], [2.3, 412.0], [2.4, 413.0], [2.5, 414.0], [2.6, 415.0], [2.7, 417.0], [2.8, 418.0], [2.9, 420.0], [3.0, 421.0], [3.1, 422.0], [3.2, 424.0], [3.3, 426.0], [3.4, 427.0], [3.5, 430.0], [3.6, 430.0], [3.7, 430.0], [3.8, 431.0], [3.9, 433.0], [4.0, 434.0], [4.1, 440.0], [4.2, 440.0], [4.3, 441.0], [4.4, 442.0], [4.5, 442.0], [4.6, 443.0], [4.7, 443.0], [4.8, 445.0], [4.9, 446.0], [5.0, 449.0], [5.1, 450.0], [5.2, 451.0], [5.3, 451.0], [5.4, 452.0], [5.5, 453.0], [5.6, 454.0], [5.7, 456.0], [5.8, 457.0], [5.9, 458.0], [6.0, 458.0], [6.1, 459.0], [6.2, 459.0], [6.3, 460.0], [6.4, 461.0], [6.5, 462.0], [6.6, 463.0], [6.7, 463.0], [6.8, 465.0], [6.9, 466.0], [7.0, 466.0], [7.1, 468.0], [7.2, 468.0], [7.3, 469.0], [7.4, 469.0], [7.5, 470.0], [7.6, 471.0], [7.7, 471.0], [7.8, 472.0], [7.9, 473.0], [8.0, 474.0], [8.1, 476.0], [8.2, 477.0], [8.3, 479.0], [8.4, 480.0], [8.5, 482.0], [8.6, 483.0], [8.7, 484.0], [8.8, 486.0], [8.9, 486.0], [9.0, 487.0], [9.1, 488.0], [9.2, 492.0], [9.3, 494.0], [9.4, 495.0], [9.5, 496.0], [9.6, 498.0], [9.7, 500.0], [9.8, 501.0], [9.9, 502.0], [10.0, 502.0], [10.1, 502.0], [10.2, 503.0], [10.3, 503.0], [10.4, 504.0], [10.5, 505.0], [10.6, 505.0], [10.7, 506.0], [10.8, 506.0], [10.9, 507.0], [11.0, 508.0], [11.1, 508.0], [11.2, 508.0], [11.3, 509.0], [11.4, 509.0], [11.5, 511.0], [11.6, 512.0], [11.7, 513.0], [11.8, 513.0], [11.9, 513.0], [12.0, 514.0], [12.1, 514.0], [12.2, 515.0], [12.3, 516.0], [12.4, 516.0], [12.5, 517.0], [12.6, 518.0], [12.7, 519.0], [12.8, 522.0], [12.9, 523.0], [13.0, 524.0], [13.1, 524.0], [13.2, 525.0], [13.3, 526.0], [13.4, 527.0], [13.5, 527.0], [13.6, 528.0], [13.7, 528.0], [13.8, 529.0], [13.9, 530.0], [14.0, 530.0], [14.1, 531.0], [14.2, 533.0], [14.3, 534.0], [14.4, 535.0], [14.5, 537.0], [14.6, 538.0], [14.7, 539.0], [14.8, 541.0], [14.9, 542.0], [15.0, 543.0], [15.1, 545.0], [15.2, 546.0], [15.3, 546.0], [15.4, 547.0], [15.5, 548.0], [15.6, 549.0], [15.7, 550.0], [15.8, 551.0], [15.9, 552.0], [16.0, 552.0], [16.1, 552.0], [16.2, 553.0], [16.3, 554.0], [16.4, 554.0], [16.5, 555.0], [16.6, 556.0], [16.7, 556.0], [16.8, 556.0], [16.9, 557.0], [17.0, 559.0], [17.1, 560.0], [17.2, 561.0], [17.3, 561.0], [17.4, 563.0], [17.5, 564.0], [17.6, 564.0], [17.7, 565.0], [17.8, 567.0], [17.9, 568.0], [18.0, 570.0], [18.1, 572.0], [18.2, 573.0], [18.3, 574.0], [18.4, 575.0], [18.5, 577.0], [18.6, 577.0], [18.7, 579.0], [18.8, 580.0], [18.9, 580.0], [19.0, 581.0], [19.1, 581.0], [19.2, 582.0], [19.3, 583.0], [19.4, 584.0], [19.5, 585.0], [19.6, 585.0], [19.7, 589.0], [19.8, 589.0], [19.9, 590.0], [20.0, 591.0], [20.1, 592.0], [20.2, 592.0], [20.3, 592.0], [20.4, 592.0], [20.5, 593.0], [20.6, 594.0], [20.7, 594.0], [20.8, 595.0], [20.9, 595.0], [21.0, 599.0], [21.1, 600.0], [21.2, 602.0], [21.3, 604.0], [21.4, 605.0], [21.5, 606.0], [21.6, 606.0], [21.7, 607.0], [21.8, 608.0], [21.9, 609.0], [22.0, 610.0], [22.1, 610.0], [22.2, 612.0], [22.3, 613.0], [22.4, 614.0], [22.5, 615.0], [22.6, 616.0], [22.7, 616.0], [22.8, 619.0], [22.9, 619.0], [23.0, 621.0], [23.1, 621.0], [23.2, 622.0], [23.3, 623.0], [23.4, 624.0], [23.5, 626.0], [23.6, 627.0], [23.7, 627.0], [23.8, 629.0], [23.9, 630.0], [24.0, 631.0], [24.1, 634.0], [24.2, 634.0], [24.3, 635.0], [24.4, 637.0], [24.5, 640.0], [24.6, 641.0], [24.7, 641.0], [24.8, 643.0], [24.9, 644.0], [25.0, 645.0], [25.1, 646.0], [25.2, 647.0], [25.3, 648.0], [25.4, 649.0], [25.5, 649.0], [25.6, 651.0], [25.7, 652.0], [25.8, 652.0], [25.9, 654.0], [26.0, 654.0], [26.1, 658.0], [26.2, 658.0], [26.3, 659.0], [26.4, 662.0], [26.5, 663.0], [26.6, 664.0], [26.7, 665.0], [26.8, 668.0], [26.9, 670.0], [27.0, 671.0], [27.1, 671.0], [27.2, 673.0], [27.3, 674.0], [27.4, 676.0], [27.5, 677.0], [27.6, 678.0], [27.7, 681.0], [27.8, 686.0], [27.9, 687.0], [28.0, 688.0], [28.1, 688.0], [28.2, 689.0], [28.3, 689.0], [28.4, 695.0], [28.5, 696.0], [28.6, 697.0], [28.7, 699.0], [28.8, 703.0], [28.9, 707.0], [29.0, 711.0], [29.1, 717.0], [29.2, 721.0], [29.3, 722.0], [29.4, 725.0], [29.5, 728.0], [29.6, 732.0], [29.7, 737.0], [29.8, 739.0], [29.9, 741.0], [30.0, 742.0], [30.1, 744.0], [30.2, 747.0], [30.3, 750.0], [30.4, 753.0], [30.5, 754.0], [30.6, 762.0], [30.7, 765.0], [30.8, 773.0], [30.9, 774.0], [31.0, 776.0], [31.1, 778.0], [31.2, 781.0], [31.3, 784.0], [31.4, 787.0], [31.5, 791.0], [31.6, 796.0], [31.7, 798.0], [31.8, 804.0], [31.9, 804.0], [32.0, 807.0], [32.1, 808.0], [32.2, 808.0], [32.3, 811.0], [32.4, 814.0], [32.5, 820.0], [32.6, 823.0], [32.7, 831.0], [32.8, 832.0], [32.9, 834.0], [33.0, 836.0], [33.1, 844.0], [33.2, 849.0], [33.3, 850.0], [33.4, 851.0], [33.5, 858.0], [33.6, 858.0], [33.7, 871.0], [33.8, 874.0], [33.9, 877.0], [34.0, 880.0], [34.1, 884.0], [34.2, 888.0], [34.3, 904.0], [34.4, 906.0], [34.5, 912.0], [34.6, 915.0], [34.7, 921.0], [34.8, 922.0], [34.9, 926.0], [35.0, 933.0], [35.1, 939.0], [35.2, 954.0], [35.3, 964.0], [35.4, 971.0], [35.5, 977.0], [35.6, 981.0], [35.7, 992.0], [35.8, 998.0], [35.9, 1011.0], [36.0, 1020.0], [36.1, 1031.0], [36.2, 1034.0], [36.3, 1048.0], [36.4, 1061.0], [36.5, 1065.0], [36.6, 1078.0], [36.7, 1083.0], [36.8, 1086.0], [36.9, 1088.0], [37.0, 1094.0], [37.1, 1098.0], [37.2, 1111.0], [37.3, 1114.0], [37.4, 1116.0], [37.5, 1122.0], [37.6, 1126.0], [37.7, 1130.0], [37.8, 1132.0], [37.9, 1140.0], [38.0, 1147.0], [38.1, 1151.0], [38.2, 1161.0], [38.3, 1179.0], [38.4, 1186.0], [38.5, 1204.0], [38.6, 1214.0], [38.7, 1218.0], [38.8, 1245.0], [38.9, 1264.0], [39.0, 1265.0], [39.1, 1275.0], [39.2, 1279.0], [39.3, 1303.0], [39.4, 1320.0], [39.5, 1322.0], [39.6, 1338.0], [39.7, 1373.0], [39.8, 1413.0], [39.9, 1418.0], [40.0, 1460.0], [40.1, 1490.0], [40.2, 1501.0], [40.3, 1504.0], [40.4, 1524.0], [40.5, 1599.0], [40.6, 1635.0], [40.7, 1669.0], [40.8, 1697.0], [40.9, 1724.0], [41.0, 1739.0], [41.1, 1836.0], [41.2, 1864.0], [41.3, 1876.0], [41.4, 1881.0], [41.5, 1890.0], [41.6, 1900.0], [41.7, 1918.0], [41.8, 1927.0], [41.9, 1944.0], [42.0, 1953.0], [42.1, 1979.0], [42.2, 1986.0], [42.3, 1989.0], [42.4, 1992.0], [42.5, 1994.0], [42.6, 1996.0], [42.7, 2008.0], [42.8, 2014.0], [42.9, 2017.0], [43.0, 2023.0], [43.1, 2024.0], [43.2, 2027.0], [43.3, 2030.0], [43.4, 2034.0], [43.5, 2039.0], [43.6, 2043.0], [43.7, 2053.0], [43.8, 2058.0], [43.9, 2060.0], [44.0, 2062.0], [44.1, 2064.0], [44.2, 2070.0], [44.3, 2092.0], [44.4, 2098.0], [44.5, 2108.0], [44.6, 2114.0], [44.7, 2115.0], [44.8, 2123.0], [44.9, 2132.0], [45.0, 2142.0], [45.1, 2157.0], [45.2, 2163.0], [45.3, 2181.0], [45.4, 2188.0], [45.5, 2193.0], [45.6, 2209.0], [45.7, 2215.0], [45.8, 2221.0], [45.9, 2235.0], [46.0, 2249.0], [46.1, 2263.0], [46.2, 2278.0], [46.3, 2294.0], [46.4, 2308.0], [46.5, 2368.0], [46.6, 2387.0], [46.7, 2398.0], [46.8, 2469.0], [46.9, 2475.0], [47.0, 2531.0], [47.1, 2538.0], [47.2, 2562.0], [47.3, 2598.0], [47.4, 2612.0], [47.5, 2640.0], [47.6, 2648.0], [47.7, 2654.0], [47.8, 2668.0], [47.9, 2688.0], [48.0, 2690.0], [48.1, 2732.0], [48.2, 2779.0], [48.3, 2782.0], [48.4, 2797.0], [48.5, 2812.0], [48.6, 2819.0], [48.7, 2823.0], [48.8, 2841.0], [48.9, 2883.0], [49.0, 2956.0], [49.1, 2982.0], [49.2, 2989.0], [49.3, 3279.0], [49.4, 3481.0], [49.5, 4760.0], [49.6, 6174.0], [49.7, 6498.0], [49.8, 6673.0], [49.9, 6771.0], [50.0, 6840.0], [50.1, 7124.0], [50.2, 7198.0], [50.3, 7253.0], [50.4, 7269.0], [50.5, 7280.0], [50.6, 7322.0], [50.7, 7380.0], [50.8, 7396.0], [50.9, 7448.0], [51.0, 7454.0], [51.1, 7495.0], [51.2, 7517.0], [51.3, 7543.0], [51.4, 7575.0], [51.5, 7589.0], [51.6, 7617.0], [51.7, 7631.0], [51.8, 7651.0], [51.9, 7659.0], [52.0, 7690.0], [52.1, 7712.0], [52.2, 7755.0], [52.3, 7763.0], [52.4, 7793.0], [52.5, 7822.0], [52.6, 7871.0], [52.7, 7880.0], [52.8, 7890.0], [52.9, 7905.0], [53.0, 7918.0], [53.1, 7946.0], [53.2, 7978.0], [53.3, 7994.0], [53.4, 8014.0], [53.5, 8040.0], [53.6, 8043.0], [53.7, 8072.0], [53.8, 8100.0], [53.9, 8118.0], [54.0, 8139.0], [54.1, 8142.0], [54.2, 8159.0], [54.3, 8171.0], [54.4, 8240.0], [54.5, 8264.0], [54.6, 8268.0], [54.7, 8303.0], [54.8, 8357.0], [54.9, 8369.0], [55.0, 8381.0], [55.1, 8438.0], [55.2, 8444.0], [55.3, 8470.0], [55.4, 8490.0], [55.5, 8533.0], [55.6, 8602.0], [55.7, 8641.0], [55.8, 8652.0], [55.9, 8670.0], [56.0, 8701.0], [56.1, 8755.0], [56.2, 8756.0], [56.3, 8771.0], [56.4, 8789.0], [56.5, 8816.0], [56.6, 8827.0], [56.7, 8846.0], [56.8, 8883.0], [56.9, 8900.0], [57.0, 8920.0], [57.1, 8942.0], [57.2, 8966.0], [57.3, 8996.0], [57.4, 9028.0], [57.5, 9083.0], [57.6, 9127.0], [57.7, 9143.0], [57.8, 9162.0], [57.9, 9183.0], [58.0, 9189.0], [58.1, 9195.0], [58.2, 9208.0], [58.3, 9260.0], [58.4, 9270.0], [58.5, 9327.0], [58.6, 9332.0], [58.7, 9358.0], [58.8, 9382.0], [58.9, 9404.0], [59.0, 9440.0], [59.1, 9457.0], [59.2, 9463.0], [59.3, 9479.0], [59.4, 9518.0], [59.5, 9548.0], [59.6, 9551.0], [59.7, 9568.0], [59.8, 9583.0], [59.9, 9591.0], [60.0, 9604.0], [60.1, 9630.0], [60.2, 9640.0], [60.3, 9661.0], [60.4, 9670.0], [60.5, 9687.0], [60.6, 9697.0], [60.7, 9702.0], [60.8, 9712.0], [60.9, 9723.0], [61.0, 9749.0], [61.1, 9760.0], [61.2, 9766.0], [61.3, 9801.0], [61.4, 9809.0], [61.5, 9815.0], [61.6, 9839.0], [61.7, 9858.0], [61.8, 9861.0], [61.9, 9888.0], [62.0, 9895.0], [62.1, 9934.0], [62.2, 9953.0], [62.3, 9972.0], [62.4, 9987.0], [62.5, 9992.0], [62.6, 10009.0], [62.7, 10036.0], [62.8, 10039.0], [62.9, 10047.0], [63.0, 10055.0], [63.1, 10059.0], [63.2, 10068.0], [63.3, 10083.0], [63.4, 10091.0], [63.5, 10101.0], [63.6, 10110.0], [63.7, 10136.0], [63.8, 10160.0], [63.9, 10213.0], [64.0, 10232.0], [64.1, 10254.0], [64.2, 10254.0], [64.3, 10290.0], [64.4, 10297.0], [64.5, 10318.0], [64.6, 10328.0], [64.7, 10340.0], [64.8, 10344.0], [64.9, 10359.0], [65.0, 10375.0], [65.1, 10390.0], [65.2, 10395.0], [65.3, 10419.0], [65.4, 10478.0], [65.5, 10490.0], [65.6, 10503.0], [65.7, 10515.0], [65.8, 10531.0], [65.9, 10546.0], [66.0, 10549.0], [66.1, 10553.0], [66.2, 10562.0], [66.3, 10578.0], [66.4, 10595.0], [66.5, 10601.0], [66.6, 10604.0], [66.7, 10650.0], [66.8, 10660.0], [66.9, 10672.0], [67.0, 10700.0], [67.1, 10730.0], [67.2, 10744.0], [67.3, 10766.0], [67.4, 10774.0], [67.5, 10776.0], [67.6, 10808.0], [67.7, 10828.0], [67.8, 10833.0], [67.9, 10847.0], [68.0, 10881.0], [68.1, 10891.0], [68.2, 10913.0], [68.3, 10929.0], [68.4, 10930.0], [68.5, 10947.0], [68.6, 10965.0], [68.7, 10985.0], [68.8, 10994.0], [68.9, 11017.0], [69.0, 11020.0], [69.1, 11025.0], [69.2, 11029.0], [69.3, 11048.0], [69.4, 11056.0], [69.5, 11070.0], [69.6, 11083.0], [69.7, 11106.0], [69.8, 11123.0], [69.9, 11132.0], [70.0, 11137.0], [70.1, 11147.0], [70.2, 11156.0], [70.3, 11180.0], [70.4, 11187.0], [70.5, 11226.0], [70.6, 11235.0], [70.7, 11266.0], [70.8, 11279.0], [70.9, 11287.0], [71.0, 11294.0], [71.1, 11324.0], [71.2, 11342.0], [71.3, 11351.0], [71.4, 11377.0], [71.5, 11395.0], [71.6, 11404.0], [71.7, 11406.0], [71.8, 11432.0], [71.9, 11442.0], [72.0, 11450.0], [72.1, 11480.0], [72.2, 11484.0], [72.3, 11509.0], [72.4, 11512.0], [72.5, 11529.0], [72.6, 11541.0], [72.7, 11588.0], [72.8, 11603.0], [72.9, 11619.0], [73.0, 11622.0], [73.1, 11659.0], [73.2, 11676.0], [73.3, 11691.0], [73.4, 11700.0], [73.5, 11716.0], [73.6, 11724.0], [73.7, 11748.0], [73.8, 11774.0], [73.9, 11825.0], [74.0, 11830.0], [74.1, 11873.0], [74.2, 11902.0], [74.3, 11927.0], [74.4, 11939.0], [74.5, 11952.0], [74.6, 11963.0], [74.7, 11996.0], [74.8, 12038.0], [74.9, 12058.0], [75.0, 12076.0], [75.1, 12093.0], [75.2, 12099.0], [75.3, 12132.0], [75.4, 12162.0], [75.5, 12234.0], [75.6, 12240.0], [75.7, 12277.0], [75.8, 12304.0], [75.9, 12353.0], [76.0, 12384.0], [76.1, 12421.0], [76.2, 12428.0], [76.3, 12470.0], [76.4, 12493.0], [76.5, 12499.0], [76.6, 12511.0], [76.7, 12569.0], [76.8, 12575.0], [76.9, 12591.0], [77.0, 12594.0], [77.1, 12605.0], [77.2, 12608.0], [77.3, 12623.0], [77.4, 12666.0], [77.5, 12690.0], [77.6, 12705.0], [77.7, 12730.0], [77.8, 12752.0], [77.9, 12775.0], [78.0, 12777.0], [78.1, 12797.0], [78.2, 12805.0], [78.3, 12810.0], [78.4, 12878.0], [78.5, 12907.0], [78.6, 12913.0], [78.7, 12962.0], [78.8, 12979.0], [78.9, 13015.0], [79.0, 13018.0], [79.1, 13054.0], [79.2, 13060.0], [79.3, 13094.0], [79.4, 13105.0], [79.5, 13118.0], [79.6, 13139.0], [79.7, 13157.0], [79.8, 13196.0], [79.9, 13211.0], [80.0, 13239.0], [80.1, 13251.0], [80.2, 13253.0], [80.3, 13260.0], [80.4, 13310.0], [80.5, 13365.0], [80.6, 13387.0], [80.7, 13401.0], [80.8, 13405.0], [80.9, 13435.0], [81.0, 13447.0], [81.1, 13461.0], [81.2, 13495.0], [81.3, 13555.0], [81.4, 13592.0], [81.5, 13607.0], [81.6, 13611.0], [81.7, 13633.0], [81.8, 13646.0], [81.9, 13739.0], [82.0, 13783.0], [82.1, 13835.0], [82.2, 13860.0], [82.3, 13913.0], [82.4, 13958.0], [82.5, 14007.0], [82.6, 14020.0], [82.7, 14046.0], [82.8, 14072.0], [82.9, 14099.0], [83.0, 14132.0], [83.1, 14144.0], [83.2, 14153.0], [83.3, 14194.0], [83.4, 14207.0], [83.5, 14225.0], [83.6, 14303.0], [83.7, 14361.0], [83.8, 14378.0], [83.9, 14395.0], [84.0, 14423.0], [84.1, 14435.0], [84.2, 14442.0], [84.3, 14464.0], [84.4, 14535.0], [84.5, 14559.0], [84.6, 14568.0], [84.7, 14644.0], [84.8, 14752.0], [84.9, 14789.0], [85.0, 14794.0], [85.1, 14834.0], [85.2, 14866.0], [85.3, 14922.0], [85.4, 14945.0], [85.5, 15053.0], [85.6, 15084.0], [85.7, 15153.0], [85.8, 15204.0], [85.9, 15218.0], [86.0, 15224.0], [86.1, 15325.0], [86.2, 15413.0], [86.3, 15438.0], [86.4, 15554.0], [86.5, 15604.0], [86.6, 15660.0], [86.7, 15672.0], [86.8, 15763.0], [86.9, 15790.0], [87.0, 15847.0], [87.1, 15904.0], [87.2, 15917.0], [87.3, 15966.0], [87.4, 15986.0], [87.5, 16034.0], [87.6, 16083.0], [87.7, 16129.0], [87.8, 16156.0], [87.9, 16185.0], [88.0, 16191.0], [88.1, 16201.0], [88.2, 16230.0], [88.3, 16237.0], [88.4, 16331.0], [88.5, 16395.0], [88.6, 16401.0], [88.7, 16421.0], [88.8, 16429.0], [88.9, 16431.0], [89.0, 16476.0], [89.1, 16498.0], [89.2, 16511.0], [89.3, 16522.0], [89.4, 16558.0], [89.5, 16582.0], [89.6, 16585.0], [89.7, 16598.0], [89.8, 16652.0], [89.9, 16670.0], [90.0, 16696.0], [90.1, 16730.0], [90.2, 16772.0], [90.3, 16787.0], [90.4, 16832.0], [90.5, 16856.0], [90.6, 16882.0], [90.7, 16940.0], [90.8, 16976.0], [90.9, 16990.0], [91.0, 17029.0], [91.1, 17073.0], [91.2, 17128.0], [91.3, 17175.0], [91.4, 17191.0], [91.5, 17205.0], [91.6, 17216.0], [91.7, 17224.0], [91.8, 17230.0], [91.9, 17263.0], [92.0, 17298.0], [92.1, 17335.0], [92.2, 17367.0], [92.3, 17428.0], [92.4, 17463.0], [92.5, 17468.0], [92.6, 17619.0], [92.7, 17657.0], [92.8, 17712.0], [92.9, 17742.0], [93.0, 17750.0], [93.1, 17764.0], [93.2, 17799.0], [93.3, 17822.0], [93.4, 17833.0], [93.5, 17904.0], [93.6, 17954.0], [93.7, 17964.0], [93.8, 17982.0], [93.9, 18062.0], [94.0, 18071.0], [94.1, 18089.0], [94.2, 18111.0], [94.3, 18132.0], [94.4, 18161.0], [94.5, 18186.0], [94.6, 18196.0], [94.7, 18300.0], [94.8, 18316.0], [94.9, 18341.0], [95.0, 18372.0], [95.1, 18416.0], [95.2, 18429.0], [95.3, 18459.0], [95.4, 18471.0], [95.5, 18489.0], [95.6, 18510.0], [95.7, 18565.0], [95.8, 18581.0], [95.9, 18625.0], [96.0, 18683.0], [96.1, 18722.0], [96.2, 18760.0], [96.3, 18830.0], [96.4, 18891.0], [96.5, 18907.0], [96.6, 19067.0], [96.7, 19084.0], [96.8, 19088.0], [96.9, 19127.0], [97.0, 19210.0], [97.1, 19221.0], [97.2, 19229.0], [97.3, 19255.0], [97.4, 19277.0], [97.5, 19340.0], [97.6, 19366.0], [97.7, 19402.0], [97.8, 19421.0], [97.9, 19464.0], [98.0, 19582.0], [98.1, 19637.0], [98.2, 19688.0], [98.3, 19744.0], [98.4, 19785.0], [98.5, 19799.0], [98.6, 19859.0], [98.7, 20192.0], [98.8, 20485.0], [98.9, 20786.0], [99.0, 20917.0], [99.1, 21144.0], [99.2, 21258.0], [99.3, 21297.0], [99.4, 21682.0], [99.5, 22095.0], [99.6, 22154.0], [99.7, 22929.0], [99.8, 23509.0], [99.9, 24295.0], [100.0, 24650.0]], "isOverall": false, "label": "Ingest API Firenoc(30)", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 300.0, "maxY": 233.0, "series": [{"data": [[300.0, 34.0], [400.0, 165.0], [500.0, 233.0], [600.0, 157.0], [700.0, 62.0], [800.0, 52.0], [900.0, 32.0], [1000.0, 27.0], [1100.0, 27.0], [1200.0, 16.0], [1300.0, 11.0], [1400.0, 8.0], [1500.0, 8.0], [1600.0, 6.0], [1700.0, 5.0], [1800.0, 10.0], [1900.0, 22.0], [2000.0, 37.0], [2100.0, 23.0], [2200.0, 16.0], [2300.0, 8.0], [2400.0, 4.0], [2500.0, 8.0], [2600.0, 14.0], [2800.0, 10.0], [2700.0, 9.0], [2900.0, 6.0], [3000.0, 1.0], [3200.0, 1.0], [3300.0, 1.0], [3400.0, 1.0], [4100.0, 1.0], [4700.0, 1.0], [5000.0, 1.0], [6100.0, 1.0], [6300.0, 1.0], [6600.0, 2.0], [6400.0, 1.0], [6700.0, 2.0], [6800.0, 2.0], [7000.0, 2.0], [7100.0, 3.0], [7400.0, 6.0], [7300.0, 6.0], [7200.0, 6.0], [7500.0, 8.0], [7600.0, 12.0], [7700.0, 7.0], [7800.0, 9.0], [7900.0, 9.0], [8000.0, 9.0], [8100.0, 13.0], [8600.0, 9.0], [8200.0, 6.0], [8400.0, 8.0], [8700.0, 9.0], [8300.0, 8.0], [8500.0, 2.0], [9100.0, 13.0], [9200.0, 7.0], [8900.0, 9.0], [8800.0, 9.0], [9000.0, 4.0], [9600.0, 14.0], [9400.0, 10.0], [9300.0, 7.0], [9700.0, 12.0], [9500.0, 14.0], [9800.0, 16.0], [10000.0, 19.0], [10200.0, 12.0], [10100.0, 8.0], [9900.0, 11.0], [10400.0, 8.0], [10700.0, 13.0], [10300.0, 15.0], [10600.0, 10.0], [10500.0, 18.0], [11100.0, 15.0], [11200.0, 12.0], [10800.0, 11.0], [10900.0, 15.0], [11000.0, 17.0], [11500.0, 10.0], [11400.0, 14.0], [11300.0, 12.0], [11600.0, 13.0], [11700.0, 9.0], [11800.0, 7.0], [11900.0, 11.0], [12000.0, 11.0], [12100.0, 4.0], [12200.0, 6.0], [12700.0, 11.0], [12500.0, 11.0], [12600.0, 11.0], [12400.0, 10.0], [12300.0, 6.0], [13300.0, 6.0], [12900.0, 7.0], [12800.0, 7.0], [13000.0, 11.0], [13200.0, 11.0], [13100.0, 10.0], [13600.0, 8.0], [13800.0, 3.0], [13500.0, 4.0], [13700.0, 5.0], [13400.0, 12.0], [14300.0, 7.0], [13900.0, 4.0], [14100.0, 9.0], [14000.0, 11.0], [14200.0, 4.0], [14700.0, 7.0], [14500.0, 5.0], [14600.0, 3.0], [14400.0, 9.0], [14800.0, 4.0], [15200.0, 7.0], [15000.0, 4.0], [15300.0, 2.0], [14900.0, 3.0], [15100.0, 2.0], [15600.0, 7.0], [15400.0, 3.0], [15500.0, 3.0], [15800.0, 3.0], [15700.0, 3.0], [16100.0, 9.0], [16200.0, 5.0], [15900.0, 8.0], [16300.0, 6.0], [16000.0, 3.0], [17200.0, 12.0], [16500.0, 12.0], [16700.0, 6.0], [17400.0, 6.0], [16900.0, 6.0], [17300.0, 5.0], [16400.0, 11.0], [16600.0, 6.0], [16800.0, 7.0], [17100.0, 6.0], [17000.0, 4.0], [17600.0, 4.0], [17900.0, 7.0], [17500.0, 1.0], [18000.0, 6.0], [17700.0, 9.0], [17800.0, 5.0], [18100.0, 11.0], [18300.0, 8.0], [18200.0, 1.0], [18400.0, 9.0], [19400.0, 5.0], [18600.0, 5.0], [19100.0, 3.0], [19000.0, 5.0], [18500.0, 6.0], [18700.0, 4.0], [19300.0, 5.0], [19200.0, 9.0], [18800.0, 5.0], [18900.0, 2.0], [20400.0, 2.0], [19700.0, 6.0], [19600.0, 5.0], [19800.0, 2.0], [20300.0, 1.0], [20100.0, 1.0], [19500.0, 2.0], [19900.0, 1.0], [21200.0, 4.0], [21100.0, 1.0], [20900.0, 2.0], [20700.0, 1.0], [20800.0, 1.0], [21600.0, 2.0], [22000.0, 2.0], [22100.0, 1.0], [21700.0, 1.0], [22400.0, 1.0], [22900.0, 1.0], [23500.0, 1.0], [23300.0, 1.0], [24000.0, 1.0], [24200.0, 1.0], [24500.0, 1.0], [24600.0, 1.0]], "isOverall": false, "label": "Ingest API Firenoc(30)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 24600.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 1023.0, "minX": 2.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 1029.0, "series": [{"data": [], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 1023.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 1029.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 20.8169014084507, "minX": 1.64508078E12, "maxY": 25.0, "series": [{"data": [[1.64508096E12, 25.0], [1.64508114E12, 25.0], [1.64508084E12, 25.0], [1.64508132E12, 25.0], [1.64508102E12, 25.0], [1.6450812E12, 25.0], [1.6450809E12, 25.0], [1.64508138E12, 20.8169014084507], [1.64508108E12, 25.0], [1.64508078E12, 25.0], [1.64508126E12, 25.0]], "isOverall": false, "label": "Dashboard API", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64508138E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 6885.816074950673, "minX": 1.0, "maxY": 18316.0, "series": [{"data": [[8.0, 8650.0], [2.0, 13396.0], [9.0, 9260.0], [10.0, 8006.0], [11.0, 10607.0], [12.0, 9382.0], [3.0, 14004.0], [13.0, 11132.0], [14.0, 10650.0], [15.0, 10068.0], [4.0, 15790.0], [1.0, 14789.0], [17.0, 16695.5], [19.0, 16677.0], [20.0, 9533.0], [5.0, 16623.0], [22.0, 11526.5], [23.0, 18316.0], [24.0, 17205.0], [6.0, 16976.0], [25.0, 6885.816074950673], [7.0, 16421.0]], "isOverall": false, "label": "Ingest API Firenoc(30)", "isController": false}, {"data": [[24.855263157894733, 6961.520955165675]], "isOverall": false, "label": "Ingest API Firenoc(30)-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 25.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 699.2833333333333, "minX": 1.64508078E12, "maxY": 2851121.0, "series": [{"data": [[1.64508096E12, 2339.8], [1.64508114E12, 5264.05], [1.64508084E12, 2159.5], [1.64508132E12, 2439.2166666666667], [1.64508102E12, 2319.85], [1.6450812E12, 2399.6], [1.6450809E12, 2238.883333333333], [1.64508138E12, 1419.3833333333334], [1.64508108E12, 11543.783333333333], [1.64508078E12, 699.2833333333333], [1.64508126E12, 2239.5666666666666]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.64508096E12, 418021.5], [1.64508114E12, 1218336.1666666667], [1.64508084E12, 385866.0], [1.64508132E12, 435885.6666666667], [1.64508102E12, 414448.6666666667], [1.6450812E12, 428740.0], [1.6450809E12, 400157.3333333333], [1.64508138E12, 253671.16666666666], [1.64508108E12, 2851121.0], [1.64508078E12, 125049.16666666667], [1.64508126E12, 400157.3333333333]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64508138E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 1722.1516290726797, "minX": 1.64508078E12, "maxY": 16202.57142857143, "series": [{"data": [[1.64508096E12, 12520.179487179483], [1.64508114E12, 3391.0117302052786], [1.64508084E12, 13701.268518518515], [1.64508132E12, 12430.204918032789], [1.64508102E12, 12374.293103448279], [1.6450812E12, 12901.983333333332], [1.6450809E12, 12662.937500000002], [1.64508138E12, 13515.507042253517], [1.64508108E12, 1722.1516290726797], [1.64508078E12, 16202.57142857143], [1.64508126E12, 12185.267857142853]], "isOverall": false, "label": "Ingest API Firenoc(30)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64508138E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 1722.0814536340863, "minX": 1.64508078E12, "maxY": 16202.4, "series": [{"data": [[1.64508096E12, 12519.81196581197], [1.64508114E12, 3390.9325513196477], [1.64508084E12, 13701.194444444442], [1.64508132E12, 12430.090163934421], [1.64508102E12, 12374.017241379308], [1.6450812E12, 12901.83333333333], [1.6450809E12, 12662.830357142857], [1.64508138E12, 13515.253521126762], [1.64508108E12, 1722.0814536340863], [1.64508078E12, 16202.4], [1.64508126E12, 12170.94642857143]], "isOverall": false, "label": "Ingest API Firenoc(30)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64508138E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 126.92857142857142, "minX": 1.64508078E12, "maxY": 501.15162907268206, "series": [{"data": [[1.64508096E12, 131.21367521367517], [1.64508114E12, 439.1231671554254], [1.64508084E12, 127.82407407407408], [1.64508132E12, 176.61475409836058], [1.64508102E12, 138.4137931034482], [1.6450812E12, 208.15833333333336], [1.6450809E12, 126.92857142857142], [1.64508138E12, 173.70422535211267], [1.64508108E12, 501.15162907268206], [1.64508078E12, 133.65714285714284], [1.64508126E12, 254.21428571428564]], "isOverall": false, "label": "Ingest API Firenoc(30)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64508138E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 6174.0, "minX": 1.64508078E12, "maxY": 24650.0, "series": [{"data": [[1.64508096E12, 19430.0], [1.64508114E12, 22154.0], [1.64508084E12, 24539.0], [1.64508132E12, 21258.0], [1.64508102E12, 20918.0], [1.6450812E12, 24650.0], [1.6450809E12, 19704.0], [1.64508138E12, 22446.0], [1.64508108E12, 22095.0], [1.64508078E12, 24295.0], [1.64508126E12, 22097.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.64508096E12, 17734.0], [1.64508114E12, 19410.9], [1.64508084E12, 17856.500000000004], [1.64508132E12, 18523.0], [1.64508102E12, 17303.3], [1.6450812E12, 18464.6], [1.6450809E12, 17501.600000000002], [1.64508138E12, 19702.0], [1.64508108E12, 18638.100000000002], [1.64508078E12, 21403.6], [1.64508126E12, 18621.7]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.64508096E12, 19392.379999999997], [1.64508114E12, 22154.0], [1.64508084E12, 24394.099999999995], [1.64508132E12, 21179.57], [1.64508102E12, 20653.819999999996], [1.6450812E12, 24410.389999999992], [1.6450809E12, 19699.71], [1.64508138E12, 22446.0], [1.64508108E12, 22095.0], [1.64508078E12, 24295.0], [1.64508126E12, 21887.440000000006]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.64508096E12, 18519.2], [1.64508114E12, 20257.8], [1.64508084E12, 19634.75], [1.64508132E12, 19080.6], [1.64508102E12, 18237.55], [1.6450812E12, 19576.1], [1.6450809E12, 18714.5], [1.64508138E12, 21027.999999999996], [1.64508108E12, 19970.799999999992], [1.64508078E12, 24137.399999999998], [1.64508126E12, 19289.55]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.64508096E12, 7269.0], [1.64508114E12, 6174.0], [1.64508084E12, 8072.0], [1.64508132E12, 6840.0], [1.64508102E12, 7124.0], [1.6450812E12, 6673.0], [1.6450809E12, 6771.0], [1.64508138E12, 7879.0], [1.64508108E12, 7617.0], [1.64508078E12, 9670.0], [1.64508126E12, 6498.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.64508096E12, 12493.0], [1.64508114E12, 11954.5], [1.64508084E12, 13851.0], [1.64508132E12, 11181.0], [1.64508102E12, 12057.0], [1.6450812E12, 11779.0], [1.6450809E12, 12059.0], [1.64508138E12, 12705.0], [1.64508108E12, 12194.5], [1.64508078E12, 15675.0], [1.64508126E12, 11035.5]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64508138E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 527.0, "minX": 1.0, "maxY": 16498.0, "series": [{"data": [[1.0, 11697.5], [4.0, 12563.5], [2.0, 11225.5], [8.0, 13625.5], [5.0, 12633.0], [3.0, 12606.0], [6.0, 12661.0], [7.0, 12591.0], [28.0, 16498.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[2.0, 1153.0], [11.0, 622.0], [3.0, 2215.0], [13.0, 574.0], [15.0, 659.0], [1.0, 1826.0], [16.0, 2135.5], [17.0, 604.0], [18.0, 1123.5], [19.0, 623.0], [5.0, 1975.5], [20.0, 793.5], [21.0, 682.5], [22.0, 582.0], [23.0, 827.0], [24.0, 587.0], [6.0, 597.0], [25.0, 751.5], [26.0, 670.0], [27.0, 551.0], [28.0, 559.0], [7.0, 2043.0], [29.0, 590.0], [30.0, 527.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 30.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 527.0, "minX": 1.0, "maxY": 16498.0, "series": [{"data": [[1.0, 11697.5], [4.0, 12562.5], [2.0, 11225.5], [8.0, 13625.5], [5.0, 12633.0], [3.0, 12606.0], [6.0, 12660.5], [7.0, 12591.0], [28.0, 16498.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[2.0, 1153.0], [11.0, 622.0], [3.0, 2215.0], [13.0, 574.0], [15.0, 659.0], [1.0, 1826.0], [16.0, 2135.5], [17.0, 604.0], [18.0, 1123.5], [19.0, 623.0], [5.0, 1975.5], [20.0, 793.5], [21.0, 682.5], [22.0, 582.0], [23.0, 827.0], [24.0, 587.0], [6.0, 597.0], [25.0, 751.5], [26.0, 670.0], [27.0, 551.0], [28.0, 559.0], [7.0, 2043.0], [29.0, 590.0], [30.0, 527.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 30.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.7666666666666667, "minX": 1.64508078E12, "maxY": 13.116666666666667, "series": [{"data": [[1.64508096E12, 2.0], [1.64508114E12, 5.883333333333334], [1.64508084E12, 1.7833333333333334], [1.64508132E12, 2.033333333333333], [1.64508102E12, 1.9166666666666667], [1.6450812E12, 1.9666666666666666], [1.6450809E12, 1.8333333333333333], [1.64508138E12, 0.7666666666666667], [1.64508108E12, 13.116666666666667], [1.64508078E12, 1.0], [1.64508126E12, 1.9]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64508138E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.5833333333333334, "minX": 1.64508078E12, "maxY": 11.516666666666667, "series": [{"data": [[1.64508096E12, 1.95], [1.64508114E12, 1.2], [1.64508084E12, 1.8], [1.64508132E12, 2.033333333333333], [1.64508102E12, 1.9333333333333333], [1.6450812E12, 2.0], [1.6450809E12, 1.8666666666666667], [1.64508138E12, 1.1833333333333333], [1.64508108E12, 0.6333333333333333], [1.64508078E12, 0.5833333333333334], [1.64508126E12, 1.8666666666666667]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.64508108E12, 1.15]], "isOverall": false, "label": "502", "isController": false}, {"data": [[1.64508114E12, 4.483333333333333], [1.64508108E12, 11.516666666666667]], "isOverall": false, "label": "503", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64508138E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.5833333333333334, "minX": 1.64508078E12, "maxY": 12.666666666666666, "series": [{"data": [[1.64508114E12, 4.483333333333333], [1.64508108E12, 12.666666666666666]], "isOverall": false, "label": "Ingest API Firenoc(30)-failure", "isController": false}, {"data": [[1.64508096E12, 1.95], [1.64508114E12, 1.2], [1.64508084E12, 1.8], [1.64508132E12, 2.033333333333333], [1.64508102E12, 1.9333333333333333], [1.6450812E12, 2.0], [1.6450809E12, 1.8666666666666667], [1.64508138E12, 1.1833333333333333], [1.64508108E12, 0.6333333333333333], [1.64508078E12, 0.5833333333333334], [1.64508126E12, 1.8666666666666667]], "isOverall": false, "label": "Ingest API Firenoc(30)-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64508138E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.5833333333333334, "minX": 1.64508078E12, "maxY": 12.666666666666666, "series": [{"data": [[1.64508096E12, 1.95], [1.64508114E12, 1.2], [1.64508084E12, 1.8], [1.64508132E12, 2.033333333333333], [1.64508102E12, 1.9333333333333333], [1.6450812E12, 2.0], [1.6450809E12, 1.8666666666666667], [1.64508138E12, 1.1833333333333333], [1.64508108E12, 0.6333333333333333], [1.64508078E12, 0.5833333333333334], [1.64508126E12, 1.8666666666666667]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.64508114E12, 4.483333333333333], [1.64508108E12, 12.666666666666666]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64508138E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

