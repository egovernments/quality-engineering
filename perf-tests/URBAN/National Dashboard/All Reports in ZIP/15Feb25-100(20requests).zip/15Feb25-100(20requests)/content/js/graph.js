/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 359.0, "minX": 0.0, "maxY": 60653.0, "series": [{"data": [[0.0, 359.0], [0.1, 366.0], [0.2, 378.0], [0.3, 385.0], [0.4, 390.0], [0.5, 392.0], [0.6, 402.0], [0.7, 405.0], [0.8, 407.0], [0.9, 410.0], [1.0, 411.0], [1.1, 417.0], [1.2, 429.0], [1.3, 429.0], [1.4, 437.0], [1.5, 447.0], [1.6, 449.0], [1.7, 456.0], [1.8, 457.0], [1.9, 461.0], [2.0, 465.0], [2.1, 465.0], [2.2, 465.0], [2.3, 469.0], [2.4, 469.0], [2.5, 470.0], [2.6, 474.0], [2.7, 475.0], [2.8, 476.0], [2.9, 486.0], [3.0, 487.0], [3.1, 487.0], [3.2, 489.0], [3.3, 490.0], [3.4, 492.0], [3.5, 493.0], [3.6, 494.0], [3.7, 496.0], [3.8, 497.0], [3.9, 498.0], [4.0, 503.0], [4.1, 503.0], [4.2, 504.0], [4.3, 508.0], [4.4, 509.0], [4.5, 512.0], [4.6, 514.0], [4.7, 514.0], [4.8, 515.0], [4.9, 519.0], [5.0, 519.0], [5.1, 521.0], [5.2, 522.0], [5.3, 523.0], [5.4, 527.0], [5.5, 529.0], [5.6, 531.0], [5.7, 535.0], [5.8, 535.0], [5.9, 536.0], [6.0, 540.0], [6.1, 541.0], [6.2, 544.0], [6.3, 545.0], [6.4, 546.0], [6.5, 549.0], [6.6, 551.0], [6.7, 552.0], [6.8, 554.0], [6.9, 555.0], [7.0, 556.0], [7.1, 557.0], [7.2, 557.0], [7.3, 559.0], [7.4, 562.0], [7.5, 567.0], [7.6, 567.0], [7.7, 569.0], [7.8, 570.0], [7.9, 572.0], [8.0, 576.0], [8.1, 576.0], [8.2, 579.0], [8.3, 580.0], [8.4, 581.0], [8.5, 583.0], [8.6, 585.0], [8.7, 586.0], [8.8, 586.0], [8.9, 588.0], [9.0, 590.0], [9.1, 592.0], [9.2, 593.0], [9.3, 593.0], [9.4, 593.0], [9.5, 593.0], [9.6, 594.0], [9.7, 602.0], [9.8, 602.0], [9.9, 603.0], [10.0, 604.0], [10.1, 604.0], [10.2, 605.0], [10.3, 609.0], [10.4, 610.0], [10.5, 610.0], [10.6, 612.0], [10.7, 613.0], [10.8, 615.0], [10.9, 616.0], [11.0, 617.0], [11.1, 620.0], [11.2, 621.0], [11.3, 622.0], [11.4, 624.0], [11.5, 625.0], [11.6, 627.0], [11.7, 629.0], [11.8, 630.0], [11.9, 630.0], [12.0, 634.0], [12.1, 638.0], [12.2, 639.0], [12.3, 642.0], [12.4, 642.0], [12.5, 643.0], [12.6, 646.0], [12.7, 646.0], [12.8, 649.0], [12.9, 652.0], [13.0, 652.0], [13.1, 654.0], [13.2, 659.0], [13.3, 659.0], [13.4, 659.0], [13.5, 660.0], [13.6, 661.0], [13.7, 662.0], [13.8, 664.0], [13.9, 664.0], [14.0, 667.0], [14.1, 668.0], [14.2, 669.0], [14.3, 675.0], [14.4, 675.0], [14.5, 678.0], [14.6, 680.0], [14.7, 681.0], [14.8, 683.0], [14.9, 691.0], [15.0, 695.0], [15.1, 697.0], [15.2, 698.0], [15.3, 699.0], [15.4, 703.0], [15.5, 703.0], [15.6, 704.0], [15.7, 709.0], [15.8, 709.0], [15.9, 710.0], [16.0, 711.0], [16.1, 712.0], [16.2, 717.0], [16.3, 720.0], [16.4, 720.0], [16.5, 722.0], [16.6, 722.0], [16.7, 723.0], [16.8, 725.0], [16.9, 726.0], [17.0, 727.0], [17.1, 743.0], [17.2, 743.0], [17.3, 743.0], [17.4, 745.0], [17.5, 746.0], [17.6, 746.0], [17.7, 750.0], [17.8, 751.0], [17.9, 752.0], [18.0, 752.0], [18.1, 756.0], [18.2, 759.0], [18.3, 760.0], [18.4, 762.0], [18.5, 762.0], [18.6, 770.0], [18.7, 772.0], [18.8, 773.0], [18.9, 774.0], [19.0, 775.0], [19.1, 781.0], [19.2, 785.0], [19.3, 785.0], [19.4, 788.0], [19.5, 792.0], [19.6, 793.0], [19.7, 796.0], [19.8, 796.0], [19.9, 800.0], [20.0, 801.0], [20.1, 803.0], [20.2, 808.0], [20.3, 813.0], [20.4, 814.0], [20.5, 818.0], [20.6, 818.0], [20.7, 818.0], [20.8, 827.0], [20.9, 828.0], [21.0, 834.0], [21.1, 835.0], [21.2, 842.0], [21.3, 844.0], [21.4, 846.0], [21.5, 847.0], [21.6, 848.0], [21.7, 848.0], [21.8, 848.0], [21.9, 853.0], [22.0, 854.0], [22.1, 856.0], [22.2, 858.0], [22.3, 862.0], [22.4, 868.0], [22.5, 876.0], [22.6, 876.0], [22.7, 881.0], [22.8, 883.0], [22.9, 884.0], [23.0, 885.0], [23.1, 886.0], [23.2, 887.0], [23.3, 890.0], [23.4, 890.0], [23.5, 890.0], [23.6, 893.0], [23.7, 897.0], [23.8, 900.0], [23.9, 900.0], [24.0, 905.0], [24.1, 906.0], [24.2, 907.0], [24.3, 910.0], [24.4, 914.0], [24.5, 917.0], [24.6, 917.0], [24.7, 919.0], [24.8, 922.0], [24.9, 926.0], [25.0, 931.0], [25.1, 937.0], [25.2, 938.0], [25.3, 941.0], [25.4, 942.0], [25.5, 943.0], [25.6, 950.0], [25.7, 952.0], [25.8, 961.0], [25.9, 962.0], [26.0, 962.0], [26.1, 963.0], [26.2, 967.0], [26.3, 968.0], [26.4, 970.0], [26.5, 982.0], [26.6, 992.0], [26.7, 994.0], [26.8, 999.0], [26.9, 1003.0], [27.0, 1011.0], [27.1, 1015.0], [27.2, 1022.0], [27.3, 1024.0], [27.4, 1027.0], [27.5, 1031.0], [27.6, 1033.0], [27.7, 1034.0], [27.8, 1038.0], [27.9, 1039.0], [28.0, 1041.0], [28.1, 1042.0], [28.2, 1050.0], [28.3, 1050.0], [28.4, 1052.0], [28.5, 1056.0], [28.6, 1058.0], [28.7, 1069.0], [28.8, 1069.0], [28.9, 1076.0], [29.0, 1081.0], [29.1, 1087.0], [29.2, 1087.0], [29.3, 1093.0], [29.4, 1093.0], [29.5, 1095.0], [29.6, 1100.0], [29.7, 1101.0], [29.8, 1101.0], [29.9, 1108.0], [30.0, 1108.0], [30.1, 1113.0], [30.2, 1118.0], [30.3, 1118.0], [30.4, 1124.0], [30.5, 1131.0], [30.6, 1139.0], [30.7, 1145.0], [30.8, 1145.0], [30.9, 1146.0], [31.0, 1151.0], [31.1, 1151.0], [31.2, 1151.0], [31.3, 1161.0], [31.4, 1163.0], [31.5, 1166.0], [31.6, 1178.0], [31.7, 1179.0], [31.8, 1180.0], [31.9, 1182.0], [32.0, 1183.0], [32.1, 1186.0], [32.2, 1191.0], [32.3, 1197.0], [32.4, 1201.0], [32.5, 1202.0], [32.6, 1202.0], [32.7, 1207.0], [32.8, 1207.0], [32.9, 1207.0], [33.0, 1212.0], [33.1, 1213.0], [33.2, 1215.0], [33.3, 1221.0], [33.4, 1223.0], [33.5, 1223.0], [33.6, 1226.0], [33.7, 1228.0], [33.8, 1230.0], [33.9, 1232.0], [34.0, 1232.0], [34.1, 1236.0], [34.2, 1237.0], [34.3, 1240.0], [34.4, 1245.0], [34.5, 1249.0], [34.6, 1253.0], [34.7, 1257.0], [34.8, 1259.0], [34.9, 1261.0], [35.0, 1268.0], [35.1, 1269.0], [35.2, 1270.0], [35.3, 1274.0], [35.4, 1277.0], [35.5, 1277.0], [35.6, 1278.0], [35.7, 1279.0], [35.8, 1280.0], [35.9, 1283.0], [36.0, 1285.0], [36.1, 1290.0], [36.2, 1293.0], [36.3, 1294.0], [36.4, 1303.0], [36.5, 1306.0], [36.6, 1307.0], [36.7, 1316.0], [36.8, 1317.0], [36.9, 1319.0], [37.0, 1321.0], [37.1, 1325.0], [37.2, 1326.0], [37.3, 1327.0], [37.4, 1328.0], [37.5, 1334.0], [37.6, 1336.0], [37.7, 1347.0], [37.8, 1349.0], [37.9, 1353.0], [38.0, 1355.0], [38.1, 1356.0], [38.2, 1359.0], [38.3, 1361.0], [38.4, 1361.0], [38.5, 1363.0], [38.6, 1365.0], [38.7, 1370.0], [38.8, 1376.0], [38.9, 1379.0], [39.0, 1386.0], [39.1, 1386.0], [39.2, 1387.0], [39.3, 1390.0], [39.4, 1390.0], [39.5, 1392.0], [39.6, 1394.0], [39.7, 1394.0], [39.8, 1397.0], [39.9, 1398.0], [40.0, 1398.0], [40.1, 1400.0], [40.2, 1400.0], [40.3, 1400.0], [40.4, 1410.0], [40.5, 1411.0], [40.6, 1418.0], [40.7, 1422.0], [40.8, 1423.0], [40.9, 1425.0], [41.0, 1428.0], [41.1, 1430.0], [41.2, 1435.0], [41.3, 1436.0], [41.4, 1437.0], [41.5, 1441.0], [41.6, 1452.0], [41.7, 1454.0], [41.8, 1459.0], [41.9, 1460.0], [42.0, 1460.0], [42.1, 1464.0], [42.2, 1471.0], [42.3, 1473.0], [42.4, 1480.0], [42.5, 1483.0], [42.6, 1486.0], [42.7, 1489.0], [42.8, 1497.0], [42.9, 1498.0], [43.0, 1499.0], [43.1, 1500.0], [43.2, 1502.0], [43.3, 1503.0], [43.4, 1504.0], [43.5, 1508.0], [43.6, 1510.0], [43.7, 1516.0], [43.8, 1520.0], [43.9, 1525.0], [44.0, 1526.0], [44.1, 1529.0], [44.2, 1531.0], [44.3, 1531.0], [44.4, 1533.0], [44.5, 1533.0], [44.6, 1542.0], [44.7, 1543.0], [44.8, 1550.0], [44.9, 1556.0], [45.0, 1557.0], [45.1, 1559.0], [45.2, 1562.0], [45.3, 1562.0], [45.4, 1564.0], [45.5, 1568.0], [45.6, 1572.0], [45.7, 1575.0], [45.8, 1587.0], [45.9, 1592.0], [46.0, 1596.0], [46.1, 1620.0], [46.2, 1636.0], [46.3, 1641.0], [46.4, 1644.0], [46.5, 1657.0], [46.6, 1659.0], [46.7, 1659.0], [46.8, 1663.0], [46.9, 1664.0], [47.0, 1676.0], [47.1, 1676.0], [47.2, 1681.0], [47.3, 1682.0], [47.4, 1687.0], [47.5, 1691.0], [47.6, 1695.0], [47.7, 1695.0], [47.8, 1701.0], [47.9, 1702.0], [48.0, 1708.0], [48.1, 1713.0], [48.2, 1713.0], [48.3, 1719.0], [48.4, 1720.0], [48.5, 1721.0], [48.6, 1725.0], [48.7, 1726.0], [48.8, 1726.0], [48.9, 1731.0], [49.0, 1736.0], [49.1, 1736.0], [49.2, 1743.0], [49.3, 1743.0], [49.4, 1749.0], [49.5, 1759.0], [49.6, 1760.0], [49.7, 1761.0], [49.8, 1764.0], [49.9, 1770.0], [50.0, 1778.0], [50.1, 1783.0], [50.2, 1785.0], [50.3, 1817.0], [50.4, 1818.0], [50.5, 1823.0], [50.6, 1831.0], [50.7, 1848.0], [50.8, 1852.0], [50.9, 1865.0], [51.0, 1872.0], [51.1, 1880.0], [51.2, 1881.0], [51.3, 1888.0], [51.4, 1890.0], [51.5, 1891.0], [51.6, 1892.0], [51.7, 1896.0], [51.8, 1903.0], [51.9, 1911.0], [52.0, 1917.0], [52.1, 1918.0], [52.2, 1924.0], [52.3, 1928.0], [52.4, 1930.0], [52.5, 1937.0], [52.6, 1940.0], [52.7, 1940.0], [52.8, 1957.0], [52.9, 1960.0], [53.0, 1963.0], [53.1, 1965.0], [53.2, 1974.0], [53.3, 1975.0], [53.4, 1990.0], [53.5, 1991.0], [53.6, 1993.0], [53.7, 2009.0], [53.8, 2017.0], [53.9, 2024.0], [54.0, 2029.0], [54.1, 2030.0], [54.2, 2035.0], [54.3, 2068.0], [54.4, 2072.0], [54.5, 2079.0], [54.6, 2085.0], [54.7, 2091.0], [54.8, 2092.0], [54.9, 2109.0], [55.0, 2110.0], [55.1, 2114.0], [55.2, 2130.0], [55.3, 2135.0], [55.4, 2146.0], [55.5, 2147.0], [55.6, 2151.0], [55.7, 2177.0], [55.8, 2180.0], [55.9, 2182.0], [56.0, 2206.0], [56.1, 2211.0], [56.2, 2219.0], [56.3, 2222.0], [56.4, 2222.0], [56.5, 2228.0], [56.6, 2243.0], [56.7, 2243.0], [56.8, 2259.0], [56.9, 2265.0], [57.0, 2267.0], [57.1, 2279.0], [57.2, 2308.0], [57.3, 2313.0], [57.4, 2316.0], [57.5, 2320.0], [57.6, 2321.0], [57.7, 2326.0], [57.8, 2333.0], [57.9, 2336.0], [58.0, 2351.0], [58.1, 2358.0], [58.2, 2361.0], [58.3, 2367.0], [58.4, 2368.0], [58.5, 2373.0], [58.6, 2376.0], [58.7, 2382.0], [58.8, 2387.0], [58.9, 2398.0], [59.0, 2412.0], [59.1, 2426.0], [59.2, 2431.0], [59.3, 2454.0], [59.4, 2469.0], [59.5, 2470.0], [59.6, 2472.0], [59.7, 2499.0], [59.8, 2514.0], [59.9, 2540.0], [60.0, 2544.0], [60.1, 2545.0], [60.2, 2550.0], [60.3, 2592.0], [60.4, 2605.0], [60.5, 2613.0], [60.6, 2631.0], [60.7, 2645.0], [60.8, 2674.0], [60.9, 2677.0], [61.0, 2699.0], [61.1, 2727.0], [61.2, 2735.0], [61.3, 2762.0], [61.4, 2787.0], [61.5, 2788.0], [61.6, 2801.0], [61.7, 2860.0], [61.8, 2861.0], [61.9, 2870.0], [62.0, 2897.0], [62.1, 2953.0], [62.2, 2957.0], [62.3, 2983.0], [62.4, 2988.0], [62.5, 3019.0], [62.6, 3043.0], [62.7, 3068.0], [62.8, 3101.0], [62.9, 3101.0], [63.0, 3114.0], [63.1, 3134.0], [63.2, 3134.0], [63.3, 3137.0], [63.4, 3161.0], [63.5, 3215.0], [63.6, 3217.0], [63.7, 3267.0], [63.8, 3270.0], [63.9, 3276.0], [64.0, 3282.0], [64.1, 3295.0], [64.2, 3316.0], [64.3, 3375.0], [64.4, 3386.0], [64.5, 3418.0], [64.6, 3421.0], [64.7, 3451.0], [64.8, 3485.0], [64.9, 3492.0], [65.0, 3514.0], [65.1, 3546.0], [65.2, 3573.0], [65.3, 3580.0], [65.4, 3600.0], [65.5, 3603.0], [65.6, 3606.0], [65.7, 3625.0], [65.8, 3667.0], [65.9, 3690.0], [66.0, 3708.0], [66.1, 3714.0], [66.2, 3737.0], [66.3, 3763.0], [66.4, 3778.0], [66.5, 3831.0], [66.6, 3867.0], [66.7, 3872.0], [66.8, 3929.0], [66.9, 3940.0], [67.0, 3944.0], [67.1, 3983.0], [67.2, 4002.0], [67.3, 4003.0], [67.4, 4013.0], [67.5, 4015.0], [67.6, 4017.0], [67.7, 4080.0], [67.8, 4107.0], [67.9, 4271.0], [68.0, 4272.0], [68.1, 4302.0], [68.2, 4346.0], [68.3, 4390.0], [68.4, 4466.0], [68.5, 4499.0], [68.6, 4534.0], [68.7, 4575.0], [68.8, 4605.0], [68.9, 4622.0], [69.0, 4625.0], [69.1, 4709.0], [69.2, 4710.0], [69.3, 4721.0], [69.4, 4734.0], [69.5, 4736.0], [69.6, 4781.0], [69.7, 4794.0], [69.8, 4801.0], [69.9, 4828.0], [70.0, 4843.0], [70.1, 4847.0], [70.2, 4876.0], [70.3, 4897.0], [70.4, 4915.0], [70.5, 4938.0], [70.6, 4969.0], [70.7, 4978.0], [70.8, 5074.0], [70.9, 5118.0], [71.0, 5150.0], [71.1, 5213.0], [71.2, 5256.0], [71.3, 5368.0], [71.4, 5439.0], [71.5, 5489.0], [71.6, 5562.0], [71.7, 5579.0], [71.8, 5623.0], [71.9, 5856.0], [72.0, 5866.0], [72.1, 5894.0], [72.2, 5908.0], [72.3, 5914.0], [72.4, 5914.0], [72.5, 5939.0], [72.6, 5954.0], [72.7, 5978.0], [72.8, 6113.0], [72.9, 6240.0], [73.0, 6424.0], [73.1, 6579.0], [73.2, 6604.0], [73.3, 6697.0], [73.4, 6715.0], [73.5, 6855.0], [73.6, 6870.0], [73.7, 6875.0], [73.8, 7014.0], [73.9, 7105.0], [74.0, 7162.0], [74.1, 7218.0], [74.2, 7257.0], [74.3, 7515.0], [74.4, 7541.0], [74.5, 7759.0], [74.6, 7804.0], [74.7, 7910.0], [74.8, 8118.0], [74.9, 8129.0], [75.0, 8164.0], [75.1, 8249.0], [75.2, 8307.0], [75.3, 8328.0], [75.4, 8423.0], [75.5, 8424.0], [75.6, 8687.0], [75.7, 8696.0], [75.8, 8771.0], [75.9, 8872.0], [76.0, 9007.0], [76.1, 9049.0], [76.2, 9114.0], [76.3, 9122.0], [76.4, 9265.0], [76.5, 9352.0], [76.6, 9470.0], [76.7, 9472.0], [76.8, 9697.0], [76.9, 9748.0], [77.0, 9987.0], [77.1, 10099.0], [77.2, 10264.0], [77.3, 10347.0], [77.4, 10666.0], [77.5, 10707.0], [77.6, 10734.0], [77.7, 10786.0], [77.8, 10794.0], [77.9, 10851.0], [78.0, 10895.0], [78.1, 10903.0], [78.2, 11139.0], [78.3, 11168.0], [78.4, 11178.0], [78.5, 11290.0], [78.6, 11475.0], [78.7, 11758.0], [78.8, 11948.0], [78.9, 11995.0], [79.0, 12045.0], [79.1, 12317.0], [79.2, 12391.0], [79.3, 12456.0], [79.4, 12512.0], [79.5, 12904.0], [79.6, 13056.0], [79.7, 13296.0], [79.8, 13446.0], [79.9, 13646.0], [80.0, 13680.0], [80.1, 13690.0], [80.2, 13754.0], [80.3, 13815.0], [80.4, 13882.0], [80.5, 13970.0], [80.6, 13972.0], [80.7, 14588.0], [80.8, 14748.0], [80.9, 14774.0], [81.0, 15030.0], [81.1, 15366.0], [81.2, 15616.0], [81.3, 15662.0], [81.4, 15701.0], [81.5, 15759.0], [81.6, 16061.0], [81.7, 16207.0], [81.8, 16300.0], [81.9, 16529.0], [82.0, 16842.0], [82.1, 17635.0], [82.2, 18457.0], [82.3, 19151.0], [82.4, 20154.0], [82.5, 20307.0], [82.6, 20377.0], [82.7, 21277.0], [82.8, 21345.0], [82.9, 21560.0], [83.0, 21663.0], [83.1, 21720.0], [83.2, 21772.0], [83.3, 21886.0], [83.4, 21963.0], [83.5, 21976.0], [83.6, 22093.0], [83.7, 22184.0], [83.8, 22278.0], [83.9, 22666.0], [84.0, 22931.0], [84.1, 22975.0], [84.2, 23286.0], [84.3, 23518.0], [84.4, 23764.0], [84.5, 23898.0], [84.6, 24002.0], [84.7, 24920.0], [84.8, 25281.0], [84.9, 26259.0], [85.0, 26851.0], [85.1, 27163.0], [85.2, 27564.0], [85.3, 27875.0], [85.4, 27961.0], [85.5, 28024.0], [85.6, 28481.0], [85.7, 29042.0], [85.8, 29642.0], [85.9, 29878.0], [86.0, 30114.0], [86.1, 30295.0], [86.2, 30353.0], [86.3, 30535.0], [86.4, 30593.0], [86.5, 30662.0], [86.6, 30925.0], [86.7, 31069.0], [86.8, 31933.0], [86.9, 32307.0], [87.0, 33171.0], [87.1, 33275.0], [87.2, 33444.0], [87.3, 36030.0], [87.4, 36750.0], [87.5, 39175.0], [87.6, 41191.0], [87.7, 41935.0], [87.8, 43465.0], [87.9, 44897.0], [88.0, 47711.0], [88.1, 51616.0], [88.2, 51947.0], [88.3, 52337.0], [88.4, 55667.0], [88.5, 59621.0], [88.6, 60273.0], [88.7, 60275.0], [88.8, 60275.0], [88.9, 60275.0], [89.0, 60275.0], [89.1, 60276.0], [89.2, 60276.0], [89.3, 60277.0], [89.4, 60277.0], [89.5, 60277.0], [89.6, 60278.0], [89.7, 60279.0], [89.8, 60279.0], [89.9, 60279.0], [90.0, 60279.0], [90.1, 60279.0], [90.2, 60279.0], [90.3, 60279.0], [90.4, 60280.0], [90.5, 60280.0], [90.6, 60280.0], [90.7, 60280.0], [90.8, 60280.0], [90.9, 60280.0], [91.0, 60280.0], [91.1, 60280.0], [91.2, 60281.0], [91.3, 60281.0], [91.4, 60281.0], [91.5, 60282.0], [91.6, 60282.0], [91.7, 60282.0], [91.8, 60282.0], [91.9, 60282.0], [92.0, 60282.0], [92.1, 60283.0], [92.2, 60283.0], [92.3, 60283.0], [92.4, 60283.0], [92.5, 60283.0], [92.6, 60283.0], [92.7, 60283.0], [92.8, 60284.0], [92.9, 60284.0], [93.0, 60284.0], [93.1, 60284.0], [93.2, 60284.0], [93.3, 60284.0], [93.4, 60284.0], [93.5, 60284.0], [93.6, 60285.0], [93.7, 60285.0], [93.8, 60285.0], [93.9, 60285.0], [94.0, 60285.0], [94.1, 60285.0], [94.2, 60285.0], [94.3, 60285.0], [94.4, 60286.0], [94.5, 60286.0], [94.6, 60286.0], [94.7, 60286.0], [94.8, 60287.0], [94.9, 60287.0], [95.0, 60288.0], [95.1, 60288.0], [95.2, 60288.0], [95.3, 60288.0], [95.4, 60289.0], [95.5, 60290.0], [95.6, 60290.0], [95.7, 60290.0], [95.8, 60291.0], [95.9, 60291.0], [96.0, 60291.0], [96.1, 60292.0], [96.2, 60292.0], [96.3, 60293.0], [96.4, 60294.0], [96.5, 60294.0], [96.6, 60294.0], [96.7, 60295.0], [96.8, 60296.0], [96.9, 60296.0], [97.0, 60297.0], [97.1, 60297.0], [97.2, 60299.0], [97.3, 60301.0], [97.4, 60301.0], [97.5, 60303.0], [97.6, 60304.0], [97.7, 60304.0], [97.8, 60305.0], [97.9, 60306.0], [98.0, 60307.0], [98.1, 60308.0], [98.2, 60309.0], [98.3, 60310.0], [98.4, 60310.0], [98.5, 60310.0], [98.6, 60318.0], [98.7, 60320.0], [98.8, 60323.0], [98.9, 60325.0], [99.0, 60327.0], [99.1, 60327.0], [99.2, 60335.0], [99.3, 60335.0], [99.4, 60339.0], [99.5, 60380.0], [99.6, 60393.0], [99.7, 60470.0], [99.8, 60651.0], [99.9, 60653.0]], "isOverall": false, "label": "Ingest API Firenoc(20)", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 300.0, "maxY": 118.0, "series": [{"data": [[47700.0, 1.0], [300.0, 8.0], [400.0, 45.0], [500.0, 77.0], [600.0, 77.0], [700.0, 62.0], [800.0, 52.0], [900.0, 42.0], [1000.0, 37.0], [1100.0, 38.0], [1200.0, 54.0], [1300.0, 50.0], [1400.0, 40.0], [1500.0, 40.0], [1600.0, 24.0], [1700.0, 34.0], [1800.0, 20.0], [1900.0, 25.0], [2000.0, 16.0], [2100.0, 16.0], [2300.0, 24.0], [2200.0, 16.0], [2400.0, 11.0], [2500.0, 8.0], [2600.0, 9.0], [2700.0, 7.0], [2800.0, 7.0], [2900.0, 5.0], [3000.0, 5.0], [3100.0, 9.0], [3300.0, 4.0], [3200.0, 9.0], [3400.0, 7.0], [3500.0, 6.0], [3600.0, 7.0], [3700.0, 7.0], [3800.0, 5.0], [3900.0, 5.0], [4000.0, 8.0], [4200.0, 2.0], [4100.0, 2.0], [4300.0, 4.0], [4500.0, 3.0], [4600.0, 4.0], [4400.0, 3.0], [4700.0, 9.0], [4800.0, 8.0], [4900.0, 6.0], [5100.0, 3.0], [5000.0, 1.0], [5200.0, 2.0], [5300.0, 2.0], [5400.0, 2.0], [5500.0, 3.0], [5600.0, 1.0], [5800.0, 3.0], [5700.0, 1.0], [5900.0, 9.0], [6100.0, 1.0], [6200.0, 1.0], [6400.0, 1.0], [6600.0, 3.0], [6500.0, 2.0], [6800.0, 4.0], [6700.0, 1.0], [7100.0, 2.0], [7000.0, 2.0], [7200.0, 3.0], [7500.0, 2.0], [7600.0, 1.0], [7900.0, 2.0], [7700.0, 1.0], [7800.0, 1.0], [8100.0, 4.0], [8300.0, 3.0], [8600.0, 2.0], [8200.0, 1.0], [8400.0, 2.0], [8500.0, 1.0], [8700.0, 1.0], [9100.0, 2.0], [9000.0, 3.0], [8800.0, 2.0], [9200.0, 2.0], [9500.0, 1.0], [9700.0, 1.0], [9400.0, 2.0], [9600.0, 1.0], [9300.0, 1.0], [10200.0, 2.0], [9800.0, 1.0], [9900.0, 1.0], [10000.0, 1.0], [10300.0, 1.0], [10700.0, 5.0], [10600.0, 1.0], [10800.0, 3.0], [11100.0, 4.0], [10900.0, 2.0], [11200.0, 1.0], [11500.0, 1.0], [11400.0, 1.0], [11700.0, 1.0], [11900.0, 2.0], [12000.0, 2.0], [12400.0, 2.0], [12500.0, 1.0], [12300.0, 2.0], [12900.0, 2.0], [13200.0, 1.0], [13000.0, 1.0], [13600.0, 3.0], [13800.0, 3.0], [13400.0, 2.0], [13700.0, 2.0], [13900.0, 3.0], [14700.0, 2.0], [14500.0, 1.0], [14900.0, 1.0], [15000.0, 1.0], [15300.0, 1.0], [15800.0, 1.0], [15600.0, 3.0], [15700.0, 2.0], [16200.0, 1.0], [16000.0, 1.0], [16300.0, 2.0], [16800.0, 1.0], [17600.0, 1.0], [18400.0, 1.0], [19600.0, 1.0], [21200.0, 2.0], [21600.0, 2.0], [22000.0, 1.0], [21800.0, 2.0], [22200.0, 1.0], [22600.0, 2.0], [23200.0, 1.0], [24200.0, 1.0], [23800.0, 1.0], [24000.0, 1.0], [25200.0, 1.0], [26200.0, 1.0], [27600.0, 1.0], [26800.0, 1.0], [28000.0, 1.0], [28400.0, 2.0], [27800.0, 1.0], [29600.0, 1.0], [29000.0, 1.0], [29400.0, 1.0], [30200.0, 2.0], [30600.0, 1.0], [29800.0, 1.0], [31000.0, 1.0], [32600.0, 1.0], [33200.0, 1.0], [36000.0, 1.0], [38400.0, 1.0], [44800.0, 1.0], [51600.0, 1.0], [55600.0, 1.0], [60400.0, 2.0], [59600.0, 1.0], [33100.0, 1.0], [36700.0, 1.0], [39100.0, 1.0], [41900.0, 2.0], [41100.0, 1.0], [51900.0, 1.0], [52300.0, 1.0], [60300.0, 32.0], [16500.0, 1.0], [17900.0, 1.0], [19100.0, 1.0], [20100.0, 1.0], [20300.0, 2.0], [21500.0, 1.0], [21300.0, 1.0], [21900.0, 3.0], [21700.0, 2.0], [22100.0, 1.0], [23500.0, 2.0], [22900.0, 3.0], [23700.0, 1.0], [24900.0, 1.0], [26500.0, 1.0], [27100.0, 1.0], [27500.0, 1.0], [27900.0, 1.0], [30300.0, 1.0], [30500.0, 3.0], [30100.0, 1.0], [30900.0, 2.0], [31900.0, 1.0], [32300.0, 1.0], [33400.0, 1.0], [34200.0, 1.0], [43400.0, 1.0], [49000.0, 1.0], [52600.0, 1.0], [60200.0, 118.0], [60600.0, 3.0]], "isOverall": false, "label": "Ingest API Firenoc(20)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 60600.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 51.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 504.0, "series": [{"data": [[0.0, 51.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 504.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 474.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 323.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 2.5, "minX": 1.64491416E12, "maxY": 25.0, "series": [{"data": [[1.64491422E12, 25.0], [1.6449147E12, 25.0], [1.64491452E12, 25.0], [1.64491482E12, 2.5], [1.64491434E12, 25.0], [1.64491416E12, 23.162689804772217], [1.64491464E12, 25.0], [1.64491446E12, 25.0], [1.64491428E12, 25.0], [1.64491476E12, 16.599999999999998], [1.64491458E12, 25.0], [1.6449144E12, 25.0]], "isOverall": false, "label": "Dashboard API", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64491482E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 5612.538461538461, "minX": 1.0, "maxY": 60346.0, "series": [{"data": [[2.0, 60284.0], [3.0, 60346.0], [4.0, 60279.0], [5.0, 60277.0], [6.0, 30423.0], [7.0, 11127.000000000002], [8.0, 20431.0], [9.0, 15456.0], [10.0, 12580.8], [11.0, 10461.166666666666], [12.0, 7992.875], [13.0, 12454.0], [14.0, 9106.285714285714], [15.0, 10701.166666666668], [16.0, 9227.285714285714], [1.0, 60283.0], [17.0, 7331.333333333333], [18.0, 12585.6], [19.0, 10617.333333333334], [20.0, 10809.166666666668], [21.0, 7464.444444444444], [22.0, 20877.666666666668], [23.0, 5612.538461538461], [24.0, 7398.444444444444], [25.0, 10927.516286644957]], "isOverall": false, "label": "Ingest API Firenoc(20)", "isController": false}, {"data": [[24.15162721893491, 11052.101331360922]], "isOverall": false, "label": "Ingest API Firenoc(20)-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 25.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 56.666666666666664, "minX": 1.64491416E12, "maxY": 1110602.7833333334, "series": [{"data": [[1.64491422E12, 1403.4166666666667], [1.6449147E12, 1295.5166666666667], [1.64491452E12, 3825.5833333333335], [1.64491482E12, 56.666666666666664], [1.64491434E12, 340.0], [1.64491416E12, 8775.1], [1.64491464E12, 6157.65], [1.64491446E12, 1149.8333333333333], [1.64491428E12, 558.45], [1.64491476E12, 355.96666666666664], [1.64491458E12, 489.6666666666667], [1.6449144E12, 325.8333333333333]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.64491422E12, 183092.86666666667], [1.6449147E12, 175865.51666666666], [1.64491452E12, 501096.26666666666], [1.64491482E12, 9636.466666666667], [1.64491434E12, 57818.8], [1.64491416E12, 1110602.7833333334], [1.64491464E12, 792599.3833333333], [1.64491446E12, 166229.05], [1.64491428E12, 81909.96666666666], [1.64491476E12, 60227.916666666664], [1.64491458E12, 62637.03333333333], [1.6449144E12, 55409.683333333334]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64491482E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 1390.1127982646422, "minX": 1.64491416E12, "maxY": 60298.0, "series": [{"data": [[1.64491422E12, 12895.828947368422], [1.6449147E12, 19038.315068493153], [1.64491452E12, 7954.884615384619], [1.64491482E12, 60298.0], [1.64491434E12, 60291.0], [1.64491416E12, 1390.1127982646422], [1.64491464E12, 5599.027355623102], [1.64491446E12, 30242.666666666675], [1.64491428E12, 38555.11764705883], [1.64491476E12, 60261.16], [1.64491458E12, 17538.76923076923], [1.6449144E12, 60290.95652173912]], "isOverall": false, "label": "Ingest API Firenoc(20)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64491482E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 1389.5509761388291, "minX": 1.64491416E12, "maxY": 60298.0, "series": [{"data": [[1.64491422E12, 12894.934210526315], [1.6449147E12, 19038.232876712325], [1.64491452E12, 7954.033653846154], [1.64491482E12, 60298.0], [1.64491434E12, 60290.95833333333], [1.64491416E12, 1389.5509761388291], [1.64491464E12, 5598.525835866261], [1.64491446E12, 30242.6231884058], [1.64491428E12, 38555.0], [1.64491476E12, 60261.119999999995], [1.64491458E12, 17537.346153846152], [1.6449144E12, 60290.95652173912]], "isOverall": false, "label": "Ingest API Firenoc(20)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64491482E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 128.44000000000003, "minX": 1.64491416E12, "maxY": 225.92841648590002, "series": [{"data": [[1.64491422E12, 174.35526315789474], [1.6449147E12, 130.98630136986299], [1.64491452E12, 212.00961538461544], [1.64491482E12, 135.75], [1.64491434E12, 133.25000000000003], [1.64491416E12, 225.92841648590002], [1.64491464E12, 150.91793313069903], [1.64491446E12, 141.3188405797101], [1.64491428E12, 139.61764705882354], [1.64491476E12, 128.44000000000003], [1.64491458E12, 145.3076923076923], [1.6449144E12, 130.9565217391304]], "isOverall": false, "label": "Ingest API Firenoc(20)", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64491482E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 359.0, "minX": 1.64491416E12, "maxY": 55667.0, "series": [{"data": [[1.64491422E12, 30353.0], [1.6449147E12, 16300.0], [1.64491452E12, 20307.0], [1.64491416E12, 13646.0], [1.64491464E12, 41961.0], [1.64491428E12, 43465.0], [1.64491458E12, 55667.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.64491422E12, 16921.0], [1.6449147E12, 9219.7], [1.64491452E12, 6285.7000000000035], [1.64491416E12, 2425.500000000002], [1.64491464E12, 3173.9000000000015], [1.64491428E12, 42547.0], [1.64491458E12, 31440.5]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.64491422E12, 30353.0], [1.6449147E12, 16300.0], [1.64491452E12, 20108.059999999994], [1.64491416E12, 9990.770000000017], [1.64491464E12, 28729.069999999774], [1.64491428E12, 43465.0], [1.64491458E12, 55667.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.64491422E12, 28008.25], [1.6449147E12, 12804.099999999975], [1.64491452E12, 11570.699999999997], [1.64491416E12, 3822.549999999999], [1.64491464E12, 8423.15], [1.64491428E12, 43465.0], [1.64491458E12, 50757.75]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.64491422E12, 721.0], [1.6449147E12, 1230.0], [1.64491452E12, 652.0], [1.64491416E12, 359.0], [1.64491464E12, 366.0], [1.64491428E12, 4271.0], [1.64491458E12, 5368.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.64491422E12, 4467.0], [1.6449147E12, 2330.5], [1.64491452E12, 2291.5], [1.64491416E12, 912.0], [1.64491464E12, 1392.5], [1.64491428E12, 8696.0], [1.64491458E12, 10300.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.6449147E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 437.0, "minX": 1.0, "maxY": 60343.0, "series": [{"data": [[8.0, 1542.0], [2.0, 5806.0], [9.0, 1827.5], [10.0, 1755.0], [11.0, 1393.0], [12.0, 883.0], [3.0, 2631.0], [13.0, 712.0], [14.0, 1319.0], [15.0, 610.0], [1.0, 6942.0], [16.0, 1038.0], [4.0, 2110.0], [17.0, 891.5], [19.0, 929.0], [20.0, 1246.5], [5.0, 2957.0], [23.0, 622.0], [6.0, 1932.5], [7.0, 1681.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[8.0, 1102.0], [2.0, 56458.5], [9.0, 1048.0], [10.0, 60293.5], [11.0, 1024.0], [3.0, 39823.5], [12.0, 915.0], [13.0, 30501.5], [14.0, 22184.0], [15.0, 60287.0], [16.0, 437.0], [1.0, 59947.0], [4.0, 60283.0], [17.0, 746.0], [19.0, 1328.0], [20.0, 1081.0], [5.0, 60343.0], [23.0, 503.0], [6.0, 1607.0], [7.0, 1607.5]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 23.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 437.0, "minX": 1.0, "maxY": 60343.0, "series": [{"data": [[8.0, 1542.0], [2.0, 5806.0], [9.0, 1827.0], [10.0, 1755.0], [11.0, 1393.0], [12.0, 883.0], [3.0, 2630.0], [13.0, 712.0], [14.0, 1319.0], [15.0, 610.0], [1.0, 6942.0], [16.0, 1038.0], [4.0, 2109.0], [17.0, 891.5], [19.0, 928.5], [20.0, 1246.0], [5.0, 2957.0], [23.0, 621.5], [6.0, 1931.0], [7.0, 1681.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[8.0, 1102.0], [2.0, 56458.5], [9.0, 1048.0], [10.0, 60293.5], [11.0, 1024.0], [3.0, 39823.5], [12.0, 915.0], [13.0, 30501.5], [14.0, 22184.0], [15.0, 60287.0], [16.0, 437.0], [1.0, 59947.0], [4.0, 60283.0], [17.0, 746.0], [19.0, 1328.0], [20.0, 1080.5], [5.0, 60343.0], [23.0, 503.0], [6.0, 1607.0], [7.0, 1607.5]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 23.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.06666666666666667, "minX": 1.64491416E12, "maxY": 8.1, "series": [{"data": [[1.64491422E12, 1.25], [1.6449147E12, 1.2166666666666666], [1.64491452E12, 3.466666666666667], [1.64491434E12, 0.4], [1.64491416E12, 8.1], [1.64491464E12, 5.483333333333333], [1.64491446E12, 1.15], [1.64491428E12, 0.5833333333333334], [1.64491476E12, 0.06666666666666667], [1.64491458E12, 0.43333333333333335], [1.6449144E12, 0.38333333333333336]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64491476E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.64491416E12, "maxY": 7.5, "series": [{"data": [[1.64491422E12, 1.0666666666666667], [1.6449147E12, 0.8666666666666667], [1.64491452E12, 2.1333333333333333], [1.64491416E12, 7.5], [1.64491464E12, 4.933333333333334], [1.64491428E12, 0.25], [1.64491458E12, 0.4]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.64491422E12, 0.05], [1.64491452E12, 0.1], [1.64491416E12, 0.18333333333333332], [1.64491464E12, 0.23333333333333334], [1.64491428E12, 0.016666666666666666], [1.64491458E12, 0.016666666666666666]], "isOverall": false, "label": "400", "isController": false}, {"data": [[1.64491422E12, 0.016666666666666666], [1.6449147E12, 0.03333333333333333], [1.64491452E12, 1.2333333333333334], [1.64491446E12, 0.9166666666666666], [1.64491476E12, 0.016666666666666666]], "isOverall": false, "label": "500", "isController": false}, {"data": [[1.64491422E12, 0.13333333333333333], [1.6449147E12, 0.31666666666666665], [1.64491482E12, 0.06666666666666667], [1.64491434E12, 0.4], [1.64491464E12, 0.31666666666666665], [1.64491446E12, 0.23333333333333334], [1.64491428E12, 0.3], [1.64491476E12, 0.4], [1.64491458E12, 0.016666666666666666], [1.6449144E12, 0.38333333333333336]], "isOverall": false, "label": "504", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64491482E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.03333333333333333, "minX": 1.64491416E12, "maxY": 7.5, "series": [{"data": [[1.64491422E12, 0.2], [1.6449147E12, 0.35], [1.64491452E12, 1.3333333333333333], [1.64491482E12, 0.06666666666666667], [1.64491434E12, 0.4], [1.64491416E12, 0.18333333333333332], [1.64491464E12, 0.55], [1.64491446E12, 1.15], [1.64491428E12, 0.31666666666666665], [1.64491476E12, 0.4166666666666667], [1.64491458E12, 0.03333333333333333], [1.6449144E12, 0.38333333333333336]], "isOverall": false, "label": "Ingest API Firenoc(20)-failure", "isController": false}, {"data": [[1.64491422E12, 1.0666666666666667], [1.6449147E12, 0.8666666666666667], [1.64491452E12, 2.1333333333333333], [1.64491416E12, 7.5], [1.64491464E12, 4.933333333333334], [1.64491428E12, 0.25], [1.64491458E12, 0.4]], "isOverall": false, "label": "Ingest API Firenoc(20)-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64491482E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.03333333333333333, "minX": 1.64491416E12, "maxY": 7.5, "series": [{"data": [[1.64491422E12, 1.0666666666666667], [1.6449147E12, 0.8666666666666667], [1.64491452E12, 2.1333333333333333], [1.64491416E12, 7.5], [1.64491464E12, 4.933333333333334], [1.64491428E12, 0.25], [1.64491458E12, 0.4]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.64491422E12, 0.2], [1.6449147E12, 0.35], [1.64491452E12, 1.3333333333333333], [1.64491482E12, 0.06666666666666667], [1.64491434E12, 0.4], [1.64491416E12, 0.18333333333333332], [1.64491464E12, 0.55], [1.64491446E12, 1.15], [1.64491428E12, 0.31666666666666665], [1.64491476E12, 0.4166666666666667], [1.64491458E12, 0.03333333333333333], [1.6449144E12, 0.38333333333333336]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64491482E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

