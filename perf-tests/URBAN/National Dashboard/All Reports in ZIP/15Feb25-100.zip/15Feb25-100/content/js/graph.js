/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 304.0, "minX": 0.0, "maxY": 63563.0, "series": [{"data": [[0.0, 304.0], [0.1, 341.0], [0.2, 363.0], [0.3, 368.0], [0.4, 374.0], [0.5, 380.0], [0.6, 387.0], [0.7, 390.0], [0.8, 393.0], [0.9, 395.0], [1.0, 399.0], [1.1, 401.0], [1.2, 401.0], [1.3, 403.0], [1.4, 404.0], [1.5, 409.0], [1.6, 410.0], [1.7, 412.0], [1.8, 414.0], [1.9, 416.0], [2.0, 418.0], [2.1, 420.0], [2.2, 424.0], [2.3, 424.0], [2.4, 427.0], [2.5, 429.0], [2.6, 430.0], [2.7, 433.0], [2.8, 434.0], [2.9, 437.0], [3.0, 439.0], [3.1, 439.0], [3.2, 440.0], [3.3, 441.0], [3.4, 442.0], [3.5, 444.0], [3.6, 446.0], [3.7, 446.0], [3.8, 447.0], [3.9, 449.0], [4.0, 452.0], [4.1, 455.0], [4.2, 457.0], [4.3, 458.0], [4.4, 458.0], [4.5, 459.0], [4.6, 460.0], [4.7, 463.0], [4.8, 464.0], [4.9, 465.0], [5.0, 465.0], [5.1, 467.0], [5.2, 469.0], [5.3, 470.0], [5.4, 472.0], [5.5, 473.0], [5.6, 474.0], [5.7, 475.0], [5.8, 477.0], [5.9, 478.0], [6.0, 479.0], [6.1, 481.0], [6.2, 482.0], [6.3, 483.0], [6.4, 484.0], [6.5, 485.0], [6.6, 486.0], [6.7, 487.0], [6.8, 489.0], [6.9, 489.0], [7.0, 492.0], [7.1, 492.0], [7.2, 494.0], [7.3, 495.0], [7.4, 496.0], [7.5, 496.0], [7.6, 497.0], [7.7, 499.0], [7.8, 501.0], [7.9, 503.0], [8.0, 505.0], [8.1, 507.0], [8.2, 508.0], [8.3, 509.0], [8.4, 510.0], [8.5, 512.0], [8.6, 513.0], [8.7, 514.0], [8.8, 516.0], [8.9, 518.0], [9.0, 519.0], [9.1, 521.0], [9.2, 522.0], [9.3, 523.0], [9.4, 525.0], [9.5, 526.0], [9.6, 527.0], [9.7, 528.0], [9.8, 529.0], [9.9, 531.0], [10.0, 533.0], [10.1, 533.0], [10.2, 535.0], [10.3, 538.0], [10.4, 539.0], [10.5, 539.0], [10.6, 541.0], [10.7, 542.0], [10.8, 544.0], [10.9, 544.0], [11.0, 546.0], [11.1, 546.0], [11.2, 547.0], [11.3, 548.0], [11.4, 550.0], [11.5, 551.0], [11.6, 552.0], [11.7, 553.0], [11.8, 554.0], [11.9, 555.0], [12.0, 556.0], [12.1, 556.0], [12.2, 559.0], [12.3, 561.0], [12.4, 561.0], [12.5, 563.0], [12.6, 563.0], [12.7, 564.0], [12.8, 566.0], [12.9, 567.0], [13.0, 567.0], [13.1, 569.0], [13.2, 570.0], [13.3, 571.0], [13.4, 571.0], [13.5, 573.0], [13.6, 574.0], [13.7, 575.0], [13.8, 575.0], [13.9, 576.0], [14.0, 577.0], [14.1, 578.0], [14.2, 579.0], [14.3, 580.0], [14.4, 581.0], [14.5, 583.0], [14.6, 584.0], [14.7, 585.0], [14.8, 586.0], [14.9, 588.0], [15.0, 589.0], [15.1, 590.0], [15.2, 592.0], [15.3, 592.0], [15.4, 594.0], [15.5, 595.0], [15.6, 596.0], [15.7, 597.0], [15.8, 598.0], [15.9, 598.0], [16.0, 599.0], [16.1, 600.0], [16.2, 600.0], [16.3, 601.0], [16.4, 602.0], [16.5, 603.0], [16.6, 603.0], [16.7, 605.0], [16.8, 606.0], [16.9, 606.0], [17.0, 607.0], [17.1, 607.0], [17.2, 608.0], [17.3, 609.0], [17.4, 610.0], [17.5, 610.0], [17.6, 611.0], [17.7, 612.0], [17.8, 613.0], [17.9, 613.0], [18.0, 614.0], [18.1, 615.0], [18.2, 615.0], [18.3, 616.0], [18.4, 617.0], [18.5, 618.0], [18.6, 619.0], [18.7, 619.0], [18.8, 619.0], [18.9, 620.0], [19.0, 620.0], [19.1, 621.0], [19.2, 622.0], [19.3, 623.0], [19.4, 624.0], [19.5, 625.0], [19.6, 626.0], [19.7, 626.0], [19.8, 627.0], [19.9, 628.0], [20.0, 628.0], [20.1, 630.0], [20.2, 631.0], [20.3, 632.0], [20.4, 633.0], [20.5, 633.0], [20.6, 634.0], [20.7, 634.0], [20.8, 634.0], [20.9, 635.0], [21.0, 636.0], [21.1, 637.0], [21.2, 638.0], [21.3, 641.0], [21.4, 643.0], [21.5, 644.0], [21.6, 645.0], [21.7, 646.0], [21.8, 647.0], [21.9, 648.0], [22.0, 649.0], [22.1, 650.0], [22.2, 651.0], [22.3, 651.0], [22.4, 653.0], [22.5, 653.0], [22.6, 654.0], [22.7, 655.0], [22.8, 656.0], [22.9, 657.0], [23.0, 658.0], [23.1, 659.0], [23.2, 660.0], [23.3, 661.0], [23.4, 661.0], [23.5, 663.0], [23.6, 664.0], [23.7, 664.0], [23.8, 665.0], [23.9, 666.0], [24.0, 667.0], [24.1, 669.0], [24.2, 670.0], [24.3, 670.0], [24.4, 671.0], [24.5, 672.0], [24.6, 673.0], [24.7, 673.0], [24.8, 674.0], [24.9, 675.0], [25.0, 675.0], [25.1, 677.0], [25.2, 677.0], [25.3, 679.0], [25.4, 679.0], [25.5, 680.0], [25.6, 681.0], [25.7, 682.0], [25.8, 683.0], [25.9, 683.0], [26.0, 684.0], [26.1, 685.0], [26.2, 686.0], [26.3, 686.0], [26.4, 687.0], [26.5, 689.0], [26.6, 690.0], [26.7, 692.0], [26.8, 693.0], [26.9, 695.0], [27.0, 697.0], [27.1, 697.0], [27.2, 699.0], [27.3, 699.0], [27.4, 701.0], [27.5, 701.0], [27.6, 702.0], [27.7, 703.0], [27.8, 704.0], [27.9, 704.0], [28.0, 706.0], [28.1, 707.0], [28.2, 708.0], [28.3, 708.0], [28.4, 710.0], [28.5, 711.0], [28.6, 712.0], [28.7, 713.0], [28.8, 714.0], [28.9, 714.0], [29.0, 716.0], [29.1, 717.0], [29.2, 719.0], [29.3, 721.0], [29.4, 721.0], [29.5, 722.0], [29.6, 723.0], [29.7, 724.0], [29.8, 726.0], [29.9, 726.0], [30.0, 727.0], [30.1, 727.0], [30.2, 728.0], [30.3, 729.0], [30.4, 730.0], [30.5, 732.0], [30.6, 732.0], [30.7, 733.0], [30.8, 734.0], [30.9, 734.0], [31.0, 735.0], [31.1, 736.0], [31.2, 737.0], [31.3, 738.0], [31.4, 738.0], [31.5, 739.0], [31.6, 740.0], [31.7, 740.0], [31.8, 741.0], [31.9, 743.0], [32.0, 744.0], [32.1, 746.0], [32.2, 747.0], [32.3, 748.0], [32.4, 749.0], [32.5, 749.0], [32.6, 750.0], [32.7, 750.0], [32.8, 752.0], [32.9, 753.0], [33.0, 754.0], [33.1, 756.0], [33.2, 757.0], [33.3, 757.0], [33.4, 758.0], [33.5, 759.0], [33.6, 760.0], [33.7, 760.0], [33.8, 762.0], [33.9, 763.0], [34.0, 764.0], [34.1, 765.0], [34.2, 765.0], [34.3, 766.0], [34.4, 766.0], [34.5, 767.0], [34.6, 768.0], [34.7, 768.0], [34.8, 770.0], [34.9, 770.0], [35.0, 771.0], [35.1, 772.0], [35.2, 774.0], [35.3, 775.0], [35.4, 776.0], [35.5, 777.0], [35.6, 778.0], [35.7, 779.0], [35.8, 780.0], [35.9, 782.0], [36.0, 783.0], [36.1, 784.0], [36.2, 785.0], [36.3, 786.0], [36.4, 787.0], [36.5, 788.0], [36.6, 790.0], [36.7, 791.0], [36.8, 793.0], [36.9, 793.0], [37.0, 794.0], [37.1, 794.0], [37.2, 795.0], [37.3, 796.0], [37.4, 796.0], [37.5, 797.0], [37.6, 797.0], [37.7, 799.0], [37.8, 801.0], [37.9, 802.0], [38.0, 804.0], [38.1, 806.0], [38.2, 807.0], [38.3, 808.0], [38.4, 809.0], [38.5, 809.0], [38.6, 810.0], [38.7, 810.0], [38.8, 811.0], [38.9, 812.0], [39.0, 814.0], [39.1, 814.0], [39.2, 815.0], [39.3, 816.0], [39.4, 817.0], [39.5, 818.0], [39.6, 819.0], [39.7, 820.0], [39.8, 820.0], [39.9, 821.0], [40.0, 822.0], [40.1, 823.0], [40.2, 824.0], [40.3, 824.0], [40.4, 825.0], [40.5, 826.0], [40.6, 826.0], [40.7, 828.0], [40.8, 830.0], [40.9, 831.0], [41.0, 832.0], [41.1, 833.0], [41.2, 834.0], [41.3, 835.0], [41.4, 836.0], [41.5, 838.0], [41.6, 840.0], [41.7, 842.0], [41.8, 843.0], [41.9, 844.0], [42.0, 846.0], [42.1, 847.0], [42.2, 848.0], [42.3, 849.0], [42.4, 850.0], [42.5, 851.0], [42.6, 853.0], [42.7, 856.0], [42.8, 857.0], [42.9, 858.0], [43.0, 861.0], [43.1, 862.0], [43.2, 865.0], [43.3, 869.0], [43.4, 870.0], [43.5, 872.0], [43.6, 873.0], [43.7, 873.0], [43.8, 875.0], [43.9, 879.0], [44.0, 882.0], [44.1, 884.0], [44.2, 886.0], [44.3, 887.0], [44.4, 887.0], [44.5, 889.0], [44.6, 890.0], [44.7, 892.0], [44.8, 893.0], [44.9, 895.0], [45.0, 897.0], [45.1, 898.0], [45.2, 900.0], [45.3, 900.0], [45.4, 902.0], [45.5, 905.0], [45.6, 907.0], [45.7, 911.0], [45.8, 913.0], [45.9, 913.0], [46.0, 916.0], [46.1, 918.0], [46.2, 919.0], [46.3, 922.0], [46.4, 925.0], [46.5, 929.0], [46.6, 930.0], [46.7, 933.0], [46.8, 935.0], [46.9, 940.0], [47.0, 942.0], [47.1, 945.0], [47.2, 948.0], [47.3, 951.0], [47.4, 954.0], [47.5, 956.0], [47.6, 958.0], [47.7, 961.0], [47.8, 963.0], [47.9, 966.0], [48.0, 968.0], [48.1, 972.0], [48.2, 975.0], [48.3, 979.0], [48.4, 980.0], [48.5, 983.0], [48.6, 986.0], [48.7, 989.0], [48.8, 993.0], [48.9, 995.0], [49.0, 998.0], [49.1, 1001.0], [49.2, 1003.0], [49.3, 1007.0], [49.4, 1008.0], [49.5, 1011.0], [49.6, 1012.0], [49.7, 1015.0], [49.8, 1021.0], [49.9, 1022.0], [50.0, 1025.0], [50.1, 1027.0], [50.2, 1031.0], [50.3, 1033.0], [50.4, 1034.0], [50.5, 1037.0], [50.6, 1039.0], [50.7, 1040.0], [50.8, 1046.0], [50.9, 1050.0], [51.0, 1051.0], [51.1, 1057.0], [51.2, 1059.0], [51.3, 1063.0], [51.4, 1066.0], [51.5, 1071.0], [51.6, 1073.0], [51.7, 1076.0], [51.8, 1077.0], [51.9, 1078.0], [52.0, 1081.0], [52.1, 1085.0], [52.2, 1090.0], [52.3, 1093.0], [52.4, 1096.0], [52.5, 1097.0], [52.6, 1099.0], [52.7, 1104.0], [52.8, 1107.0], [52.9, 1113.0], [53.0, 1114.0], [53.1, 1116.0], [53.2, 1119.0], [53.3, 1121.0], [53.4, 1122.0], [53.5, 1125.0], [53.6, 1127.0], [53.7, 1130.0], [53.8, 1133.0], [53.9, 1135.0], [54.0, 1137.0], [54.1, 1141.0], [54.2, 1143.0], [54.3, 1145.0], [54.4, 1146.0], [54.5, 1149.0], [54.6, 1156.0], [54.7, 1161.0], [54.8, 1165.0], [54.9, 1167.0], [55.0, 1172.0], [55.1, 1174.0], [55.2, 1175.0], [55.3, 1179.0], [55.4, 1181.0], [55.5, 1185.0], [55.6, 1188.0], [55.7, 1192.0], [55.8, 1194.0], [55.9, 1195.0], [56.0, 1198.0], [56.1, 1200.0], [56.2, 1202.0], [56.3, 1204.0], [56.4, 1205.0], [56.5, 1207.0], [56.6, 1209.0], [56.7, 1211.0], [56.8, 1215.0], [56.9, 1216.0], [57.0, 1221.0], [57.1, 1223.0], [57.2, 1224.0], [57.3, 1227.0], [57.4, 1228.0], [57.5, 1229.0], [57.6, 1231.0], [57.7, 1234.0], [57.8, 1238.0], [57.9, 1241.0], [58.0, 1242.0], [58.1, 1247.0], [58.2, 1249.0], [58.3, 1252.0], [58.4, 1257.0], [58.5, 1261.0], [58.6, 1267.0], [58.7, 1268.0], [58.8, 1271.0], [58.9, 1275.0], [59.0, 1276.0], [59.1, 1279.0], [59.2, 1280.0], [59.3, 1285.0], [59.4, 1286.0], [59.5, 1287.0], [59.6, 1289.0], [59.7, 1290.0], [59.8, 1298.0], [59.9, 1301.0], [60.0, 1304.0], [60.1, 1306.0], [60.2, 1307.0], [60.3, 1310.0], [60.4, 1313.0], [60.5, 1316.0], [60.6, 1324.0], [60.7, 1327.0], [60.8, 1329.0], [60.9, 1332.0], [61.0, 1334.0], [61.1, 1336.0], [61.2, 1339.0], [61.3, 1342.0], [61.4, 1347.0], [61.5, 1355.0], [61.6, 1357.0], [61.7, 1360.0], [61.8, 1364.0], [61.9, 1368.0], [62.0, 1371.0], [62.1, 1374.0], [62.2, 1380.0], [62.3, 1383.0], [62.4, 1387.0], [62.5, 1389.0], [62.6, 1391.0], [62.7, 1392.0], [62.8, 1395.0], [62.9, 1396.0], [63.0, 1398.0], [63.1, 1400.0], [63.2, 1400.0], [63.3, 1409.0], [63.4, 1410.0], [63.5, 1412.0], [63.6, 1414.0], [63.7, 1418.0], [63.8, 1420.0], [63.9, 1423.0], [64.0, 1425.0], [64.1, 1428.0], [64.2, 1433.0], [64.3, 1437.0], [64.4, 1439.0], [64.5, 1441.0], [64.6, 1442.0], [64.7, 1445.0], [64.8, 1446.0], [64.9, 1448.0], [65.0, 1450.0], [65.1, 1452.0], [65.2, 1455.0], [65.3, 1458.0], [65.4, 1463.0], [65.5, 1468.0], [65.6, 1472.0], [65.7, 1476.0], [65.8, 1478.0], [65.9, 1485.0], [66.0, 1491.0], [66.1, 1495.0], [66.2, 1498.0], [66.3, 1499.0], [66.4, 1505.0], [66.5, 1507.0], [66.6, 1512.0], [66.7, 1514.0], [66.8, 1518.0], [66.9, 1523.0], [67.0, 1526.0], [67.1, 1531.0], [67.2, 1537.0], [67.3, 1545.0], [67.4, 1546.0], [67.5, 1549.0], [67.6, 1552.0], [67.7, 1557.0], [67.8, 1560.0], [67.9, 1564.0], [68.0, 1569.0], [68.1, 1574.0], [68.2, 1577.0], [68.3, 1581.0], [68.4, 1584.0], [68.5, 1589.0], [68.6, 1593.0], [68.7, 1599.0], [68.8, 1610.0], [68.9, 1616.0], [69.0, 1619.0], [69.1, 1623.0], [69.2, 1625.0], [69.3, 1629.0], [69.4, 1630.0], [69.5, 1633.0], [69.6, 1635.0], [69.7, 1639.0], [69.8, 1642.0], [69.9, 1647.0], [70.0, 1657.0], [70.1, 1661.0], [70.2, 1665.0], [70.3, 1669.0], [70.4, 1672.0], [70.5, 1678.0], [70.6, 1685.0], [70.7, 1692.0], [70.8, 1704.0], [70.9, 1707.0], [71.0, 1710.0], [71.1, 1712.0], [71.2, 1715.0], [71.3, 1721.0], [71.4, 1731.0], [71.5, 1737.0], [71.6, 1740.0], [71.7, 1749.0], [71.8, 1756.0], [71.9, 1760.0], [72.0, 1766.0], [72.1, 1776.0], [72.2, 1780.0], [72.3, 1782.0], [72.4, 1787.0], [72.5, 1794.0], [72.6, 1798.0], [72.7, 1803.0], [72.8, 1812.0], [72.9, 1818.0], [73.0, 1825.0], [73.1, 1827.0], [73.2, 1837.0], [73.3, 1845.0], [73.4, 1846.0], [73.5, 1860.0], [73.6, 1863.0], [73.7, 1871.0], [73.8, 1883.0], [73.9, 1888.0], [74.0, 1892.0], [74.1, 1895.0], [74.2, 1907.0], [74.3, 1912.0], [74.4, 1922.0], [74.5, 1928.0], [74.6, 1933.0], [74.7, 1941.0], [74.8, 1947.0], [74.9, 1952.0], [75.0, 1960.0], [75.1, 1964.0], [75.2, 1968.0], [75.3, 1973.0], [75.4, 1984.0], [75.5, 1992.0], [75.6, 1994.0], [75.7, 1997.0], [75.8, 2001.0], [75.9, 2006.0], [76.0, 2009.0], [76.1, 2024.0], [76.2, 2033.0], [76.3, 2036.0], [76.4, 2041.0], [76.5, 2048.0], [76.6, 2051.0], [76.7, 2066.0], [76.8, 2074.0], [76.9, 2081.0], [77.0, 2089.0], [77.1, 2100.0], [77.2, 2106.0], [77.3, 2122.0], [77.4, 2130.0], [77.5, 2141.0], [77.6, 2150.0], [77.7, 2153.0], [77.8, 2167.0], [77.9, 2182.0], [78.0, 2192.0], [78.1, 2196.0], [78.2, 2210.0], [78.3, 2217.0], [78.4, 2225.0], [78.5, 2232.0], [78.6, 2246.0], [78.7, 2252.0], [78.8, 2262.0], [78.9, 2264.0], [79.0, 2267.0], [79.1, 2273.0], [79.2, 2277.0], [79.3, 2289.0], [79.4, 2294.0], [79.5, 2299.0], [79.6, 2306.0], [79.7, 2320.0], [79.8, 2326.0], [79.9, 2331.0], [80.0, 2339.0], [80.1, 2348.0], [80.2, 2351.0], [80.3, 2353.0], [80.4, 2364.0], [80.5, 2374.0], [80.6, 2386.0], [80.7, 2393.0], [80.8, 2401.0], [80.9, 2413.0], [81.0, 2422.0], [81.1, 2432.0], [81.2, 2437.0], [81.3, 2461.0], [81.4, 2479.0], [81.5, 2489.0], [81.6, 2505.0], [81.7, 2521.0], [81.8, 2534.0], [81.9, 2551.0], [82.0, 2565.0], [82.1, 2576.0], [82.2, 2587.0], [82.3, 2598.0], [82.4, 2614.0], [82.5, 2623.0], [82.6, 2634.0], [82.7, 2651.0], [82.8, 2663.0], [82.9, 2676.0], [83.0, 2687.0], [83.1, 2718.0], [83.2, 2734.0], [83.3, 2755.0], [83.4, 2760.0], [83.5, 2769.0], [83.6, 2802.0], [83.7, 2811.0], [83.8, 2819.0], [83.9, 2837.0], [84.0, 2845.0], [84.1, 2858.0], [84.2, 2866.0], [84.3, 2883.0], [84.4, 2908.0], [84.5, 2927.0], [84.6, 2953.0], [84.7, 2965.0], [84.8, 2979.0], [84.9, 3015.0], [85.0, 3031.0], [85.1, 3042.0], [85.2, 3048.0], [85.3, 3061.0], [85.4, 3074.0], [85.5, 3110.0], [85.6, 3148.0], [85.7, 3185.0], [85.8, 3200.0], [85.9, 3207.0], [86.0, 3230.0], [86.1, 3243.0], [86.2, 3278.0], [86.3, 3283.0], [86.4, 3303.0], [86.5, 3332.0], [86.6, 3349.0], [86.7, 3382.0], [86.8, 3396.0], [86.9, 3415.0], [87.0, 3428.0], [87.1, 3445.0], [87.2, 3471.0], [87.3, 3497.0], [87.4, 3575.0], [87.5, 3598.0], [87.6, 3611.0], [87.7, 3629.0], [87.8, 3661.0], [87.9, 3715.0], [88.0, 3736.0], [88.1, 3758.0], [88.2, 3790.0], [88.3, 3828.0], [88.4, 3859.0], [88.5, 3904.0], [88.6, 3933.0], [88.7, 3977.0], [88.8, 4047.0], [88.9, 4081.0], [89.0, 4112.0], [89.1, 4159.0], [89.2, 4244.0], [89.3, 4276.0], [89.4, 4309.0], [89.5, 4391.0], [89.6, 4443.0], [89.7, 4479.0], [89.8, 4532.0], [89.9, 4585.0], [90.0, 4643.0], [90.1, 4673.0], [90.2, 4715.0], [90.3, 4779.0], [90.4, 4820.0], [90.5, 4887.0], [90.6, 4943.0], [90.7, 5033.0], [90.8, 5071.0], [90.9, 5117.0], [91.0, 5202.0], [91.1, 5261.0], [91.2, 5502.0], [91.3, 5572.0], [91.4, 5709.0], [91.5, 5827.0], [91.6, 5976.0], [91.7, 6250.0], [91.8, 6351.0], [91.9, 6595.0], [92.0, 6717.0], [92.1, 6879.0], [92.2, 6933.0], [92.3, 7060.0], [92.4, 7095.0], [92.5, 7258.0], [92.6, 7367.0], [92.7, 7434.0], [92.8, 7493.0], [92.9, 7658.0], [93.0, 7770.0], [93.1, 7907.0], [93.2, 8093.0], [93.3, 8360.0], [93.4, 8378.0], [93.5, 8453.0], [93.6, 8596.0], [93.7, 8636.0], [93.8, 8866.0], [93.9, 9081.0], [94.0, 9253.0], [94.1, 9668.0], [94.2, 9868.0], [94.3, 10177.0], [94.4, 10632.0], [94.5, 10893.0], [94.6, 11125.0], [94.7, 11318.0], [94.8, 11959.0], [94.9, 12583.0], [95.0, 13029.0], [95.1, 13612.0], [95.2, 14135.0], [95.3, 15015.0], [95.4, 16150.0], [95.5, 16331.0], [95.6, 17220.0], [95.7, 18959.0], [95.8, 20361.0], [95.9, 20395.0], [96.0, 20549.0], [96.1, 20737.0], [96.2, 20889.0], [96.3, 21011.0], [96.4, 21175.0], [96.5, 22126.0], [96.6, 23515.0], [96.7, 24561.0], [96.8, 25250.0], [96.9, 26863.0], [97.0, 28021.0], [97.1, 28625.0], [97.2, 29822.0], [97.3, 32900.0], [97.4, 35106.0], [97.5, 39232.0], [97.6, 43931.0], [97.7, 54257.0], [97.8, 55060.0], [97.9, 60310.0], [98.0, 60323.0], [98.1, 60332.0], [98.2, 60349.0], [98.3, 60355.0], [98.4, 60377.0], [98.5, 60386.0], [98.6, 60413.0], [98.7, 60423.0], [98.8, 60458.0], [98.9, 60480.0], [99.0, 60551.0], [99.1, 60695.0], [99.2, 60795.0], [99.3, 60949.0], [99.4, 61299.0], [99.5, 62155.0], [99.6, 62337.0], [99.7, 62466.0], [99.8, 62746.0], [99.9, 62967.0], [100.0, 63563.0]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 300.0, "maxY": 452.0, "series": [{"data": [[32900.0, 1.0], [51300.0, 1.0], [54500.0, 1.0], [60900.0, 2.0], [61300.0, 1.0], [60500.0, 3.0], [62100.0, 2.0], [62900.0, 3.0], [61700.0, 1.0], [300.0, 42.0], [400.0, 267.0], [500.0, 334.0], [600.0, 452.0], [700.0, 414.0], [800.0, 297.0], [900.0, 156.0], [1000.0, 144.0], [1100.0, 138.0], [1200.0, 149.0], [1300.0, 131.0], [1400.0, 129.0], [1500.0, 96.0], [1600.0, 80.0], [1700.0, 76.0], [1800.0, 60.0], [1900.0, 64.0], [2000.0, 54.0], [2100.0, 42.0], [2200.0, 55.0], [2300.0, 51.0], [2400.0, 32.0], [2500.0, 29.0], [2600.0, 31.0], [2800.0, 31.0], [2700.0, 20.0], [2900.0, 20.0], [3000.0, 25.0], [3100.0, 11.0], [3300.0, 19.0], [3200.0, 25.0], [3400.0, 18.0], [3500.0, 9.0], [3700.0, 15.0], [3600.0, 13.0], [3800.0, 10.0], [3900.0, 10.0], [4000.0, 10.0], [4300.0, 5.0], [4200.0, 8.0], [4100.0, 8.0], [4600.0, 10.0], [4400.0, 9.0], [4500.0, 7.0], [4700.0, 8.0], [4800.0, 6.0], [5000.0, 7.0], [4900.0, 6.0], [5100.0, 6.0], [5300.0, 2.0], [5200.0, 5.0], [5500.0, 6.0], [5600.0, 2.0], [5400.0, 1.0], [5800.0, 2.0], [5700.0, 4.0], [6100.0, 2.0], [5900.0, 3.0], [6200.0, 4.0], [6300.0, 2.0], [6600.0, 3.0], [6500.0, 1.0], [6400.0, 3.0], [6800.0, 3.0], [6700.0, 3.0], [6900.0, 4.0], [7100.0, 2.0], [7000.0, 7.0], [7300.0, 6.0], [7400.0, 6.0], [7200.0, 2.0], [7600.0, 4.0], [7500.0, 2.0], [7900.0, 3.0], [7700.0, 3.0], [7800.0, 2.0], [8000.0, 2.0], [8100.0, 1.0], [8600.0, 4.0], [8300.0, 6.0], [8500.0, 4.0], [8400.0, 5.0], [8200.0, 1.0], [8700.0, 1.0], [8800.0, 3.0], [9100.0, 2.0], [9000.0, 3.0], [9200.0, 3.0], [9300.0, 1.0], [9700.0, 1.0], [9400.0, 1.0], [9600.0, 2.0], [10200.0, 1.0], [9900.0, 2.0], [9800.0, 2.0], [10000.0, 1.0], [10100.0, 1.0], [10300.0, 2.0], [10700.0, 1.0], [10600.0, 1.0], [10800.0, 3.0], [10900.0, 2.0], [11100.0, 3.0], [11200.0, 1.0], [11000.0, 1.0], [11700.0, 1.0], [11400.0, 1.0], [11600.0, 1.0], [11300.0, 1.0], [12100.0, 1.0], [11900.0, 1.0], [12200.0, 1.0], [12500.0, 1.0], [12700.0, 1.0], [12600.0, 1.0], [12400.0, 1.0], [13000.0, 2.0], [12800.0, 1.0], [13100.0, 1.0], [13600.0, 1.0], [13400.0, 1.0], [13800.0, 1.0], [14200.0, 1.0], [13900.0, 1.0], [14100.0, 2.0], [14800.0, 1.0], [14400.0, 1.0], [15000.0, 1.0], [15700.0, 1.0], [15400.0, 1.0], [16000.0, 1.0], [16200.0, 1.0], [16100.0, 3.0], [16300.0, 1.0], [17200.0, 1.0], [17400.0, 1.0], [18800.0, 1.0], [19000.0, 1.0], [20400.0, 3.0], [19800.0, 1.0], [20800.0, 2.0], [21000.0, 2.0], [20600.0, 2.0], [22200.0, 1.0], [21600.0, 1.0], [22800.0, 1.0], [24400.0, 1.0], [23800.0, 1.0], [24000.0, 1.0], [25200.0, 2.0], [24800.0, 1.0], [24600.0, 1.0], [26600.0, 2.0], [26800.0, 1.0], [27600.0, 1.0], [27000.0, 1.0], [28400.0, 1.0], [28000.0, 1.0], [28600.0, 1.0], [29600.0, 1.0], [29800.0, 1.0], [30000.0, 1.0], [32600.0, 1.0], [34400.0, 1.0], [35200.0, 1.0], [39200.0, 1.0], [46400.0, 1.0], [54000.0, 1.0], [54800.0, 1.0], [60400.0, 16.0], [61200.0, 2.0], [60800.0, 2.0], [62400.0, 5.0], [33900.0, 1.0], [35100.0, 1.0], [42300.0, 1.0], [43900.0, 1.0], [60300.0, 27.0], [60700.0, 4.0], [61100.0, 1.0], [62300.0, 1.0], [62700.0, 3.0], [63500.0, 1.0], [16700.0, 3.0], [18100.0, 1.0], [18900.0, 1.0], [20300.0, 5.0], [19700.0, 1.0], [20900.0, 3.0], [20700.0, 3.0], [20500.0, 2.0], [21100.0, 3.0], [21500.0, 1.0], [21300.0, 1.0], [22100.0, 1.0], [23500.0, 1.0], [23300.0, 1.0], [24500.0, 1.0], [26300.0, 1.0], [26900.0, 1.0], [28100.0, 1.0], [28500.0, 1.0], [29100.0, 2.0], [32500.0, 1.0], [35400.0, 1.0], [35800.0, 1.0], [35000.0, 1.0], [39400.0, 1.0], [42200.0, 1.0], [55000.0, 1.0], [54200.0, 2.0], [55400.0, 1.0], [57400.0, 1.0], [60600.0, 4.0], [61000.0, 1.0], [61400.0, 1.0], [62200.0, 2.0], [62600.0, 2.0], [63000.0, 2.0]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 63500.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 75.0, "minX": 1.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 3620.0, "series": [{"data": [], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 75.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 305.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 3620.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 4.0, "minX": 1.64491158E12, "maxY": 25.0, "series": [{"data": [[1.644912E12, 25.0], [1.6449117E12, 25.0], [1.64491218E12, 18.879999999999995], [1.64491158E12, 21.961783439490446], [1.64491188E12, 25.0], [1.64491206E12, 25.0], [1.64491176E12, 25.0], [1.64491224E12, 4.0], [1.64491194E12, 25.0], [1.64491212E12, 25.0], [1.64491164E12, 25.0], [1.64491182E12, 25.0]], "isOverall": false, "label": "Dashboard API", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64491224E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 3224.3062994134148, "minX": 1.0, "maxY": 60770.0, "series": [{"data": [[2.0, 60333.0], [3.0, 60770.0], [4.0, 30807.0], [5.0, 30847.5], [6.0, 30706.0], [7.0, 20563.666666666668], [8.0, 20568.666666666668], [9.0, 20586.0], [10.0, 20732.666666666668], [11.0, 30771.5], [12.0, 15728.25], [13.0, 15847.0], [14.0, 60489.0], [15.0, 13072.8], [16.0, 9471.57142857143], [1.0, 60323.0], [17.0, 30787.5], [18.0, 20617.0], [19.0, 30777.5], [20.0, 15947.0], [21.0, 7466.0], [22.0, 15739.75], [23.0, 12460.285714285714], [24.0, 20968.0], [25.0, 3224.3062994134148]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}, {"data": [[24.805750000000057, 3543.129250000005]], "isOverall": false, "label": "Ingest API Firenoc-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 25.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 99.16666666666667, "minX": 1.64491158E12, "maxY": 6352456.366666666, "series": [{"data": [[1.644912E12, 2762.366666666667], [1.6449117E12, 8286.233333333334], [1.64491218E12, 403.6166666666667], [1.64491158E12, 3419.3333333333335], [1.64491188E12, 15345.766666666666], [1.64491206E12, 13844.033333333333], [1.64491176E12, 4236.566666666667], [1.64491224E12, 99.16666666666667], [1.64491194E12, 4643.666666666667], [1.64491212E12, 5023.366666666667], [1.64491164E12, 600.95], [1.64491182E12, 1291.5]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.644912E12, 883922.5], [1.6449117E12, 3441404.933333333], [1.64491218E12, 147320.41666666666], [1.64491158E12, 925172.2166666667], [1.64491188E12, 6352456.366666666], [1.64491206E12, 5739603.433333334], [1.64491176E12, 1756059.3666666667], [1.64491224E12, 41249.71666666667], [1.64491194E12, 1756059.3666666667], [1.64491212E12, 1885701.3333333333], [1.64491164E12, 176784.5], [1.64491182E12, 465532.51666666666]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64491224E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 1146.3993288590602, "minX": 1.64491158E12, "maxY": 60455.42857142857, "series": [{"data": [[1.644912E12, 12620.993333333334], [1.6449117E12, 3624.9349315068516], [1.64491218E12, 53648.200000000004], [1.64491158E12, 2613.9363057324827], [1.64491188E12, 1339.2087198515749], [1.64491206E12, 1228.0749486652974], [1.64491176E12, 1146.3993288590602], [1.64491224E12, 60455.42857142857], [1.64491194E12, 3247.7382550335565], [1.64491212E12, 2904.568750000001], [1.64491164E12, 28384.100000000002], [1.64491182E12, 28574.367088607585]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64491224E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 1146.3523489932886, "minX": 1.64491158E12, "maxY": 60455.42857142857, "series": [{"data": [[1.644912E12, 12620.466666666665], [1.6449117E12, 3624.8955479452084], [1.64491218E12, 53646.31999999999], [1.64491158E12, 2613.5605095541405], [1.64491188E12, 1339.0844155844147], [1.64491206E12, 1228.0472279260787], [1.64491176E12, 1146.3523489932886], [1.64491224E12, 60455.42857142857], [1.64491194E12, 3247.6476510067114], [1.64491212E12, 2904.468750000001], [1.64491164E12, 28383.83333333333], [1.64491182E12, 28573.88607594938]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64491224E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 137.56666666666666, "minX": 1.64491158E12, "maxY": 770.0205479452057, "series": [{"data": [[1.644912E12, 293.46666666666664], [1.6449117E12, 770.0205479452057], [1.64491218E12, 146.16], [1.64491158E12, 206.45222929936315], [1.64491188E12, 320.5723562152136], [1.64491206E12, 471.9527720739219], [1.64491176E12, 332.8791946308726], [1.64491224E12, 174.71428571428572], [1.64491194E12, 371.36912751677863], [1.64491212E12, 335.7687499999999], [1.64491164E12, 137.56666666666666], [1.64491182E12, 476.7848101265823]], "isOverall": false, "label": "Ingest API Firenoc", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64491224E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 606.0, "minX": 1.64491158E12, "maxY": 54279.0, "series": [{"data": [[1.644912E12, 54279.0], [1.64491218E12, 42269.0], [1.64491158E12, 10388.0], [1.64491194E12, 27024.0], [1.64491212E12, 21340.0], [1.64491164E12, 39462.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.644912E12, 5781.600000000004], [1.64491218E12, 42269.0], [1.64491158E12, 6256.3], [1.64491194E12, 24618.0], [1.64491212E12, 16278.5], [1.64491164E12, 37860.40000000001]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.644912E12, 54279.0], [1.64491218E12, 42269.0], [1.64491158E12, 9376.250000000013], [1.64491194E12, 27024.0], [1.64491212E12, 21340.0], [1.64491164E12, 39462.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.644912E12, 32602.2], [1.64491218E12, 42269.0], [1.64491158E12, 7369.150000000001], [1.64491194E12, 26675.0], [1.64491212E12, 18734.59999999999], [1.64491164E12, 39416.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.644912E12, 1569.0], [1.64491218E12, 30006.0], [1.64491158E12, 606.0], [1.64491194E12, 675.0], [1.64491212E12, 4694.0], [1.64491164E12, 6901.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.644912E12, 2914.0], [1.64491218E12, 34184.0], [1.64491158E12, 1830.0], [1.64491194E12, 11212.5], [1.64491212E12, 8747.5], [1.64491164E12, 13612.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64491218E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 707.0, "minX": 1.0, "maxY": 60332.0, "series": [{"data": [[4.0, 3545.0], [1.0, 15711.0], [8.0, 5126.0], [2.0, 11735.0], [9.0, 2239.0], [5.0, 3631.0], [11.0, 1819.0], [3.0, 7859.0], [6.0, 2240.5], [12.0, 1304.5], [13.0, 1498.0], [7.0, 2418.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[2.0, 60332.0], [3.0, 3068.0], [4.0, 2211.5], [5.0, 2651.0], [6.0, 2211.0], [7.0, 3075.0], [8.0, 2398.0], [9.0, 2175.5], [10.0, 2659.0], [11.0, 1584.0], [12.0, 1190.5], [13.0, 913.0], [14.0, 1128.5], [15.0, 1001.0], [1.0, 10028.0], [16.0, 917.5], [17.0, 911.0], [18.0, 824.5], [19.0, 794.0], [20.0, 768.5], [21.0, 759.5], [22.0, 802.5], [23.0, 754.5], [24.0, 1030.5], [25.0, 1174.0], [26.0, 707.0], [27.0, 750.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 27.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 707.0, "minX": 1.0, "maxY": 60332.0, "series": [{"data": [[4.0, 3544.5], [1.0, 15711.0], [8.0, 5125.0], [2.0, 11735.0], [9.0, 2239.0], [5.0, 3631.0], [11.0, 1819.0], [3.0, 7859.0], [6.0, 2238.5], [12.0, 1304.5], [13.0, 1497.0], [7.0, 2418.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[2.0, 60332.0], [3.0, 3068.0], [4.0, 2211.5], [5.0, 2651.0], [6.0, 2211.0], [7.0, 3075.0], [8.0, 2398.0], [9.0, 2175.5], [10.0, 2659.0], [11.0, 1584.0], [12.0, 1190.5], [13.0, 913.0], [14.0, 1128.5], [15.0, 1001.0], [1.0, 10028.0], [16.0, 917.5], [17.0, 911.0], [18.0, 824.5], [19.0, 794.0], [20.0, 768.5], [21.0, 759.0], [22.0, 802.5], [23.0, 754.5], [24.0, 1030.5], [25.0, 1174.0], [26.0, 707.0], [27.0, 750.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 27.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.11666666666666667, "minX": 1.64491158E12, "maxY": 17.9, "series": [{"data": [[1.644912E12, 2.35], [1.6449117E12, 9.7], [1.64491218E12, 0.11666666666666667], [1.64491158E12, 3.033333333333333], [1.64491188E12, 17.9], [1.64491206E12, 16.2], [1.64491176E12, 5.016666666666667], [1.64491194E12, 5.033333333333333], [1.64491212E12, 5.516666666666667], [1.64491164E12, 0.48333333333333334], [1.64491182E12, 1.3166666666666667]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64491218E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.64491158E12, "maxY": 16.833333333333332, "series": [{"data": [[1.644912E12, 1.3833333333333333], [1.64491218E12, 0.1], [1.64491158E12, 2.6], [1.64491194E12, 0.8333333333333334], [1.64491212E12, 1.0333333333333334], [1.64491164E12, 0.38333333333333336]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.644912E12, 0.06666666666666667], [1.64491218E12, 0.016666666666666666], [1.64491158E12, 0.016666666666666666], [1.64491194E12, 0.016666666666666666], [1.64491212E12, 0.016666666666666666]], "isOverall": false, "label": "400", "isController": false}, {"data": [[1.64491188E12, 0.2], [1.64491194E12, 0.13333333333333333], [1.64491182E12, 0.9166666666666666]], "isOverall": false, "label": "500", "isController": false}, {"data": [[1.644912E12, 0.6], [1.6449117E12, 0.8833333333333333], [1.64491188E12, 0.9333333333333333], [1.64491206E12, 0.16666666666666666]], "isOverall": false, "label": "502", "isController": false}, {"data": [[1.644912E12, 0.1], [1.6449117E12, 8.716666666666667], [1.64491188E12, 16.833333333333332], [1.64491206E12, 16.066666666666666], [1.64491176E12, 4.966666666666667], [1.64491194E12, 3.9833333333333334], [1.64491212E12, 4.283333333333333]], "isOverall": false, "label": "503", "isController": false}, {"data": [[1.644912E12, 0.35], [1.6449117E12, 0.13333333333333333], [1.64491218E12, 0.3], [1.64491224E12, 0.11666666666666667], [1.64491164E12, 0.11666666666666667], [1.64491182E12, 0.4]], "isOverall": false, "label": "504", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64491224E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.64491158E12, "maxY": 17.966666666666665, "series": [{"data": [[1.644912E12, 1.3833333333333333], [1.64491218E12, 0.1], [1.64491158E12, 2.6], [1.64491194E12, 0.8333333333333334], [1.64491212E12, 1.0333333333333334], [1.64491164E12, 0.38333333333333336]], "isOverall": false, "label": "Ingest API Firenoc-success", "isController": false}, {"data": [[1.644912E12, 1.1166666666666667], [1.6449117E12, 9.733333333333333], [1.64491218E12, 0.31666666666666665], [1.64491158E12, 0.016666666666666666], [1.64491188E12, 17.966666666666665], [1.64491206E12, 16.233333333333334], [1.64491176E12, 4.966666666666667], [1.64491224E12, 0.11666666666666667], [1.64491194E12, 4.133333333333334], [1.64491212E12, 4.3], [1.64491164E12, 0.11666666666666667], [1.64491182E12, 1.3166666666666667]], "isOverall": false, "label": "Ingest API Firenoc-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64491224E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.64491158E12, "maxY": 17.966666666666665, "series": [{"data": [[1.644912E12, 1.3833333333333333], [1.64491218E12, 0.1], [1.64491158E12, 2.6], [1.64491194E12, 0.8333333333333334], [1.64491212E12, 1.0333333333333334], [1.64491164E12, 0.38333333333333336]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.644912E12, 1.1166666666666667], [1.6449117E12, 9.733333333333333], [1.64491218E12, 0.31666666666666665], [1.64491158E12, 0.016666666666666666], [1.64491188E12, 17.966666666666665], [1.64491206E12, 16.233333333333334], [1.64491176E12, 4.966666666666667], [1.64491224E12, 0.11666666666666667], [1.64491194E12, 4.133333333333334], [1.64491212E12, 4.3], [1.64491164E12, 0.11666666666666667], [1.64491182E12, 1.3166666666666667]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64491224E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

