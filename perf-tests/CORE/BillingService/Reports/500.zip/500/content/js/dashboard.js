/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 95.86666666666666, "KoPercent": 4.133333333333334};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.21744444444444444, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.203, 500, 1500, "demand/_create"], "isController": false}, {"data": [0.26, 500, 1500, "businessservices/_search"], "isController": false}, {"data": [0.237, 500, 1500, "demand/_update"], "isController": false}, {"data": [0.354, 500, 1500, "demand/_search"], "isController": false}, {"data": [0.016, 500, 1500, "taxheads/_search"], "isController": false}, {"data": [0.243, 500, 1500, "taxperiods/_search"], "isController": false}, {"data": [0.05, 500, 1500, "/user/oauth/token"], "isController": false}, {"data": [0.318, 500, 1500, "v2/_search"], "isController": false}, {"data": [0.276, 500, 1500, "v2/_fetchbill"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 4500, 186, 4.133333333333334, 2993.5395555555606, 59, 130501, 1815.5, 4596.5, 5970.799999999999, 64568.84, 18.19122616949372, 328.77026742618403, 15.850677004167812], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["demand/_create", 500, 19, 3.8, 1975.0179999999993, 62, 65196, 1808.5, 3100.8, 3573.9, 4690.190000000003, 2.0491803278688527, 4.731597400102459, 3.6161348936987703], "isController": false}, {"data": ["businessservices/_search", 500, 19, 3.8, 1948.1640000000002, 59, 65948, 1604.0, 2705.9000000000005, 3112.8999999999996, 7106.6400000000285, 2.0494071065240824, 2.7184584718390967, 1.0185753456837436], "isController": false}, {"data": ["demand/_update", 500, 19, 3.8, 1746.8899999999996, 77, 31790, 1664.0, 2975.2000000000007, 3288.6499999999996, 4408.870000000002, 2.0488948261307853, 4.726224112213872, 4.841842606972799], "isController": false}, {"data": ["demand/_search", 500, 19, 3.8, 1346.2680000000005, 71, 15886, 1227.5, 2365.7000000000003, 2718.8, 3381.99, 2.0505081159111227, 4.795157282943463, 1.0138120624728306], "isController": false}, {"data": ["taxheads/_search", 500, 34, 6.8, 8108.8340000000035, 237, 130251, 4659.0, 7544.400000000001, 9142.949999999997, 130133.04000000001, 2.0430678707146654, 296.23745907479673, 0.9653735111142893], "isController": false}, {"data": ["taxperiods/_search", 500, 19, 3.8, 2902.5599999999995, 62, 130501, 1749.5, 3097.100000000001, 3556.4999999999995, 65197.71, 2.049121541595118, 4.460301247761334, 0.9815372228050835], "isController": false}, {"data": ["/user/oauth/token", 500, 19, 3.8, 5890.299999999997, 77, 66610, 3483.0, 6434.200000000002, 7513.549999999999, 66304.33, 4.334408266583446, 10.965993654968099, 2.9277488681776416], "isController": false}, {"data": ["v2/_search", 500, 19, 3.8, 1491.143999999999, 60, 4022, 1330.5, 2750.0000000000005, 3114.2, 3725.95, 2.048903222105207, 4.899115686966517, 1.058338549499453], "isController": false}, {"data": ["v2/_fetchbill", 500, 19, 3.8, 1532.6779999999997, 61, 15555, 1425.0, 2589.8, 2924.25, 4304.230000000006, 2.048223371047953, 4.674541786829105, 1.18644138855207], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400", 39, 20.967741935483872, 0.8666666666666667], "isController": false}, {"data": ["401", 45, 24.193548387096776, 1.0], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 94, 50.53763440860215, 2.088888888888889], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection timed out (Connection timed out)", 8, 4.301075268817204, 0.17777777777777778], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 4500, 186, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 94, "401", 45, "400", 39, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection timed out (Connection timed out)", 8, "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["demand/_create", 500, 19, "401", 10, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 9, "", "", "", "", "", ""], "isController": false}, {"data": ["businessservices/_search", 500, 19, "401", 10, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 9, "", "", "", "", "", ""], "isController": false}, {"data": ["demand/_update", 500, 19, "400", 13, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 6, "", "", "", "", "", ""], "isController": false}, {"data": ["demand/_search", 500, 19, "401", 12, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 7, "", "", "", "", "", ""], "isController": false}, {"data": ["taxheads/_search", 500, 34, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 20, "401", 8, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection timed out (Connection timed out)", 6, "", "", "", ""], "isController": false}, {"data": ["taxperiods/_search", 500, 19, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 12, "401", 5, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection timed out (Connection timed out)", 2, "", "", "", ""], "isController": false}, {"data": ["/user/oauth/token", 500, 19, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 19, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["v2/_search", 500, 19, "400", 13, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 6, "", "", "", "", "", ""], "isController": false}, {"data": ["v2/_fetchbill", 500, 19, "400", 13, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 6, "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
