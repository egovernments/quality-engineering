/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 45.74814814814815, "KoPercent": 54.25185185185185};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.11207407407407408, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.11766666666666667, 500, 1500, "demand/_create"], "isController": false}, {"data": [0.13933333333333334, 500, 1500, "businessservices/_search"], "isController": false}, {"data": [0.11833333333333333, 500, 1500, "demand/_update"], "isController": false}, {"data": [0.163, 500, 1500, "demand/_search"], "isController": false}, {"data": [0.014, 500, 1500, "taxheads/_search"], "isController": false}, {"data": [0.12166666666666667, 500, 1500, "taxperiods/_search"], "isController": false}, {"data": [0.04, 500, 1500, "/user/oauth/token"], "isController": false}, {"data": [0.14966666666666667, 500, 1500, "v2/_search"], "isController": false}, {"data": [0.145, 500, 1500, "v2/_fetchbill"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 13500, 7324, 54.25185185185185, 3313.8265185185223, 58, 131397, 738.0, 4905.699999999999, 8052.899999999998, 66126.76999999999, 32.60940455227288, 327.53755422068355, 26.44141022238406], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["demand/_create", 1500, 841, 56.06666666666667, 1599.460666666668, 71, 131275, 678.5, 3208.1000000000017, 4274.35, 14922.04, 3.655469557249527, 5.569134048962578, 6.460292785595744], "isController": false}, {"data": ["businessservices/_search", 1500, 800, 53.333333333333336, 1667.3086666666663, 70, 130496, 645.5, 3222.9, 4706.650000000009, 15914.8, 3.6545878477644886, 3.9829106904003724, 1.7847379614830805], "isController": false}, {"data": ["demand/_update", 1500, 902, 60.13333333333333, 1194.507999999999, 58, 24711, 662.5, 2735.8, 3412.000000000001, 9431.540000000005, 3.662511750558533, 5.36308319776953, 7.020553367374345], "isController": false}, {"data": ["demand/_search", 1500, 881, 58.733333333333334, 1162.9706666666646, 68, 25371, 660.0, 2274.9, 2980.250000000001, 13683.110000000008, 3.6593309279331367, 5.481451404237749, 1.7350469827596722], "isController": false}, {"data": ["taxheads/_search", 1500, 749, 49.93333333333333, 10027.234666666667, 69, 131086, 3022.5, 15811.400000000009, 64794.8, 130212.75, 4.334959424779784, 339.778640941452, 1.9442603466450303], "isController": false}, {"data": ["taxperiods/_search", 1500, 744, 49.6, 3418.8060000000005, 66, 131397, 751.0, 4431.000000000003, 10544.000000000011, 65220.83, 3.653439591594166, 5.697567585587912, 1.7192097244819422], "isController": false}, {"data": ["/user/oauth/token", 1500, 547, 36.46666666666667, 8621.935333333331, 63, 130951, 2350.0, 15368.900000000003, 66176.0, 68139.33, 5.447612130016342, 10.78391706010532, 3.6924312238968584], "isController": false}, {"data": ["v2/_search", 1500, 937, 62.46666666666667, 1005.7039999999992, 66, 26388, 488.0, 2443.6000000000004, 3179.8, 9445.83, 3.672887722270922, 5.38204785068732, 1.8208460443305303], "isController": false}, {"data": ["v2/_fetchbill", 1500, 923, 61.53333333333333, 1126.5106666666663, 70, 130007, 612.0, 2286.2000000000007, 2956.75, 10613.150000000009, 3.6659668743233236, 5.269218774057908, 2.046957999781264], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["503/Service Temporarily Unavailable", 5482, 74.84980884762425, 40.60740740740741], "isController": false}, {"data": ["502/Bad Gateway", 1236, 16.87602403058438, 9.155555555555555], "isController": false}, {"data": ["400", 147, 2.0070999453850353, 1.0888888888888888], "isController": false}, {"data": ["401", 176, 2.4030584380120152, 1.3037037037037038], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of chunk coded message body: closing chunk expected", 1, 0.013653741125068269, 0.007407407407407408], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 226, 3.0857454942654288, 1.674074074074074], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection timed out (Connection timed out)", 56, 0.764609503003823, 0.4148148148148148], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 13500, 7324, "503/Service Temporarily Unavailable", 5482, "502/Bad Gateway", 1236, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 226, "401", 176, "400", 147], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["demand/_create", 1500, 841, "503/Service Temporarily Unavailable", 605, "502/Bad Gateway", 179, "401", 42, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 15, "", ""], "isController": false}, {"data": ["businessservices/_search", 1500, 800, "503/Service Temporarily Unavailable", 503, "502/Bad Gateway", 241, "401", 38, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 17, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection timed out (Connection timed out)", 1], "isController": false}, {"data": ["demand/_update", 1500, 902, "503/Service Temporarily Unavailable", 729, "502/Bad Gateway", 113, "400", 47, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 13, "", ""], "isController": false}, {"data": ["demand/_search", 1500, 881, "503/Service Temporarily Unavailable", 664, "502/Bad Gateway", 159, "401", 45, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 13, "", ""], "isController": false}, {"data": ["taxheads/_search", 1500, 749, "503/Service Temporarily Unavailable", 467, "502/Bad Gateway", 138, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 72, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection timed out (Connection timed out)", 42, "401", 29], "isController": false}, {"data": ["taxperiods/_search", 1500, 744, "503/Service Temporarily Unavailable", 474, "502/Bad Gateway", 216, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 23, "401", 22, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection timed out (Connection timed out)", 9], "isController": false}, {"data": ["/user/oauth/token", 1500, 547, "503/Service Temporarily Unavailable", 466, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 49, "502/Bad Gateway", 29, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection timed out (Connection timed out)", 3, "", ""], "isController": false}, {"data": ["v2/_search", 1500, 937, "503/Service Temporarily Unavailable", 803, "502/Bad Gateway", 71, "400", 51, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 12, "", ""], "isController": false}, {"data": ["v2/_fetchbill", 1500, 923, "503/Service Temporarily Unavailable", 771, "502/Bad Gateway", 90, "400", 49, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 12, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection timed out (Connection timed out)", 1], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
