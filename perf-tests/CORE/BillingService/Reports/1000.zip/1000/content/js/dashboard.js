/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 75.82222222222222, "KoPercent": 24.177777777777777};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.2311111111111111, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.2605, 500, 1500, "demand/_create"], "isController": false}, {"data": [0.3125, 500, 1500, "businessservices/_search"], "isController": false}, {"data": [0.2455, 500, 1500, "demand/_update"], "isController": false}, {"data": [0.3315, 500, 1500, "demand/_search"], "isController": false}, {"data": [0.0585, 500, 1500, "taxheads/_search"], "isController": false}, {"data": [0.3145, 500, 1500, "taxperiods/_search"], "isController": false}, {"data": [0.034, 500, 1500, "/user/oauth/token"], "isController": false}, {"data": [0.2715, 500, 1500, "v2/_search"], "isController": false}, {"data": [0.2515, 500, 1500, "v2/_fetchbill"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 9000, 2176, 24.177777777777777, 9021.649888888907, 0, 144736, 1485.5, 11000.000000000065, 61042.59999999999, 137032.8, 30.117962017903455, 488.4805527378064, 25.0729615473103], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["demand/_create", 1000, 267, 26.7, 9681.923000000008, 0, 138806, 1412.0, 17082.399999999998, 60949.7, 138583.94, 3.3832017267861616, 6.703467311293466, 5.870918854329484], "isController": false}, {"data": ["businessservices/_search", 1000, 206, 20.6, 12724.63300000001, 0, 138772, 1306.5, 60919.1, 126798.84999999987, 137921.1, 3.383900080198432, 4.228953119659783, 1.673067613284515], "isController": false}, {"data": ["demand/_update", 1000, 321, 32.1, 3736.043999999998, 0, 130966, 1142.5, 3560.9, 5192.349999999992, 128545.94, 3.377511179562004, 6.463857147320282, 7.0969129072856285], "isController": false}, {"data": ["demand/_search", 1000, 290, 29.0, 6521.697, 0, 129641, 1049.0, 4490.799999999997, 21369.649999999805, 129282.84, 3.3786865693830177, 6.625627459050318, 1.6363929311119594], "isController": false}, {"data": ["taxheads/_search", 1000, 161, 16.1, 13723.872999999998, 0, 144736, 3281.5, 8800.2, 136637.6, 143785.89, 3.4539570258666843, 451.0979825814788, 1.6113755157189582], "isController": false}, {"data": ["taxperiods/_search", 1000, 208, 20.8, 8818.318000000003, 0, 137249, 1174.5, 3844.2999999999993, 70062.94999999998, 129762.03, 3.449977057652567, 6.844976844185235, 1.5779399949802833], "isController": false}, {"data": ["/user/oauth/token", 1000, 38, 3.8, 11861.923000000008, 71, 70872, 4438.5, 33381.9, 66423.55, 69694.5, 6.2514847276228105, 15.81681801771671, 4.222670364680362], "isController": false}, {"data": ["v2/_search", 1000, 353, 35.3, 5544.078999999997, 0, 138628, 954.5, 5865.8, 19991.049999999897, 128130.94, 3.381359915330748, 6.410708375882113, 1.7082735959748292], "isController": false}, {"data": ["v2/_fetchbill", 1000, 332, 33.2, 8582.358999999991, 0, 138585, 1114.5, 12544.499999999975, 60530.35, 129387.11, 3.3770777470838933, 6.250918143012489, 1.9335880775647218], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["503/Service Temporarily Unavailable", 597, 27.435661764705884, 6.633333333333334], "isController": false}, {"data": ["400", 152, 6.985294117647059, 1.6888888888888889], "isController": false}, {"data": ["504/Gateway Time-out", 303, 13.924632352941176, 3.3666666666666667], "isController": false}, {"data": ["502/Bad Gateway", 638, 29.31985294117647, 7.088888888888889], "isController": false}, {"data": ["401", 162, 7.444852941176471, 1.8], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 65, 2.9871323529411766, 0.7222222222222222], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection timed out (Connection timed out)", 8, 0.36764705882352944, 0.08888888888888889], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: qa.digit.org:443 failed to respond", 251, 11.534926470588236, 2.7888888888888888], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 9000, 2176, "502/Bad Gateway", 638, "503/Service Temporarily Unavailable", 597, "504/Gateway Time-out", 303, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: qa.digit.org:443 failed to respond", 251, "401", 162], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["demand/_create", 1000, 267, "502/Bad Gateway", 78, "503/Service Temporarily Unavailable", 71, "504/Gateway Time-out", 50, "401", 33, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: qa.digit.org:443 failed to respond", 29], "isController": false}, {"data": ["businessservices/_search", 1000, 206, "504/Gateway Time-out", 61, "503/Service Temporarily Unavailable", 53, "502/Bad Gateway", 37, "401", 33, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: qa.digit.org:443 failed to respond", 13], "isController": false}, {"data": ["demand/_update", 1000, 321, "503/Service Temporarily Unavailable", 111, "400", 82, "502/Bad Gateway", 78, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: qa.digit.org:443 failed to respond", 33, "504/Gateway Time-out", 13], "isController": false}, {"data": ["demand/_search", 1000, 290, "502/Bad Gateway", 110, "503/Service Temporarily Unavailable", 82, "504/Gateway Time-out", 38, "401", 33, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: qa.digit.org:443 failed to respond", 19], "isController": false}, {"data": ["taxheads/_search", 1000, 161, "502/Bad Gateway", 68, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: qa.digit.org:443 failed to respond", 55, "401", 30, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 8, "", ""], "isController": false}, {"data": ["taxperiods/_search", 1000, 208, "502/Bad Gateway", 71, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: qa.digit.org:443 failed to respond", 68, "504/Gateway Time-out", 34, "401", 33, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 2], "isController": false}, {"data": ["/user/oauth/token", 1000, 38, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to qa.digit.org:443 [qa.digit.org/3.108.179.107] failed: Connection refused (Connection refused)", 38, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["v2/_search", 1000, 353, "503/Service Temporarily Unavailable", 158, "502/Bad Gateway", 101, "504/Gateway Time-out", 41, "400", 30, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: qa.digit.org:443 failed to respond", 23], "isController": false}, {"data": ["v2/_fetchbill", 1000, 332, "503/Service Temporarily Unavailable", 122, "502/Bad Gateway", 95, "504/Gateway Time-out", 66, "400", 35, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: qa.digit.org:443 failed to respond", 11], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
