/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.013481481481481481, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "TL_create"], "isController": false}, {"data": [0.018, 500, 1500, "Water"], "isController": false}, {"data": [0.017, 500, 1500, "Challan_create"], "isController": false}, {"data": [0.007, 500, 1500, "Property_Tax"], "isController": false}, {"data": [0.004, 500, 1500, "PT_create"], "isController": false}, {"data": [0.026, 500, 1500, "Trade_License"], "isController": false}, {"data": [0.002, 500, 1500, "FSM_search"], "isController": false}, {"data": [0.004, 500, 1500, "PGR_search"], "isController": false}, {"data": [0.08, 500, 1500, "Challan_search"], "isController": false}, {"data": [0.0, 500, 1500, "BPA_create"], "isController": false}, {"data": [0.0, 500, 1500, "BPA_search"], "isController": false}, {"data": [0.001, 500, 1500, "Sewerage"], "isController": false}, {"data": [0.009, 500, 1500, "sewerage_create"], "isController": false}, {"data": [0.006, 500, 1500, "FSM"], "isController": false}, {"data": [0.008, 500, 1500, "water_search"], "isController": false}, {"data": [0.052, 500, 1500, "PGR_create"], "isController": false}, {"data": [0.002, 500, 1500, "Firenoc_search"], "isController": false}, {"data": [0.002, 500, 1500, "Challan"], "isController": false}, {"data": [0.002, 500, 1500, "PT_search"], "isController": false}, {"data": [0.0, 500, 1500, "FSM_create"], "isController": false}, {"data": [0.004, 500, 1500, "BPA"], "isController": false}, {"data": [0.0, 500, 1500, "Firenoc_create"], "isController": false}, {"data": [0.008, 500, 1500, "TL_search"], "isController": false}, {"data": [0.072, 500, 1500, "PGR"], "isController": false}, {"data": [0.03, 500, 1500, "water_create"], "isController": false}, {"data": [0.002, 500, 1500, "Firenoc"], "isController": false}, {"data": [0.008, 500, 1500, "sewerage_search"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 13500, 0, 0.0, 8084.563851851878, 46, 53820, 5446.5, 19560.999999999996, 23622.699999999993, 29359.909999999996, 57.449253159708924, 424.4819925847908, 451.7250900304268], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["TL_create", 500, 0, 0.0, 13231.992000000002, 4273, 53618, 9489.5, 24735.7, 25695.9, 33607.93, 3.4473248758963044, 21.515481720559848, 43.67397032715113], "isController": false}, {"data": ["Water", 500, 0, 0.0, 4703.181999999999, 979, 29257, 3957.0, 6339.600000000002, 10681.699999999988, 22582.65, 3.6975684789682304, 10.10331699624327, 19.358070913817077], "isController": false}, {"data": ["Challan_create", 500, 0, 0.0, 4284.310000000006, 164, 15357, 3678.0, 7182.1, 7444.8, 7872.5, 9.37752020855605, 58.527081692267295, 118.80329068906018], "isController": false}, {"data": ["Property_Tax", 500, 0, 0.0, 19926.77399999998, 480, 53784, 20548.0, 28756.4, 29329.95, 33608.43, 3.8039881011252197, 54.97580069194544, 26.691068854086623], "isController": false}, {"data": ["PT_create", 500, 0, 0.0, 16765.079999999998, 775, 53820, 18386.5, 27572.0, 28680.699999999997, 33600.22, 3.674066236066104, 53.22014109332863, 79.81047788579532], "isController": false}, {"data": ["Trade_License", 500, 0, 0.0, 12884.064000000008, 946, 29636, 12324.5, 22672.4, 26255.299999999996, 29165.350000000002, 3.551716544606008, 21.948498334244942, 22.062957949451974], "isController": false}, {"data": ["FSM_search", 500, 0, 0.0, 5041.949999999996, 137, 10079, 5059.5, 6614.200000000001, 8131.849999999999, 8848.99, 8.012306903403628, 68.98095474649061, 40.2414984416063], "isController": false}, {"data": ["PGR_search", 500, 0, 0.0, 18904.305999999993, 657, 30994, 19858.5, 29479.5, 30037.75, 30396.94, 5.665593980872955, 52.32375222374564, 28.455224456669537], "isController": false}, {"data": ["Challan_search", 500, 0, 0.0, 3648.063999999999, 87, 7920, 3408.0, 6792.0, 7465.049999999999, 7762.0, 10.686957636899928, 92.0080259051853, 53.67482727204719], "isController": false}, {"data": ["BPA_create", 500, 0, 0.0, 7786.724000000006, 2923, 15481, 6561.5, 12406.7, 14692.349999999995, 15390.66, 8.03548470043713, 50.151155000482134, 101.80111622926846], "isController": false}, {"data": ["BPA_search", 500, 0, 0.0, 4979.158000000003, 2535, 12374, 4455.0, 7837.200000000001, 7964.95, 10449.350000000004, 7.611161006499931, 65.52733929033535, 38.22675884416909], "isController": false}, {"data": ["Sewerage", 500, 0, 0.0, 4482.798000000002, 1228, 21861, 3624.5, 6335.9, 6712.949999999999, 18425.450000000004, 5.92585569356215, 15.809997807433392, 30.786672157959607], "isController": false}, {"data": ["sewerage_create", 500, 0, 0.0, 5075.538000000006, 165, 22748, 4983.5, 6310.9, 6385.55, 10327.380000000001, 6.3044547277106, 39.34743180156099, 79.87079217049768], "isController": false}, {"data": ["FSM", 500, 0, 0.0, 4221.735999999999, 188, 11067, 3906.5, 6058.000000000001, 6477.95, 6825.090000000001, 8.702917217851423, 34.13175346376105, 48.26549500017406], "isController": false}, {"data": ["water_search", 500, 0, 0.0, 5808.255999999992, 129, 27096, 5355.0, 6574.1, 14295.199999999999, 22420.160000000003, 4.610717150945658, 39.69539297142278, 23.15714678448586], "isController": false}, {"data": ["PGR_create", 500, 0, 0.0, 11196.244000000012, 46, 19885, 13326.0, 18683.5, 18906.9, 19756.77, 8.570449091532398, 19.425793302194034, 68.37109241086732], "isController": false}, {"data": ["Firenoc_search", 500, 0, 0.0, 4350.15400000001, 143, 12456, 4310.5, 6283.3, 6800.849999999998, 10170.880000000001, 8.888256835069505, 76.52233618942654, 44.64092275660398], "isController": false}, {"data": ["Challan", 500, 0, 0.0, 3547.408, 132, 15165, 2979.0, 5483.4000000000015, 6168.95, 9785.740000000002, 8.826436943934473, 38.667379033681684, 42.304836446123424], "isController": false}, {"data": ["PT_search", 500, 0, 0.0, 17792.970000000016, 1125, 33805, 18391.5, 28754.6, 29535.9, 30290.49, 3.664668200941087, 62.45682562775767, 18.40565288812501], "isController": false}, {"data": ["FSM_create", 500, 0, 0.0, 6120.521999999998, 1610, 11842, 6135.0, 8544.2, 9461.699999999999, 10366.390000000001, 8.39095119822783, 52.36969639440827, 106.30450185020474], "isController": false}, {"data": ["BPA", 500, 0, 0.0, 4705.393999999996, 86, 11542, 4447.5, 6153.3, 6583.0, 10901.320000000002, 8.02851729342625, 29.942292523041846, 27.46474226452359], "isController": false}, {"data": ["Firenoc_create", 500, 0, 0.0, 5867.408000000003, 1902, 11554, 6023.5, 7401.7, 7583.5, 7973.72, 8.447515585666256, 52.72272666796195, 107.0211129812972], "isController": false}, {"data": ["TL_search", 500, 0, 0.0, 8102.821999999995, 989, 29970, 5103.0, 22115.0, 22865.8, 28619.410000000003, 3.4057393519559165, 29.321287233245464, 17.105192858505152], "isController": false}, {"data": ["PGR", 500, 0, 0.0, 9604.573999999997, 99, 19999, 7241.5, 18946.0, 19345.0, 19908.69, 12.94565414390389, 28.912803737410353, 53.501961266602805], "isController": false}, {"data": ["water_create", 500, 0, 0.0, 5218.057999999998, 267, 27820, 5289.0, 6436.9, 7922.65, 21521.46, 4.033233846898444, 25.172263198757765, 51.096819038880376], "isController": false}, {"data": ["Firenoc", 500, 0, 0.0, 5409.306000000004, 311, 8158, 5627.0, 7395.100000000001, 7853.15, 8062.91, 8.22152065245988, 100.43261898595763, 58.90751662802552], "isController": false}, {"data": ["sewerage_search", 500, 0, 0.0, 4624.4320000000025, 927, 13387, 4479.5, 6291.8, 6476.7, 9694.660000000027, 7.413887694429206, 63.82893936922643, 37.235961340282614], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 13500, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
