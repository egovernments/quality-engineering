/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.22222222222223, "KoPercent": 1.7777777777777777};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8377777777777777, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.64, 500, 1500, "TL_create"], "isController": false}, {"data": [0.94, 500, 1500, "Challan_create"], "isController": false}, {"data": [0.96, 500, 1500, "sewerage_create"], "isController": false}, {"data": [0.9, 500, 1500, "water_search"], "isController": false}, {"data": [0.92, 500, 1500, "PGR_create"], "isController": false}, {"data": [1.0, 500, 1500, "Firenoc_search"], "isController": false}, {"data": [0.66, 500, 1500, "PT_create"], "isController": false}, {"data": [0.36, 500, 1500, "PT_search"], "isController": false}, {"data": [0.9, 500, 1500, "FSM_create"], "isController": false}, {"data": [0.92, 500, 1500, "FSM_search"], "isController": false}, {"data": [1.0, 500, 1500, "Firenoc_create"], "isController": false}, {"data": [0.4, 500, 1500, "PGR_search"], "isController": false}, {"data": [0.64, 500, 1500, "TL_search"], "isController": false}, {"data": [1.0, 500, 1500, "Challan_search"], "isController": false}, {"data": [0.9, 500, 1500, "water_create"], "isController": false}, {"data": [0.98, 500, 1500, "BPA_create"], "isController": false}, {"data": [1.0, 500, 1500, "BPA_search"], "isController": false}, {"data": [0.96, 500, 1500, "sewerage_search"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 450, 8, 1.7777777777777777, 473.55333333333317, 71, 2304, 340.5, 1093.9, 1277.5, 2032.0500000000004, 47.46334774812783, 362.4394141902226, 431.3346058894104], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["TL_create", 25, 0, 0.0, 627.8, 389, 1244, 619.0, 861.6000000000005, 1165.9999999999998, 1244.0, 5.966587112171838, 33.218274537589494, 75.5903658263723], "isController": false}, {"data": ["Challan_create", 25, 0, 0.0, 359.80000000000007, 113, 544, 356.0, 524.6, 541.6, 544.0, 15.096618357487921, 84.04865357035024, 191.25823237469808], "isController": false}, {"data": ["sewerage_create", 25, 1, 4.0, 263.79999999999995, 146, 387, 247.0, 382.2, 386.1, 387.0, 15.792798483891344, 84.59141069172458, 200.07810032375238], "isController": false}, {"data": ["water_search", 25, 0, 0.0, 341.40000000000003, 109, 907, 215.0, 859.0, 893.5, 907.0, 11.893434823977163, 102.3950404376784, 59.7343118161275], "isController": false}, {"data": ["PGR_create", 25, 0, 0.0, 297.2, 98, 539, 257.0, 532.2, 538.4, 539.0, 16.733601070950467, 34.16988265562249, 133.4929561997992], "isController": false}, {"data": ["Firenoc_search", 25, 0, 0.0, 264.32, 161, 368, 243.0, 359.6, 366.2, 368.0, 14.585764294049008, 125.57431446907819, 73.25643141044341], "isController": false}, {"data": ["PT_create", 25, 2, 8.0, 705.6, 188, 1329, 705.0, 1171.8000000000002, 1290.3, 1329.0, 6.51890482398957, 80.2912626303781, 141.60792861799217], "isController": false}, {"data": ["PT_search", 25, 2, 8.0, 1331.7600000000002, 586, 2304, 1273.0, 2050.8, 2246.3999999999996, 2304.0, 5.230125523012552, 82.14034714958159, 26.253391409518827], "isController": false}, {"data": ["FSM_create", 25, 1, 4.0, 326.64000000000004, 175, 603, 306.0, 573.8000000000001, 600.9, 603.0, 14.671361502347418, 78.58634554724179, 185.87067653315728], "isController": false}, {"data": ["FSM_search", 25, 1, 4.0, 316.0, 163, 732, 292.0, 524.6000000000001, 677.6999999999998, 732.0, 14.37607820586544, 119.00304143904542, 72.18307486342725], "isController": false}, {"data": ["Firenoc_create", 25, 0, 0.0, 297.63999999999993, 152, 460, 305.0, 401.8000000000001, 452.79999999999995, 460.0, 13.116474291710388, 73.02443353226653, 166.17189549449108], "isController": false}, {"data": ["PGR_search", 25, 0, 0.0, 1160.8799999999999, 329, 2104, 1108.0, 1968.6000000000004, 2089.3, 2104.0, 7.227522405319456, 66.7487103389708, 36.29994895562301], "isController": false}, {"data": ["TL_search", 25, 0, 0.0, 740.0799999999999, 159, 1283, 892.0, 1191.4, 1255.6999999999998, 1283.0, 7.946598855689765, 68.41524952320407, 39.911482338684046], "isController": false}, {"data": ["Challan_search", 25, 0, 0.0, 250.0799999999999, 71, 449, 229.0, 426.00000000000006, 446.6, 449.0, 17.277125086385624, 148.74524879060124, 86.77368585867312], "isController": false}, {"data": ["water_create", 25, 0, 0.0, 355.52, 123, 737, 379.0, 581.8000000000002, 702.4999999999999, 737.0, 10.597710894446799, 59.00151348558711, 134.26181975943197], "isController": false}, {"data": ["BPA_create", 25, 0, 0.0, 311.3599999999999, 175, 527, 289.0, 431.00000000000006, 500.8999999999999, 527.0, 14.277555682467161, 79.48861811107939, 180.8815721373501], "isController": false}, {"data": ["BPA_search", 25, 0, 0.0, 283.4400000000001, 202, 389, 267.0, 373.40000000000003, 387.2, 389.0, 14.277555682467161, 122.92083095374073, 71.70846569817247], "isController": false}, {"data": ["sewerage_search", 25, 1, 4.0, 290.64000000000004, 173, 465, 281.0, 428.80000000000007, 459.0, 465.0, 15.67398119122257, 129.74688969435738, 78.69991673197492], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400", 8, 100.0, 1.7777777777777777], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 450, 8, "400", 8, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["sewerage_create", 25, 1, "400", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["PT_create", 25, 2, "400", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["PT_search", 25, 2, "400", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["FSM_create", 25, 1, "400", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["FSM_search", 25, 1, "400", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["sewerage_search", 25, 1, "400", 1, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
